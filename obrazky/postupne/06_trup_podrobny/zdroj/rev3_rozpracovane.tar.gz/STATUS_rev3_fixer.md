# STATUS rev3 fixer (round 1) – WORK IN PROGRESS (interim save 2026-11-22 13:05 UTC)

Backups of every changed file: `rev3_backup/<name>.bak` (+ `rev3_backup/stl/` = the rev. 2 STL set).

## Done so far
* `fe_sachta/` harness: `femodel.py` (model from the current STL, contact solver), `cases.py` (loads / supports / joint), `post.py`
  (spots, 0.4 mm averaging x 1.04, bond), `fe_design.py` + `design.json` (joint description written by t4_pan / build_all),
  `run_fe.py` (entry: acceptance cases + fail-safe cases -> `results.json`; `--validate` -> `validation.json`).
* `t4_common.py`: block `rev3 (sachta)` (dict `R3`, R2 re-bindings, PAN_ENV2 floor band).
* `t4_pan.py`: `mk_sachta` rev. 3 (floor over the whole well, hub lip, R1 roots, R1.5 window corners, lintel, R3.0 inner corners, rail block
  high on the back wall with a stadium groove, pad C, shroud roof, spline relief), `mk_drziak` (stadium tongue, plate relief, keyhole
  relief), `mk_ucho` (flange end chamfer), `mk_koleso` (lower bore chamfer), 8th PTFE strip (lintel), `fe_design()`.
* `t4_ram.py`: T_cap root R1.0 + hole D3.1, F15 = M3x8 + 2 x DIN 125 + DIN 9021 (parts pd_F15_d1 / pd_F15_d2), pan pinion face 3.0.
* `t4_assembly.py`: B2, B2b (F15 calibration), B4b, B7b, T7, T11 (rest-gap calibration), S3, S4.
* `t4_ram_checks.py`, `t4_pan_checks.py`: pivot rows / strength rows updated (not yet re-run to the end).
* FE evidence for R3-3 at h 0.6 (res/var_lens_h06, res/var_floor_h06): option (a) "lens + 2.3 wall" fails L3 (lens 39.6-40.6 MPa vs 12.9),
  option (b) "real floor" passes L3 (lens 4.7, max spot 10.6) -> (b) chosen.

## Still to do (this list is replaced by the final status at the end of the round)
* FE: validation run on the rev. 2 STL (h 0.4) - running; coarse runs of geometry v2; final h 0.4 acceptance run -> results.json.
* checks.py: K12 FE rows; module checks re-run; build_all + checks.py --force.
* T4_spec.md 17.17, opravy3.md, final STATUS, 3 previews.
