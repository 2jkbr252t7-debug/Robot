"""export the three FE parts of a floor variant ('floor' = R3-3 b, 'lens' = R3-3 a) into fe_sachta/var_<variant>/stl + design.json
(the design files of the build are NOT touched): python export_variant.py floor|lens"""
import os, sys, json
v = sys.argv[1]
os.environ["NOVA_FLOOR_VARIANT"] = v
HERE = os.path.dirname(os.path.abspath(__file__)); sys.path.insert(0, os.path.dirname(HERE))
import t4_common as C, t4_pan as P, t4_obal as O
out = os.path.join(HERE, f"var_{v}")
for name, fn in (("P_sachta", P.mk_sachta), ("koleso_pan", P.mk_koleso), ("P_drziak_serva", P.mk_drziak)):
    s = fn()
    r = O.export_abs(name, C.part(s, "P", "resin_black" if name != "koleso_pan" else "brass", name != "koleso_pan", name), out=out, do_step=False)
    print(v, name, "valid", r["valid"], "solids", r["n_solids"], "watertight", r["watertight"], "vol", r["volume_mesh"], flush=True)
json.dump(P.fe_design(), open(os.path.join(out, "design.json"), "w"), indent=1)
