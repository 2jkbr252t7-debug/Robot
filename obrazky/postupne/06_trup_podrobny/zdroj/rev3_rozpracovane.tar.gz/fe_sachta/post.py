"""post-processing of one FE case: true-surface stresses of P_sachta and P_drziak_serva (points sampled on the STL, ~0.13 mm
spacing), per named critical spot the maximum principal stress s1 averaged over 0.4 mm (the averaging distance of the review
sachta_a/summarize_v3.py) x 1.04 (FE reproduces plain bending of 1.25-1.6 walls 2-4 % low: sachta_a/fe_test5.log), the gear bond
tractions (peel at the edge and shear, 0.6 mm average as sachta_a/post_bond.py) and the allowable by load class
(T4_zivica.md Z2: normal 8.5, abuse 12.9, unfilleted notch 4.3 / 6.45; bond 2.7)."""
import os, json, numpy as np
from scipy.spatial import cKDTree
import fe3d, femodel as FM

KFE = 1.04
R_AVG = 0.4
ALLOW = {"normal": (8.5, 4.3), "abuse": (12.9, 6.45), "failsafe": (25.8, 25.8)}     # (filleted, sharp notch); failsafe = lower-bound strength
BOND_ALLOW = 2.7


def surface_points(stl_dir, name, cache_dir, seed=1, area=0.017):
    st = FM.stl_stamp(stl_dir, (name,))
    f = os.path.join(cache_dir, f"surf_{name}_{st}.npz")
    if os.path.exists(f):
        d = np.load(f); return d["P"], d["N"]
    T = FM.read_part(stl_dir, name)
    a, b, c = T[:, 0], T[:, 1], T[:, 2]
    n = np.cross(b - a, c - a); A = 0.5 * np.linalg.norm(n, axis=1); nu = n / (2 * A[:, None] + 1e-30)
    rng = np.random.default_rng(seed)
    k = np.maximum(1, np.ceil(A / area).astype(int))
    idx = np.repeat(np.arange(len(T)), k)
    r1 = rng.random(len(idx)); r2 = rng.random(len(idx)); s = np.sqrt(r1)
    P = (1 - s)[:, None] * a[idx] + (s * (1 - r2))[:, None] * b[idx] + (s * r2)[:, None] * c[idx]
    N = nu[idx]
    os.makedirs(cache_dir, exist_ok=True)
    np.savez_compressed(f, P=P.astype(np.float32), N=N.astype(np.float32))
    return P.astype(np.float32), N.astype(np.float32)


def well_spots(P, D):
    """named critical spots of P_sachta: name -> (mask, sharp)"""
    x, y, z = P[:, 0], P[:, 1], P[:, 2]; R = np.hypot(x, y)
    S = D.get("spots", {})
    we = S.get("win_end", dict(y=(-7.0, 3.4), z_top=-15.0)); wb = S.get("win_back", dict(x=(-20.9, -6.5), z_top=-10.9, z_sill=-40.65))
    rl = S.get("rail", dict(x=(-6.6, 16.6), z=(-41.88, -33.6)))
    sharp = S.get("sharp", ["win_end", "win_back", "corner_floor"])
    cr = np.hypot(np.abs(x) - 21.0, np.abs(y) - 8.5)
    corner = (np.abs(x) > 21) & (np.abs(y) > 8.5) & (cr >= 2.3) & (cr <= 4.0)
    we_c = (x > 22.4) & (x < 25.3) & ((np.abs(y - we["y"][1]) < 2.2) | (np.abs(y - we["y"][0]) < 2.2)) & (z > we["z_top"] - 2.4) & (z < we["z_top"] + 0.8)
    wb_c = (y > 10.9) & (y < 13.1) & ((np.abs(x - wb["x"][1]) < 2.2) | (np.abs(x - wb["x"][0]) < 2.2)) & \
           ((np.abs(z - wb["z_top"]) < 2.2) | ((z < wb["z_sill"] + 2.2) & (z > wb["z_sill"] - 0.4)))
    rail = (y > 13.0) & (z >= rl["z"][0]) & (z <= rl["z"][1]) & (x > rl["x"][0]) & (x < rl["x"][1])
    lens = (np.abs(x) <= 9.0) & (y <= -9.9) & (y >= -12.7) & (z <= -39.3) & (z >= -41.95)
    F = [
        ("lens: hub ring <-> front wall junction", lens, False),
        ("hub ring / lip (floor r <= 12.8)", (z <= -40.5) & (R <= 12.8) & (np.abs(y) < 10.6) & ~lens, False),
        ("front wall lower zone above the lens (z -39.3..-30)", (np.abs(x) <= 9.0) & (y <= -10.2) & (z > -39.3) & (z <= -30), False),
        ("back floor (r > 12.8)", (z <= -40.5) & (z >= -41.95) & (y >= 3.0) & (R > 12.8) & (y < 10.9) & (x < 22.9), False),
        ("back floor <-> back wall junction R1.0", (y >= 10.0) & (y <= 11.3) & (z >= -40.8) & (z <= -39.3) & (x > wb["x"][1] + 2.2) & (x < 19), False),
        ("corner (+X,+Y) arc <-> floor joint", (x > 21) & (y > 8.5) & (np.hypot(x - 21.0, y - 8.5) >= 1.2) & (np.hypot(x - 21.0, y - 8.5) <= 3.0) & (z >= -40.9) & (z <= -39.3), "corner_floor" in sharp),
        ("+X end-window top corners", we_c, "win_end" in sharp),
        ("back-window corners (top + sill / jamb)", wb_c, "win_back" in sharp),
        ("slim corner arcs 1.34 (z -40.2..-10.8)", corner & (z > -40.2) & (z < -10.8), False),
        ("slim corner arcs in the journal band zone", corner & (z >= -10.8) & (z < -3.4), False),
        ("+X pillar (window jamb) below the window top", (x > 22.4) & (y > we["y"][1] - 0.1) & (y < 8.5) & (z < we["z_top"] - 2.4) & (z > -40.5), False),
        ("+X end wall / lintel above the window", (x > 22.4) & (np.abs(y) < 8.5) & (z >= we["z_top"] + 0.8) & (z < -3.4), False),
        ("-X end wall", (x < -22.9) & (np.abs(y) < 8.5) & (z > -40.95) & (z < -3.4), False),
        ("front wall (rest)", (y < -10.2) & (np.abs(x) < 21) & (z > -40.95) & (z < -3.4), False),
        ("rail / ledge of the lift module (lips, groove, roots)", rail, False),
        ("F10 pads", (y > 13.0) & (z > -41.88) & (z < -3.4), False),
        ("back wall (rest)", (y > 10.3) & (y < 13.05) & (np.abs(x) < 21) & (z > -39.3) & (z < -3.4), False),
        ("drum shroud + lip + web (z < -41.9)", (z < -41.92), False),
        ("journal band (r > 25.9)", (R > 25.9) & (z >= -10.1) & (z <= -2.9), False),
        ("top plate / ribs / ring (z > -10.1)", (z > -10.1), False),
        ("thin floor 0.95 zone (FFC groove)", (x >= 15.0) & (x <= 23.5) & (y >= 3.2) & (y <= 7.3) & (z <= -40.4) & (z >= -41.7), False),
    ]
    out = {}; free = np.ones(len(P), bool)
    for name, m, shp in F:                         # priority order: a point belongs to the first spot that claims it
        mm = m & free
        if name.startswith("thin floor"):
            mm = m                                 # overlay spot (also part of the back floor)
        else:
            free &= ~m
        out[name] = (mm, bool(shp))
    return out


def pocket_spots(P, D):
    x, y, z = P[:, 0], P[:, 1], P[:, 2]; R = np.hypot(x, y)
    tg = D["tongues"]
    tmask = np.zeros(len(P), bool)
    for t in tg:
        z0, z1 = min(t["z_up"], t["z_lo"]), max(t["z_up"], t["z_lo"])
        tmask |= (x >= t["x"][0] - 0.8) & (x <= t["x"][1] + 0.8) & (y <= 15.9) & (z >= z0 - 1.6) & (z <= z1 + 1.6)
    Lg = D["lug"]
    lug = (R >= Lg["r"][0] - 2.0) & (z <= -41.0) & (y > 0)
    return {"P_drziak_serva tongue + roots": (tmask, False),
            "P_drziak_serva stop lug + bridge root": (lug & ~tmask, False),
            "P_drziak_serva plate near the F10 pads / dowel": ((y <= 17.2) & ~tmask & ~lug, False)}


def avg_max(P, tree, v, idx, r=R_AVG, ntop=80, sign=1.0):
    if not len(idx):
        return None
    vv = sign * v[idx]
    top = idx[np.argsort(-vv)[:ntop]]
    a = np.array([np.nanmean(v[tree.query_ball_point(P[i], r)]) for i in top])
    k = int(np.nanargmax(sign * a))
    return float(a[k]), top[k], float(sign * np.nanmax(vv))


def internal_forces(m, U, body):
    b = m.bodies[m.names.index(body)]
    K0, _, _ = fe3d.element(m.h, b["nu"])
    en = b["enodes"]
    ue = np.stack([U[3 * en], U[3 * en + 1], U[3 * en + 2]], 2).reshape(len(en), 24)
    fe = ue @ K0.T
    if len(b.get("part", [])):
        fe[b["part"]] = np.einsum("nij,nj->ni", b["Kpart"], ue[b["part"]])
    fe *= b["E"]
    f = np.zeros((m.nn, 3))
    for a in range(8):
        for c in range(3):
            np.add.at(f[:, c], en[:, a], fe[:, 3 * a + c])
    return f


def bond(stage, U):
    m = stage.m; X = m.X; nb = m.node_body
    fg = internal_forces(m, U, "gear")
    ids = np.flatnonzero((nb == stage.WELL) & (np.abs(X[:, 2] - FM.Z_BOND) < 1e-6) & (np.linalg.norm(fg, axis=1) > 0) & m.bond_fn(X))
    fb = fg[ids]; A = m.h ** 2
    tz = fb[:, 2] / A; ts = np.hypot(fb[:, 0], fb[:, 1]) / A
    t = cKDTree(X[ids, :2])
    nbr = t.query_ball_point(X[ids, :2], 0.6)
    tz_s = np.array([tz[n].mean() for n in nbr]); ts_s = np.array([ts[n].mean() for n in nbr])
    k = int(np.argmax(tz_s)); ks = int(np.argmax(ts_s))
    return dict(n_nodes=int(len(ids)), area=round(m.bond_area, 1), Fz=round(float(fb[:, 2].sum()), 2),
                tension_sum=round(float(fb[fb[:, 2] > 0, 2].sum()), 2), mean_tension=round(float(fb[:, 2].sum() / max(m.bond_area, 1e-9)), 4),
                peel_avg06=round(float(tz_s[k]), 3), peel_at=[round(float(v), 2) for v in X[ids[k]]], peel_node=round(float(tz.max()), 3),
                shear_avg06=round(float(ts_s[ks]), 3), shear_at=[round(float(v), 2) for v in X[ids[ks]]],
                torque_z=round(float((X[ids, 0] * fb[:, 1] - X[ids, 1] * fb[:, 0]).sum()), 1),
                mean_shear=round(float(np.hypot(fb[:, 0], fb[:, 1]).sum() / max(m.bond_area, 1e-9)), 4))


def evaluate(stage, U, rs, stl_dir, cache_dir, out_dir, save_surf=True):
    """rows for results.json: one per (spot, case)"""
    m = stage.m; D = stage.D; case = rs["case"]; cls = rs["spec"]["cls"]
    rows = []
    for body, part, spot_fn in (("well", "P_sachta", well_spots), ("pocket", "P_drziak_serva", pocket_spots)):
        P, N = surface_points(stl_dir, part, cache_dir)
        P = P.astype(np.float64); N = N.astype(np.float64)
        sig, ok, el = fe3d.point_stress_fc(m, U, body, P, N)
        s1, s2, s3, vm = fe3d.principal(np.nan_to_num(sig))
        s1[~ok] = np.nan; s3[~ok] = np.nan
        tree = cKDTree(P)
        for name, (msk, sharp) in spot_fn(P, D).items():
            idx = np.flatnonzero(msk & ok)
            r = avg_max(P, tree, s1, idx)
            if r is None:
                continue
            a, i, raw = r
            allow = ALLOW[cls][1 if sharp else 0]
            stress = KFE * a
            rc = avg_max(P, tree, s3, idx, sign=-1.0)
            rows.append(dict(spot=name, part=part, case=case, cls=cls, stress=round(stress, 2), raw_max=round(raw, 2), allowable=allow,
                             sharp=sharp, ok=bool(stress <= allow), margin=round(allow / stress, 2) if stress > 0 else None,
                             at=[round(float(v), 2) for v in P[i]], s3_avg=round(KFE * rc[0], 2), n_pts=int(len(idx))))
        if save_surf and body == "well":
            np.savez_compressed(os.path.join(out_dir, case + "_surf.npz"), s1=s1.astype(np.float32), s3=s3.astype(np.float32))
    if stage.GEAR >= 0 and not stage.nobond:
        b = bond(stage, U)
        rs["bond"] = b
        for nm, key, at in (("gear bond: peel at the edge (0.6 mm average)", "peel_avg06", "peel_at"), ("gear bond: local shear (0.6 mm average)", "shear_avg06", "shear_at")):
            v = max(b[key], 0.0)
            rows.append(dict(spot=nm, part="bond", case=case, cls=cls, stress=round(v, 2), raw_max=b.get("peel_node") if "peel" in key else None,
                             allowable=BOND_ALLOW, sharp=False, ok=bool(v <= BOND_ALLOW), margin=round(BOND_ALLOW / v, 2) if v > 0 else None, at=b[at]))
    rs["rows"] = rows
    json.dump(rs, open(os.path.join(out_dir, case + ".json"), "w"), indent=1, default=float)
    return rows
