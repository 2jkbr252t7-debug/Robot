import sys, time, numpy as np, scipy.sparse as sp, scipy.sparse.linalg as spl, cProfile, pstats
import femodel as FM, fe_design as FD, cases as CS, pyamg
h = 0.8
st = CS.Stage("../rev3_backup/stl", h, FD.load("rev2"), "cache", log=lambda s: None)
m = st.m; n3 = 3 * m.nn; C = FM.Contact
F = np.zeros(n3); lg = []; st.twist_case(F, 600.0, 0.0, lg)
ids = st.mesh_ids(CS.PAN_AZ % 360)
S = [C("journal", "both", CS.K_JG, ids=st.J_ids[::8], dirs=st.unit_radial(st.J_ids[::8])), C("pivot", "both", CS.K_PIV, ids=st.PIV_ids, dirs=st.unit_radial(st.PIV_ids)),
     C("ptfe", "both", CS.K_PTFE, ids=st.PTFE_ids, dirs=np.tile([0, 0, 1.0], (len(st.PTFE_ids), 1))), C("pinion", "both", CS.K_PIN / len(ids), ids=ids, dirs=st.unit_tang(ids))]
for nm, a, b, d, kind in st.pairs:
    S.append(C(nm, "both", st.k_pair, a=a, b=b, d=d))
A = m.K.copy()
for c in S:
    A = A + c.matrix(n3)
A = A.tocsr(); B = FM.rigid_modes(m.X)
ml = pyamg.smoothed_aggregation_solver(A, B=B, max_coarse=600, keep=False)
print(ml)
M = ml.aspreconditioner(cycle="V")
x = np.random.rand(n3)
t0 = time.time(); [M @ x for _ in range(5)]; print("V-cycle", (time.time() - t0) / 5)
for i, lv in enumerate(ml.levels[:-1]):
    t0 = time.time(); [lv.A @ np.ones(lv.A.shape[0]) for _ in range(5)]; print("level", i, "matvec", (time.time() - t0) / 5, type(lv.A), lv.A.shape, lv.A.nnz)
    t0 = time.time(); xx = np.zeros(lv.A.shape[0]); lv.presmoother(lv.A, xx, np.ones(lv.A.shape[0])); print("   presmooth", time.time() - t0)
pr = cProfile.Profile(); pr.enable(); [M @ x for _ in range(5)]; pr.disable()
pstats.Stats(pr).sort_stats("cumulative").print_stats(14)
