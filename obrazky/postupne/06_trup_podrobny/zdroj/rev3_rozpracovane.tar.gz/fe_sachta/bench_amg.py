import sys, time, numpy as np, scipy.sparse as sp, scipy.sparse.linalg as spl
import femodel as FM, fe_design as FD, cases as CS, pyamg
h = float(sys.argv[1]) if len(sys.argv) > 1 else 0.8
st = CS.Stage("../rev3_backup/stl", h, FD.load("rev2"), "cache", log=print)
m = st.m; n3 = 3 * m.nn; C = FM.Contact
F = np.zeros(n3); lg = []; st.twist_case(F, 600.0, 0.0, lg)
ids = st.mesh_ids(CS.PAN_AZ % 360)
S = [C("journal", "both", CS.K_JG, ids=st.J_ids[::8], dirs=st.unit_radial(st.J_ids[::8])), C("pivot", "both", CS.K_PIV, ids=st.PIV_ids, dirs=st.unit_radial(st.PIV_ids)),
     C("ptfe", "both", CS.K_PTFE, ids=st.PTFE_ids, dirs=np.tile([0, 0, 1.0], (len(st.PTFE_ids), 1))), C("pinion", "both", CS.K_PIN / len(ids), ids=ids, dirs=st.unit_tang(ids))]
for nm, a, b, d, kind in st.pairs:
    S.append(C(nm, "both", st.k_pair, a=a, b=b, d=d))
A = m.K.copy()
for c in S:
    A = A + c.matrix(n3)
A = A.tocsr(); Ab = A.tobsr(blocksize=(3, 3)); B = FM.rigid_modes(m.X)
def run(tag, Amat, **kw):
    t0 = time.time(); ml = pyamg.smoothed_aggregation_solver(Amat, B=B, max_coarse=600, keep=False, **kw); ts = time.time() - t0
    M = ml.aspreconditioner(cycle="V"); it = [0]; t0 = time.time()
    u, info = spl.cg(Amat, F, rtol=1e-6, maxiter=250, M=M, callback=lambda x: it.__setitem__(0, it[0] + 1)); tc = time.time() - t0
    print(f"{tag:42s} setup {ts:5.1f} s  its {it[0]:4d}  solve {tc:6.1f} s  {tc / max(it[0], 1):.3f} s/it  levels {len(ml.levels)} opcx {ml.operator_complexity():.2f}", flush=True)
    return u
t0 = time.time(); y = A @ F; print("csr matvec", time.time() - t0); t0 = time.time(); y = Ab @ F; print("bsr matvec", time.time() - t0)
cheb = lambda d: ("chebyshev", {"degree": d, "iterations": 1})
run("CSR cheb3", A, presmoother=cheb(3), postsmoother=cheb(3))
run("CSR cheb2", A, presmoother=cheb(2), postsmoother=cheb(2))
run("BSR cheb3", Ab, presmoother=cheb(3), postsmoother=cheb(3))
run("BSR cheb2", Ab, presmoother=cheb(2), postsmoother=cheb(2))
run("BSR evolution cheb3", Ab, strength=("evolution", {"k": 2, "proj_type": "l2", "epsilon": 4.0}), presmoother=cheb(3), postsmoother=cheb(3))
run("CSR jacobi", A, presmoother=("jacobi", {"omega": 2.0 / 3.0, "iterations": 2}), postsmoother=("jacobi", {"omega": 2.0 / 3.0, "iterations": 2}))
run("BSR cheb4", Ab, presmoother=cheb(4), postsmoother=cheb(4))
