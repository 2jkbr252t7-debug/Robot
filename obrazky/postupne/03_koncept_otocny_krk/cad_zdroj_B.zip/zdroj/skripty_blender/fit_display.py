"""Does a W x H (corner R) board fit inside the head cavity section at local y? Uses softhead.sec with shrink = wall."""
import sys, math
sys.path.insert(0, "/tmp/claude-0/pan16"); sys.path.insert(0, "/tmp/claude-0/gapwf/fin/common")
import softhead as SH
SH.W, SH.H, SH.N = 108.0, 77.0, 3.6
from build123d import Face, Vector
def contour(y, shrink, n=720):
    w = SH.sec(y, shrink=shrink)
    return [w.position_at(i / n) for i in range(n)]
def fits(y, W, H, R, shrink=2.5, clear=0.0):
    pts = contour(y, shrink)
    zc = SH.H / 2
    # min signed distance from board outline points to the contour polygon (inside positive)
    import numpy as np
    P = np.array([(p.X, p.Z) for p in pts])
    # board outline samples
    B = []
    hw, hh = W / 2, H / 2
    for sx in (-1, 1):
        for sz in (-1, 1):
            for k in range(0, 91, 5):
                a = math.radians(k)
                B.append((sx * (hw - R + R * math.cos(a)), zc + sz * (hh - R + R * math.sin(a))))
    B = np.array(B)
    # inside test via winding (contour is star-shaped about the centre): compare radial distance
    c = np.array([0, zc])
    angP = np.arctan2(P[:, 1] - c[1], P[:, 0] - c[0]); rP = np.hypot(*(P - c).T)
    o = np.argsort(angP); angP, rP = angP[o], rP[o]
    worst = 1e9
    for b in B:
        a = math.atan2(b[1] - c[1], b[0] - c[0]); r = math.hypot(*(b - c))
        rr = np.interp(a, angP, rP, period=2 * math.pi)
        worst = min(worst, rr - r)
    return round(float(worst), 2)
print("head W,H", SH.W, SH.H, "N", SH.N)
for y in (-26.9, -25.0, -23.7, -22.3):
    for (W, H, R, lab) in ((86, 56, 2, "model 86x56 R2"), (92.44, 61.0, 2, "92.44x61 R2"), (92.44, 61.0, 5, "92.44x61 R5"), (92.44, 61.0, 8, "92.44x61 R8"), (92.44, 61.0, 12, "92.44x61 R12")):
        print(f"y={y:6.1f}  {lab:16s} radial margin to inner wall (shrink 2.5): {fits(y, W, H, R):6.2f} mm   to OUTER skin: {fits(y, W, H, R, shrink=0.0):6.2f}")
