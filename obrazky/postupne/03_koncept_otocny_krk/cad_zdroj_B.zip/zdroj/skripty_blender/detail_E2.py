"""Variant B rev. E2 – labelled detail renders + 2-D label anchors (JSON).
 'spredu' : B_5_rez section (y = -1), neck extended, tilt 0, seen from front-left: servo pocket, hinge, servo lead
 'modul'  : the removable front module (bezel + display + carrier + magnets) exploded backwards, seen from rear 3/4
 'kabel'  : E2f - neck cut at the servo-wire groove plane (y = wire y), seen from the front-right: the servo wires going DOWN
Anchors: a vertex of the part near the requested point of its world bbox that the camera actually sees (ray cast).
Usage: blender-python detail_E2.py <blend> <out_dir>"""
import bpy, sys, os, json
from mathutils import Vector
from bpy_extras.object_utils import world_to_camera_view

BLEND, OUT = sys.argv[-2], sys.argv[-1]
bpy.ops.wm.open_mainfile(filepath=BLEND)
sc = bpy.context.scene
vl = bpy.context.view_layer
sc.frame_set(174)                                   # neck extended, tilt 0, pan 0
AXZ = bpy.data.objects["naklon_B"].matrix_world.translation.z
print("AXZ", AXZ)
sc.cycles.samples = int(os.environ.get("DET_SAMPLES", 64))
sc.render.resolution_x, sc.render.resolution_y = 1400, 1100
cam = sc.camera
top = [c for c in vl.layer_collection.children if c.name.startswith("B_")][0]
LC = {c.name[2:]: c for c in top.children}          # '1_obal', '2_displej', ...
for ob in bpy.data.objects:
    if ob.name.startswith("popis_"):
        ob.hide_render = True
        ob.hide_viewport = True


def show(cols):
    for k, lc in LC.items():
        lc.exclude = k not in cols
        if k in cols:
            lc.hide_viewport = False
            lc.collection.hide_render = False
            lc.collection.hide_viewport = False
    vl.update()


def hide(*names, on=True):
    for n in names:
        o = bpy.data.objects.get(n)
        if o:
            o.hide_viewport = o.hide_render = on
    vl.update()


def aim(tgt, off, lens):
    cam.location = tgt + Vector(off)
    cam.rotation_euler = (tgt - cam.location).to_track_quat("-Z", "Y").to_euler()
    cam.data.lens = lens
    vl.update()


def px(p):
    c = world_to_camera_view(sc, cam, p)
    return [round(c.x * sc.render.resolution_x, 1), round((1 - c.y) * sc.render.resolution_y, 1)]


def anchor(names, bias=(0.5, 0.5, 0.5)):
    """visible vertex near the 'bias' point of the parts' world bbox"""
    dg = bpy.context.evaluated_depsgraph_get()
    P = []
    obs = [bpy.data.objects[n] for n in names if n in bpy.data.objects and bpy.data.objects[n].visible_get()]
    for o in obs:
        me = o.evaluated_get(dg).to_mesh()
        P += [(o.matrix_world @ v.co, o) for v in me.vertices]
    if not P:
        print("ANCHOR MISSING", names)
        return None
    lo = Vector((min(p.x for p, _ in P), min(p.y for p, _ in P), min(p.z for p, _ in P)))
    hi = Vector((max(p.x for p, _ in P), max(p.y for p, _ in P), max(p.z for p, _ in P)))
    tgt = Vector([lo[i] + (hi[i] - lo[i]) * bias[i] for i in range(3)])
    cand = sorted(P, key=lambda q: (q[0] - tgt).length)[:600]
    eye = cam.matrix_world.translation
    for p, o in cand:
        d = p - eye
        hit, loc, nrm, idx, hob, mx = sc.ray_cast(dg, eye, d.normalized(), distance=d.length + 0.05)
        if hit and (hob.original if hasattr(hob, "original") else hob) == o and (loc - p).length < 0.6:
            return p
    print("ANCHOR not visible, using nearest", names)
    return cand[0][0]


B = lambda *n: [f"B_{x}" for x in n]
res = {}
# ---------------------------------------------------------------- 1) front section through the neck
show({"3_mechanika", "4_trup", "5_rez"})
hide("B_trup")
aim(Vector((2, 0, AXZ + 4)), (-70, -150, 52), 50)
L1 = {
    "servo": anchor(B("servo_MG90S"), (0.5, 0.5, 0.45)),
    "pena": anchor(B("pena_serva"), (0.9, 0.5, 0.4)),
    "paka": anchor(B("paka"), (0.5, 0.5, 0.8)),
    "kryt": anchor(B("usko_kryt_rez"), (0.2, 0.5, 0.3)),
    "lozisko": anchor(B("loziska_MR85_hlava", "loziska_MR85_krk"), (0.5, 0.5, 0.7)),
    "cap": anchor(B("capy"), (0.75, 0.5, 0.5)),
    "kabel": anchor(B("kabel_serva"), (0.5, 0.5, 0.35)),
    "krk": anchor(B("krk_zadna_polovica_rez"), (0.12, 0.5, 0.15)),
}
res["spredu"] = {k: px(v) for k, v in L1.items() if v is not None}
sc.render.filepath = os.path.join(OUT, "E2_spredu.png")
bpy.ops.render.render(write_still=True)
hide("B_trup", on=False)
# ---------------------------------------------------------------- 2) front module exploded backwards (+Y)
show({"1_obal", "2_displej", "3_mechanika"})
keep = {"B_ram_displeja": 0.0, "B_magnety": 0.0, "B_vlozky": 0.0, "B_pena_displeja": 10.0,
        "B_displej_sklo": 20.0, "B_displej": 20.0, "B_drziak_displeja": 38.0, "B_skrutky_drziaka": 50.0}
saved = {}
for o in bpy.data.objects:
    if o.type != "MESH" or not o.name.startswith("B_"):
        continue
    if o.name in keep:
        saved[o.name] = o.location.copy()
        o.location.y += keep[o.name]
        o.hide_viewport = o.hide_render = False
    else:
        o.hide_render = True
        o.hide_viewport = True
vl.update()
zc = sum((bpy.data.objects["B_ram_displeja"].matrix_world @ Vector(c)).z for c in bpy.data.objects["B_ram_displeja"].bound_box) / 8
aim(Vector((0, 5, zc)), (165, 205, 95), 55)
L2 = {
    "ram": anchor(B("ram_displeja"), (0.95, 0.5, 0.75)),
    "magnety": anchor(B("magnety"), (0.0, 0.5, 0.5)),
    "vlozky": anchor(B("vlozky"), (0.8, 0.5, 1.0)),
    "pena": anchor(B("pena_displeja"), (0.95, 0.5, 0.2)),
    "displej": anchor(B("displej"), (0.35, 0.5, 0.45)),
    "sklo": anchor(B("displej_sklo"), (0.02, 0.5, 0.2)),
    "drziak": anchor(B("drziak_displeja"), (0.75, 0.5, 0.95)),
    "skrutky": anchor(B("skrutky_drziaka"), (0.2, 0.5, 0.05)),
}
res["modul"] = {k: px(v) for k, v in L2.items() if v is not None}
sc.render.filepath = os.path.join(OUT, "E2_modul.png")
bpy.ops.render.render(write_still=True)
for n, loc in saved.items():
    bpy.data.objects[n].location = loc
for o in bpy.data.objects:
    if o.type == "MESH" and o.name.startswith("B_"):
        o.hide_render = o.hide_viewport = False
vl.update()
# ---------------------------------------------------------------- 3) E2f: cut through the servo-wire groove (y = -5),
# front part of the front half removed, seen from the front-right: the 3 wires leave the bottom-cover notch and run DOWN
show({"1_obal", "3_mechanika", "4_trup"})
for o in bpy.data.objects:
    if o.type == "MESH" and o.name.startswith("B_") and any(c.name == "B_1_obal" for c in o.users_collection):
        if not o.name.startswith("B_krk_"):
            o.hide_render = o.hide_viewport = True
wires = bpy.data.objects["B_kabel_serva"]
WY = sum((wires.matrix_world @ Vector(c)).y for c in wires.bound_box) / 8
print("WIRE_Y", WY)
bpy.ops.mesh.primitive_cube_add(size=1)
box = bpy.context.active_object
box.scale = (300, 200, 400)
box.location = (0, WY - 100 - 0.0, 0)          # removes y < WY (front skin of the front half)
box.hide_render = box.hide_viewport = True
for n in ("krk_predna_polovica", "krk_zadna_polovica", "trup", "golier_kotuc", "golier_prstenec", "servo_MG90S",
          "pena_serva", "kabel_krk", "skrutky_krk", "capy"):
    o = bpy.data.objects.get("B_" + n)
    if o and o.type == "MESH":
        md = o.modifiers.new("ycut", "BOOLEAN")
        md.object, md.operation, md.solver = box, "DIFFERENCE", "EXACT"
for n in ("B_hlava_skrupina", "B_usko_kryt", "B_usko_lozisko", "B_klzny_kruzok", "B_paka", "B_kabel_hlava",
          "B_loziska_MR85_hlava", "B_loziska_MR85_krk", "B_skrutky_hlava"):
    o = bpy.data.objects.get(n)
    if o:
        o.hide_render = o.hide_viewport = True
vl.update()
aim(Vector((6, WY, -2)), (55, -150, 30), 52)
L3 = {
    "kabel": anchor(B("kabel_serva"), (0.5, 0.5, 0.25)),
    "zarez": anchor(B("kabel_serva"), (0.0, 0.5, 1.0)),
    "servo": anchor(B("servo_MG90S"), (0.5, 0.0, 0.5)),
    "krk": anchor(B("krk_predna_polovica"), (0.2, 0.0, 0.2)),
    "trup": anchor(B("trup"), (0.15, 0.0, 0.55)),
    "pena": anchor(B("pena_serva"), (0.95, 0.0, 0.5)),
}
res["kabel"] = {k: px(v) for k, v in L3.items() if v is not None}
sc.render.filepath = os.path.join(OUT, "E2_kabel.png")
bpy.ops.render.render(write_still=True)
json.dump(res, open(os.path.join(OUT, "anchors.json"), "w"), indent=1)
print("DONE", json.dumps(res))
