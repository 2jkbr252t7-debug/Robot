"""Variant B rev. E2 – labelled detail renders + 2-D label anchors (JSON).
 'spredu' : B_5_rez section (y = -1), neck extended, tilt 0, seen from front-left: servo pocket, hinge, servo lead
 'modul'  : the removable front module (bezel + display + carrier + magnets) exploded backwards, seen from rear 3/4
 'kabel'  : head + neck cut at x = LEAD_X (plane x), seen from -X: the servo lead going up through the knuckle into the head
Anchors: a vertex of the part near the requested point of its world bbox that the camera actually sees (ray cast).
Usage: blender-python detail_E2.py <blend> <out_dir>"""
import bpy, sys, os, json
from mathutils import Vector
from bpy_extras.object_utils import world_to_camera_view

BLEND, OUT = sys.argv[-2], sys.argv[-1]
bpy.ops.wm.open_mainfile(filepath=BLEND)
sc = bpy.context.scene
vl = bpy.context.view_layer
sc.frame_set(174)                                   # neck extended, tilt 0, pan 0
AXZ = bpy.data.objects["naklon_B"].matrix_world.translation.z
print("AXZ", AXZ)
sc.cycles.samples = int(os.environ.get("DET_SAMPLES", 64))
sc.render.resolution_x, sc.render.resolution_y = 1400, 1100
cam = sc.camera
top = [c for c in vl.layer_collection.children if c.name.startswith("B_")][0]
LC = {c.name[2:]: c for c in top.children}          # '1_obal', '2_displej', ...
for ob in bpy.data.objects:
    if ob.name.startswith("popis_"):
        ob.hide_render = True
        ob.hide_viewport = True


def show(cols):
    for k, lc in LC.items():
        lc.exclude = k not in cols
        if k in cols:
            lc.hide_viewport = False
            lc.collection.hide_render = False
            lc.collection.hide_viewport = False
    vl.update()


def hide(*names, on=True):
    for n in names:
        o = bpy.data.objects.get(n)
        if o:
            o.hide_viewport = o.hide_render = on
    vl.update()


def aim(tgt, off, lens):
    cam.location = tgt + Vector(off)
    cam.rotation_euler = (tgt - cam.location).to_track_quat("-Z", "Y").to_euler()
    cam.data.lens = lens
    vl.update()


def px(p):
    c = world_to_camera_view(sc, cam, p)
    return [round(c.x * sc.render.resolution_x, 1), round((1 - c.y) * sc.render.resolution_y, 1)]


def anchor(names, bias=(0.5, 0.5, 0.5)):
    """visible vertex near the 'bias' point of the parts' world bbox"""
    dg = bpy.context.evaluated_depsgraph_get()
    P = []
    obs = [bpy.data.objects[n] for n in names if n in bpy.data.objects and bpy.data.objects[n].visible_get()]
    for o in obs:
        me = o.evaluated_get(dg).to_mesh()
        P += [(o.matrix_world @ v.co, o) for v in me.vertices]
    if not P:
        print("ANCHOR MISSING", names)
        return None
    lo = Vector((min(p.x for p, _ in P), min(p.y for p, _ in P), min(p.z for p, _ in P)))
    hi = Vector((max(p.x for p, _ in P), max(p.y for p, _ in P), max(p.z for p, _ in P)))
    tgt = Vector([lo[i] + (hi[i] - lo[i]) * bias[i] for i in range(3)])
    cand = sorted(P, key=lambda q: (q[0] - tgt).length)[:600]
    eye = cam.matrix_world.translation
    for p, o in cand:
        d = p - eye
        hit, loc, nrm, idx, hob, mx = sc.ray_cast(dg, eye, d.normalized(), distance=d.length + 0.05)
        if hit and (hob.original if hasattr(hob, "original") else hob) == o and (loc - p).length < 0.6:
            return p
    print("ANCHOR not visible, using nearest", names)
    return cand[0][0]


B = lambda *n: [f"B_{x}" for x in n]
res = {}
# ---------------------------------------------------------------- 1) front section through the neck
show({"3_mechanika", "4_trup", "5_rez"})
hide("B_trup")
aim(Vector((2, 0, AXZ + 4)), (-70, -150, 52), 50)
L1 = {
    "servo": anchor(B("servo_MG90S"), (0.5, 0.5, 0.45)),
    "pena": anchor(B("pena_serva"), (0.9, 0.5, 0.4)),
    "paka": anchor(B("paka"), (0.5, 0.5, 0.8)),
    "kryt": anchor(B("usko_kryt_rez"), (0.2, 0.5, 0.3)),
    "lozisko": anchor(B("loziska_MR85_hlava", "loziska_MR85_krk"), (0.5, 0.5, 0.7)),
    "cap": anchor(B("capy"), (0.75, 0.5, 0.5)),
    "kabel": anchor(B("kabel_serva_krk"), (0.5, 0.5, 0.5)),
    "kabel_hlava": anchor(B("kabel_serva_hlava"), (0.5, 0.5, 0.7)),
    "zatka": anchor(B("zatka_kabla"), (0.5, 0.5, 0.9)),
    "krk": anchor(B("krk_zadna_polovica_rez"), (0.12, 0.5, 0.15)),
}
res["spredu"] = {k: px(v) for k, v in L1.items() if v is not None}
sc.render.filepath = os.path.join(OUT, "E2_spredu.png")
bpy.ops.render.render(write_still=True)
hide("B_trup", on=False)
# ---------------------------------------------------------------- 2) front module exploded backwards (+Y)
show({"1_obal", "2_displej", "3_mechanika"})
keep = {"B_ram_displeja": 0.0, "B_magnety": 0.0, "B_vlozky": 0.0, "B_pena_displeja": 10.0,
        "B_displej_sklo": 20.0, "B_displej": 20.0, "B_drziak_displeja": 38.0, "B_skrutky_drziaka": 50.0}
saved = {}
for o in bpy.data.objects:
    if o.type != "MESH" or not o.name.startswith("B_"):
        continue
    if o.name in keep:
        saved[o.name] = o.location.copy()
        o.location.y += keep[o.name]
        o.hide_viewport = o.hide_render = False
    else:
        o.hide_render = True
        o.hide_viewport = True
vl.update()
zc = sum((bpy.data.objects["B_ram_displeja"].matrix_world @ Vector(c)).z for c in bpy.data.objects["B_ram_displeja"].bound_box) / 8
aim(Vector((0, 5, zc)), (165, 205, 95), 55)
L2 = {
    "ram": anchor(B("ram_displeja"), (0.95, 0.5, 0.75)),
    "magnety": anchor(B("magnety"), (0.0, 0.5, 0.5)),
    "vlozky": anchor(B("vlozky"), (0.8, 0.5, 1.0)),
    "pena": anchor(B("pena_displeja"), (0.95, 0.5, 0.2)),
    "displej": anchor(B("displej"), (0.35, 0.5, 0.45)),
    "sklo": anchor(B("displej_sklo"), (0.02, 0.5, 0.2)),
    "drziak": anchor(B("drziak_displeja"), (0.75, 0.5, 0.95)),
    "skrutky": anchor(B("skrutky_drziaka"), (0.2, 0.5, 0.05)),
}
res["modul"] = {k: px(v) for k, v in L2.items() if v is not None}
sc.render.filepath = os.path.join(OUT, "E2_modul.png")
bpy.ops.render.render(write_still=True)
for n, loc in saved.items():
    bpy.data.objects[n].location = loc
for o in bpy.data.objects:
    if o.type == "MESH" and o.name.startswith("B_"):
        o.hide_render = o.hide_viewport = False
vl.update()
# ---------------------------------------------------------------- 3) side cut at the servo-lead plane (x = lead x)
show({"1_obal", "2_displej", "3_mechanika", "4_trup"})
lead = bpy.data.objects["B_kabel_serva_krk"]
LX = sum((lead.matrix_world @ Vector(c)).x for c in lead.bound_box) / 8
print("LEAD_X", LX)
bpy.ops.mesh.primitive_cube_add(size=1)
box = bpy.context.active_object
box.scale = (300, 400, 400)
box.location = (LX - 150 - 0.0, 0, 60)          # removes x < LX
box.hide_render = True
box.hide_viewport = True
for n in ("hlava_skrupina", "ram_displeja", "displej_sklo", "displej", "drziak_displeja", "pena_displeja", "usi",
          "led_kruzky", "led_dosky", "krk_predna_polovica", "krk_zadna_polovica", "usko_kryt", "usko_lozisko", "trup",
          "golier_kotuc", "golier_prstenec", "servo_MG90S", "pena_serva", "magnety", "magnety_skrupina", "paka",
          "oci_len_vizualizacia", "skrutky_drziaka", "vlozky"):
    for o in (bpy.data.objects.get("B_" + n), bpy.data.objects.get("B_" + n + "_hlava"), bpy.data.objects.get("B_" + n + "_krk")):
        if o and o.type == "MESH":
            md = o.modifiers.new("xcut", "BOOLEAN")
            md.object, md.operation, md.solver = box, "DIFFERENCE", "EXACT"
vl.update()
hz = bpy.data.objects["B_hlava_skrupina"]
hzmin = min((hz.matrix_world @ Vector(c)).z for c in hz.bound_box)
aim(Vector((LX, -6, hzmin + 6)), (-230, -8, 30), 60)
L3 = {
    "kabel": anchor(B("kabel_serva_krk"), (0.5, 0.5, 0.6)),
    "kabel_hlava": anchor(B("kabel_serva_hlava"), (0.5, 0.45, 1.0)),
    "zatka": anchor(B("zatka_kabla"), (0.5, 0.5, 0.5)),
    "servo": anchor(B("servo_MG90S"), (0.5, 0.5, 0.5)),
    "skrupina": anchor(B("hlava_skrupina"), (0.5, 0.75, 0.04)),
    "displej": anchor(B("displej"), (0.5, 0.1, 0.25)),
    "krk": anchor(B("krk_zadna_polovica"), (0.5, 0.8, 0.3)),
}
res["kabel"] = {k: px(v) for k, v in L3.items() if v is not None}
sc.render.filepath = os.path.join(OUT, "E2_kabel.png")
bpy.ops.render.render(write_still=True)
json.dump(res, open(os.path.join(OUT, "anchors.json"), "w"), indent=1)
print("DONE", json.dumps(res))
