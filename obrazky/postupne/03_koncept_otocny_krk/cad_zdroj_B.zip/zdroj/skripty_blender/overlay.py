"""Comparison sheet: the user's MG90S drawing with the CURRENT model-B servo envelope drawn over it (same scale),
plus the user's photo with the two real mismatches marked.  Usage: python overlay.py <out.png>"""
import sys
from PIL import Image, ImageDraw, ImageFont
C = "/tmp/claude-0/-home-user-Robot/e2af8646-c6f1-5ece-963d-7005cfdf5589/scratchpad/cmp/"
F = "/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf"
FB = "/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf"
f = lambda s, b=False: ImageFont.truetype(FB if b else F, s)
RED, GRN, ORG, INK = (214, 40, 40), (22, 130, 60), (215, 120, 0), (30, 30, 35)

# ------------------------------------------------------------------ left: drawing + model envelope
S = 27.19                      # px per mm in drawing_side.png
AX, BOT = 925.0, 1027.5        # spline axis x, case bottom y
u = lambda dz: AX + dz * S     # dz = distance from the axis along the case (+ = toward the near end)
v = lambda h: BOT - h * S      # h = height above the case bottom
d = Image.open(C + "drawing_side.png").convert("RGB")
ov = Image.new("RGBA", d.size, (0, 0, 0, 0))
g = ImageDraw.Draw(ov)


def box(dz0, dz1, h0, h1, col=RED, fill=28, w=5):
    g.rectangle([u(dz0), v(h1), u(dz1), v(h0)], outline=col + (255,), fill=col + (fill,), width=w)


box(-16.9, 5.9, 0, 22.5)                       # case 22.8 x 22.5
box(-5.9, 5.9, 22.5, 28.5)                     # boss r5.9 x 6.0
box(-2.4, 2.4, 28.5, 31.5)                     # spline
box(-3.5, 3.5, 28.8, 32.1)                     # horn hub (top 32.1)
box(-6.0, 6.0, 30.5, 32.1)                     # trimmed horn arms 12 mm
box(-10.0, -4.4, 22.5, 23.7, col=RED, fill=110)  # 2nd bump as modelled: r2.8 x 1.2 at 7.2
box(-16.9 - 4.85, -16.9, 15.5, 18.0)           # kept tab 15.5..18
box(-16.9 - 2.0, -16.9, 0.65, 2.35, col=RED, fill=110)  # lead boot as modelled (far end)
d = Image.alpha_composite(d.convert("RGBA"), ov).convert("RGB")
W, H = 2000, 1500
left = Image.new("RGB", (W, H), "white")
left.paste(d, (190, 150))
L = ImageDraw.Draw(left)
ox, oy = 190, 150


def note(txt, xy, to, col, size=30, anchor="la"):
    L.line([xy, to], fill=col, width=4)
    L.ellipse([to[0] - 7, to[1] - 7, to[0] + 7, to[1] + 7], fill=col)
    bb = L.multiline_textbbox(xy, txt, font=f(size, True), anchor=anchor, spacing=6)
    L.rectangle([bb[0] - 8, bb[1] - 6, bb[2] + 8, bb[3] + 6], fill="white", outline=col, width=2)
    L.multiline_text(xy, txt, font=f(size, True), fill=col, anchor=anchor, spacing=6)


L.text((40, 30), "Tvoj výkres MG90S  +  červená = servo, ako je teraz v modeli B (rovnaká mierka)", font=f(40, True), fill=INK)
L.text((40, 84), "čierne čiary = tvoj obrázok · červené = môj model", font=f(28), fill=(90, 90, 95))
note("✘ 2. výstupok: v modeli len 1,2 mm\n   na obrázku ≈ 5,5 mm (ako veža)", (60, 215), (ox + u(-7.6), oy + v(23.2)), RED)
note("✘ kábel: v modeli vychádza TU\n   (koniec ďaleko od hriadeľa)", (40, 1330), (ox + u(-18.0), oy + v(1.5)), RED)
note("skutočný kábel vychádza TU\n(koniec pri hriadeli, pri dne)", (1420, 1330), (ox + u(5.9), oy + v(1.8)), GRN)
note("✔ výška po páku: 32,1 / 32", (1330, 215), (ox + u(3.5), oy + v(32.1)), GRN)
note("✔ dĺžka 22,8 / 22,4 · šírka 12,2 / 12", (640, 1400), (ox + u(-6.0), oy + v(0.0)), GRN)
note("! vrch tela: model 22,5\n  (kóta „24“, nakreslené 22,6)", (40, 400), (ox + u(-13.0), oy + v(22.5)), ORG)
note("! úchyt: model 15,5–18 od dna\n  výkres ho kreslí vyššie (19,7–22)\n  druhý úchyt treba odrezať", (40, 1010), (ox + u(-19.5), oy + v(16.7)), ORG)

# ------------------------------------------------------------------ right: photo with marks
p = Image.open(C + "photo_top.png").convert("RGB")
k = 1500 / p.size[1] * 0.80
p = p.resize((int(p.size[0] * k), int(p.size[1] * k)), Image.LANCZOS)
right = Image.new("RGB", (p.size[0] + 80, H), "white")
right.paste(p, (40, 200))
R = ImageDraw.Draw(right)
R.text((40, 30), "Tvoja fotka – dve veci, ktoré model nemá správne", font=f(40, True), fill=INK)
px = lambda x, y: (40 + x * k, 200 + y * k)


def rnote(txt, xy, to, col=RED, size=30):
    R.line([xy, to], fill=col, width=5)
    R.ellipse([to[0] - 9, to[1] - 9, to[0] + 9, to[1] + 9], outline=col, width=5)
    bb = R.multiline_textbbox(xy, txt, font=f(size, True), spacing=6)
    R.rectangle([bb[0] - 8, bb[1] - 6, bb[2] + 8, bb[3] + 6], fill="white", outline=col, width=2)
    R.multiline_text(xy, txt, font=f(size, True), fill=col, spacing=6)


rnote("1  druhý výstupok vedľa hriadeľa\n   je rovnako vysoký ako veža", (640, 1250), px(455, 640))
rnote("2  kábel vychádza na konci\n   pri hriadeli, dole pri dne", (60, 1250), px(215, 215))
sheet = Image.new("RGB", (W + right.size[0], H), "white")
sheet.paste(left, (0, 0))
sheet.paste(right, (W, 0))
ImageDraw.Draw(sheet).line([(W, 20), (W, H - 20)], fill=(200, 200, 205), width=3)
sheet.save(sys.argv[1])
print(sheet.size)
