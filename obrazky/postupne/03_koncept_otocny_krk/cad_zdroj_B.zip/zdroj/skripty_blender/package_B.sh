#!/bin/bash
# Final variant-B packaging: regenerate rig/blend/glb/detail sheet from fin/B and copy everything into the repo.
set -euo pipefail
S=/tmp/claude-0/-home-user-Robot/e2af8646-c6f1-5ece-963d-7005cfdf5589/scratchpad
F=/tmp/claude-0/gapwf/fin
R=/home/user/Robot/obrazky/postupne/03_koncept_otocny_krk
O=$S/finalB
mkdir -p $O/stage/B_servo_v_krku $O/rig $O/prev $O/det
cp $F/B/stl/*.stl $O/stage/B_servo_v_krku/
cd $S
/opt/venv/cad/bin/python export_rig.py B $O/rig/B > $O/rig.log 2>&1
tail -n 1 $O/rig.log
/opt/venv/bl/bin/python make_blend_v3.py -- $O/rig $O/stage $O/NOVA_mini_B.blend --only B --preview $O/prev > $O/blend.log 2>&1
grep -E "BLEND|PREVIEW" $O/blend.log
NOVA_ONLY=B /opt/venv/bl/bin/python to_glb3.py $O/rig $O/stage $S/viewer > $O/glb.log 2>&1
grep -E "^glb" $O/glb.log | cut -c1-80
/opt/venv/bl/bin/python detail_B.py $O/NOVA_mini_B.blend $O/det > $O/det.log 2>&1
grep DONE $O/det.log | cut -c1-120
/opt/venv/cad/bin/python sheet_B.py $O/det $O/det/sheet_B.png "${SKR_TEXT:-skrutky M2 sťahujú polovice\n(vložky v zadnej polovici)}"
cd $O/prev && /opt/venv/cad/bin/python -c "
from PIL import Image
ims=[Image.open(f'f{f:03d}.png').convert('RGB') for f in (1,48,210,288)]
w,h=ims[0].size; S=Image.new('RGB',(w*2,h*2),'white')
for i,im in enumerate(ims): S.paste(im,((i%2)*w,(i//2)*h))
S.save('$O/NOVA_mini_B_animacia.png')
Image.open('rez_B.png').convert('RGB').save('$O/NOVA_mini_B_rez.png')"
# ---------------------------------------------------------------- repo
cd /home/user/Robot
git rm -r -q "$R/stl/B_servo_v_krku"
mkdir -p "$R/stl/B_servo_v_krku"
cp $F/B/stl/*.stl "$R/stl/B_servo_v_krku/"
cp $F/B/montaz.txt "$R/stl/B_servo_v_krku/montaz.txt"
cp $F/B/checks.json "$R/stl/B_servo_v_krku/kontroly.json"
cp $S/stl_README_B.txt $R/stl/README.txt
cp $O/NOVA_mini_B.blend $R/NOVA_mini_B.blend
cp $O/NOVA_mini_B_animacia.png $R/NOVA_mini_B_animacia.png
cp $O/NOVA_mini_B_rez.png $R/NOVA_mini_B_rez_servo_v_krku.png
cp $O/det/sheet_B.png $R/NOVA_mini_B_uchytenie_serva_v_krku.png
cp $S/viewer/nova_b.glb $R/model_3d/NOVA_mini_B_servo_v_krku.glb
sed 's#"nova_b.txt"#"NOVA_mini_B_servo_v_krku.glb"#; s#"nova_a.txt"#"NOVA_mini_A_servo_v_hlave.glb"#' \
  $S/viewer/hlava_nova.html > $R/model_3d/prehliadac.html
# CAD sources (absolute paths, see zdroj/CITAJ.txt)
rm -f $R/cad_zdroj_B.zip
cp $S/export_rig.py $S/make_blend_v3.py $S/to_glb3.py $S/detail_B.py $S/sheet_B.py $S/src_pack/zdroj/skripty_blender/
(cd /tmp/claude-0 && zip -q -r $R/cad_zdroj_B.zip gapwf/fin/B/*.py gapwf/fin/common/*.py \
   gapwf/c_hn3/*.py gapwf/c_hn4/*.py pan16/softhead.py)
(cd $S/src_pack && zip -q -r $R/cad_zdroj_B.zip zdroj)
# zip for the user: B STL folder + README + blend
if [ -f $R/NOVA_mini_STL_A_B.zip ]; then git rm -q $R/NOVA_mini_STL_A_B.zip; fi
rm -f $R/NOVA_mini_B_STL.zip
(cd $R && zip -q -r NOVA_mini_B_STL.zip stl/README.txt stl/B_servo_v_krku NOVA_mini_B.blend)
du -sh $R/NOVA_mini_B_STL.zip $R/NOVA_mini_B.blend $R/cad_zdroj_B.zip
