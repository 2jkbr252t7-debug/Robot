"""Labelled sheets of variant B rev. E2 (Slovak).  Usage: python sheet_E2.py <det_dir> <out_dir>
-> NOVA_mini_B_servo_a_kabel.png (servo pocket section + servo-lead route), NOVA_mini_B_modul_displeja.png"""
import sys, json, os
sys.path.insert(0, "/home/user/Robot")
from PIL import Image, ImageDraw
from nova.render.sheet import font, INK, MUTED, ACCENT

D, OUT = sys.argv[1], sys.argv[2]
A = json.load(open(os.path.join(D, "anchors.json")))
SHEETS = {
    "NOVA_mini_B_servo_a_kabel.png": (
        "NOVA mini · verzia B – servo v krku a jeho vodiče",
        "Servo MG90S leží v kapse medzi prednou a zadnou polovicou krku, os jeho hriadeľa je os kĺbu. Páka serva je zovretá\n"
        "v kryte pravého uška a točí hlavou priamo. Servo je UPRAVENÉ: pôvodný kábel sa odspájkuje a 3 tenké vodiče vyjdú\n"
        "zárezom na okraji spodného veka, drážkou v prednej polovici krku idú DOLE do trupu – kábel nejde cez pánt ani do hlavy.", [
            ("E2_spredu.png", "spredu", "Rez spredu – krk vysunutý, hlava v 0° (predná polovica odrezaná)", {
                "servo": "servo MG90S, ušká odrezané;\nkapsa prijme 12,0–12,3 × 22,4–22,8\na výšku 22,4–23,0 mm",
                "pena": "penové pásiky a podložky –\nservo sedí bez vôle",
                "paka": "páka serva (originálna, skrátená\nna 12 mm) – kryt prijme jej\nvýšku 8,9–10,3 mm nad telom",
                "kryt": "kryt pravého uška (−X):\nramená páky zovreté 4 rebrami",
                "lozisko": "ložisko MR85 v ľavom\nuške (+X)",
                "cap": "dutý čap Ø5 – cez neho\nidú 4 vodiče do hlavy",
                "kabel": "vodiče serva (oranžové)\nidú DOLE do trupu",
                "krk": "zadná polovica krku",
            }),
            ("E2_kabel.png", "kabel", "Rez rovinou drážky vodičov serva – predná časť prednej polovice krku odrezaná", {
                "zarez": "3 vodiče AWG30 vychádzajú zárezom\n2 × 2 mm na okraji spodného veka serva",
                "kabel": "drážka v prednej polovici krku –\nvodiče idú rovno dole do trupu,\npri náklone sa nehýbu",
                "servo": "servo MG90S (upravené – pôvodný\nkábel odspájkovaný)",
                "krk": "predná polovica krku (rez)",
                "trup": "trup – servo sa zapojí\ndo elektroniky trupu",
            }),
        ]),
    "NOVA_mini_B_modul_displeja.png": (
        "NOVA mini · verzia B – predný modul s displejom (rozložený)",
        "Tvárou robota je priamo sklo displeja Waveshare ESP32-S3-Touch-LCD-3.5B (92,44 × 61,00 mm, dotyk funguje). Sedí v čiernom\n"
        "lesklom ráme, ktorý má rovnaký tvar ako hlava – spoj so škrupinou je bez schodíka. Displej je priskrutkovaný k dvom lištám,\n"
        "lišty k rámu. Celý modul drží v hlave na 6 magnetoch; vyberá sa prísavkou, bez náradia a bez viditeľných skrutiek.", [
            ("E2_modul.png", "modul", "Pohľad zozadu – diely posunuté od seba v poradí montáže", {
                "ram": "rám displeja – čierny lesklý,\nvonkajší tvar = tvar hlavy",
                "magnety": "6 magnetov N35 Ø4 × 2\n(protikusy v škrupine)",
                "vlozky": "mosadzné vložky M2\nzalepené v stĺpikoch rámu",
                "pena": "penový rámik 1,0 × 0,5\npod sklom",
                "sklo": "sklo displeja 92,44 × 61,00\n= tvár robota",
                "displej": "doska displeja,\n4 stĺpiky M2 (72,0 × 48,5)",
                "drziak": "2 lišty držiaka\n(tlačené, čierne)",
                "skrutky": "4× M2×5 do stĺpikov displeja\n+ 4× M2×6 do vložiek rámu",
            }),
        ]),
}
COL, IW, IH = 600, 1400, 1100
W = COL * 2 + IW
fT, fL = font(34), font(27, "Medium")
for fn_out, (title, intro, panels) in SHEETS.items():
    TOP = 250
    H = TOP + len(panels) * (IH + 90) + 40
    S = Image.new("RGB", (W, H), (246, 247, 245))
    d = ImageDraw.Draw(S)
    d.text((40, 36), title, font=font(58), fill=INK)
    d.multiline_text((40, 112), intro, font=font(27, "Regular"), fill=MUTED, spacing=8)
    y0 = TOP
    for fn, key, ptitle, labels in panels:
        im = Image.open(os.path.join(D, fn)).convert("RGB")
        d.text((COL, y0 + 8), ptitle, font=fT, fill=INK)
        yi = y0 + 70
        S.paste(im, (COL, yi))
        sides = {"L": [], "R": []}
        for k, txt in labels.items():
            if k not in A.get(key, {}):
                print("missing anchor", key, k)
                continue
            ax, ay = A[key][k]
            ax, ay = min(max(ax, 4), IW - 4), min(max(ay, 4), IH - 4)
            sides["L" if ax < IW * 0.5 else "R"].append([ay, ax, txt])
        for side, items in sides.items():
            items.sort()
            last = -1e9
            for it in items:
                n = it[2].count("\n") + 1
                ly = max(it[0] - 20, last)
                it.append(ly)
                last = ly + 36 * n + 34
            over = (items[-1][3] + 36 * (items[-1][2].count("\n") + 1) - IH) if items else 0
            if over > 0:
                for it in items:
                    it[3] -= over
            for ay, ax, txt, ly in items:
                px, py = COL + ax, yi + ay
                if side == "L":
                    tx = 24
                    w = max(d.textlength(t, font=fL) for t in txt.split("\n"))
                    ex = tx + w + 14
                else:
                    tx = COL + IW + 24
                    ex = tx - 14
                d.multiline_text((tx, yi + ly), txt, font=fL, fill=INK, spacing=6)
                d.line([(ex, yi + ly + 16), (px, py)], fill=ACCENT, width=4)
                d.ellipse([px - 8, py - 8, px + 8, py + 8], fill=ACCENT, outline=(255, 255, 255), width=3)
        y0 = yi + IH + 20
    S.save(os.path.join(OUT, fn_out))
    print("sheet", fn_out, S.size)
