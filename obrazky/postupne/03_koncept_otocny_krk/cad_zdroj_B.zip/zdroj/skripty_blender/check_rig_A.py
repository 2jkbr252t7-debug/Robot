"""verify the rigid-motion formulas used in the Blender rig against the builder's own posed geometry (A)"""
import sys, math
sys.path.insert(0, "/tmp/claude-0/gapwf/fin/A")
import build as M
from build123d import Axis, Location
def bb(s):
    b = s.bounding_box(); return [round(v, 3) for v in (b.min.X, b.min.Y, b.min.Z, b.max.X, b.max.Y, b.max.Z)]
P0 = M.parts(0.0)
for th in (40.0, -40.0):
    P = M.parts(th)
    t = math.radians(th); L = M.ZS - M.AXZ
    worst = 0
    for k, (s0, g) in P0.items():
        if g == "head":
            s1 = s0.rotate(Axis((0, 0, M.AXZ), (1, 0, 0)), th)
        elif g == "neck":
            s1 = s0
        elif g == "horn":
            s1 = s0.moved(Location((0, -L * math.sin(t), L * (math.cos(t) - 1))))
        elif g == "link":
            s1 = s0.rotate(Axis((0, M.R_ARM, M.AXZ), (1, 0, 0)), th)
        a, b = bb(s1), bb(P[k][0])
        d = max(abs(x - y) for x, y in zip(a, b))
        worst = max(worst, d)
        if d > 0.01:
            print("MISMATCH", th, k, g, a, b)
    print("tilt", th, "worst bbox diff", round(worst, 4), flush=True)
