"""Variant B rev. E2 – the hinge explained: (1) exploded view along the hinge axis, (2) horizontal section through the
hinge axis (assembled).  Writes E2_pant_rozlozeny.png, E2_pant_rez.png and anchors_pant.json (2-D label anchors).
Usage: blender-python hinge_E2.py <blend> <out_dir>"""
import bpy, bmesh, sys, os, json
from mathutils import Vector
from bpy_extras.object_utils import world_to_camera_view

BLEND, OUT = sys.argv[-2], sys.argv[-1]
bpy.ops.wm.open_mainfile(filepath=BLEND)
sc = bpy.context.scene
vl = bpy.context.view_layer
sc.frame_set(174)                                         # neck extended, tilt 0
AXZ = bpy.data.objects["naklon_B"].matrix_world.translation.z
sc.cycles.samples = int(os.environ.get("DET_SAMPLES", 64))
sc.render.resolution_x, sc.render.resolution_y = 1400, 1100
cam = sc.camera
for ob in bpy.data.objects:
    if ob.name.startswith("popis_"):
        ob.hide_render = ob.hide_viewport = True
top = [c for c in vl.layer_collection.children if c.name.startswith("B_")][0]
for lc in top.children:                                   # every collection on; visibility per object below
    lc.exclude = False
    lc.collection.hide_render = lc.collection.hide_viewport = False
    lc.hide_viewport = False
vl.update()


def bake(o):
    """clear the parent (keep the world matrix) so the object can be moved freely in world space"""
    mw = o.matrix_world.copy()
    o.parent = None
    o.matrix_world = mw


def split_loose(name):
    """separate an object into its loose parts; returns the new objects (world matrices kept)"""
    o = bpy.data.objects[name]
    bake(o)
    bpy.ops.object.select_all(action="DESELECT")
    o.hide_set(False); o.hide_viewport = False
    vl.objects.active = o
    o.select_set(True)
    bpy.ops.object.mode_set(mode="EDIT")
    bpy.ops.mesh.select_all(action="SELECT")
    bpy.ops.mesh.separate(type="LOOSE")
    bpy.ops.object.mode_set(mode="OBJECT")
    return [x for x in bpy.context.selected_objects]


def ctr(o):
    bb = [o.matrix_world @ Vector(c) for c in o.bound_box]
    return sum(bb, Vector()) / 8


# ---------------------------------------------------------------- separate horn screw / cross screws, pin / dowels
scr = split_loose("B_skrutky_hlava")
horn_screw = [o for o in scr if abs(ctr(o).y) < 1.0 and ctr(o).x < 0]
cross = [o for o in scr if o not in horn_screw]
for i, o in enumerate(horn_screw):
    o.name = f"X_skrutka_paky_{i}"
for i, o in enumerate(cross):
    o.name = f"X_skrutka_hlavy_{i}"
cap_parts = split_loose("B_capy")
pin = [o for o in cap_parts if abs(ctr(o).z - AXZ) < 1.0]
dowels = [o for o in cap_parts if o not in pin]
for i, o in enumerate(pin):
    o.name = f"X_dutý_čap_{i}"
for i, o in enumerate(dowels):
    o.name = f"X_kolik_{i}"
for n in ("B_paka", "B_klzny_kruzok", "B_usko_kryt", "B_usko_lozisko", "B_loziska_MR85_hlava", "B_loziska_MR85_krk",
          "B_servo_MG90S", "B_pena_serva", "B_krk_zadna_polovica", "B_krk_predna_polovica", "B_kabel_krk", "B_kabel_hlava",
          "B_skrutky_krk", "B_zatka_kabla", "B_kabel_serva_krk"):
    bake(bpy.data.objects[n])
vl.update()
SHOW1 = {"B_krk_zadna_polovica", "B_servo_MG90S", "B_pena_serva", "B_paka", "B_klzny_kruzok", "B_usko_kryt",
         "B_usko_lozisko", "B_loziska_MR85_hlava", "B_loziska_MR85_krk"} | {o.name for o in horn_screw + cross + pin}


def only(names):
    for o in bpy.data.objects:
        if o.type == "MESH":
            on = o.name in names
            o.hide_render = not on
            o.hide_viewport = not on
    vl.update()


def aim(tgt, off, lens):
    cam.location = tgt + Vector(off)
    cam.rotation_euler = (tgt - cam.location).to_track_quat("-Z", "Y").to_euler()
    cam.data.lens = lens
    vl.update()


def px(p):
    c = world_to_camera_view(sc, cam, p)
    return [round(c.x * sc.render.resolution_x, 1), round((1 - c.y) * sc.render.resolution_y, 1)]


def anchor(names, bias=(0.5, 0.5, 0.5)):
    dg = bpy.context.evaluated_depsgraph_get()
    P = []
    for n in names:
        o = bpy.data.objects.get(n)
        if o is None or not o.visible_get():
            continue
        me = o.evaluated_get(dg).to_mesh()
        P += [(o.matrix_world @ v.co, o) for v in me.vertices]
    if not P:
        print("ANCHOR MISSING", names)
        return None
    lo = Vector([min(p[i] for p, _ in P) for i in range(3)])
    hi = Vector([max(p[i] for p, _ in P) for i in range(3)])
    tgt = Vector([lo[i] + (hi[i] - lo[i]) * bias[i] for i in range(3)])
    cand = sorted(P, key=lambda q: (q[0] - tgt).length)[:800]
    eye = cam.matrix_world.translation
    for p, o in cand:
        d = p - eye
        hit, loc, nrm, idx, hob, mx = sc.ray_cast(dg, eye, d.normalized(), distance=d.length + 0.05)
        if hit and (hob.original if hasattr(hob, "original") else hob) == o and (loc - p).length < 0.6:
            return p
    print("ANCHOR not visible, nearest used", names)
    return cand[0][0]


res = {}
# ---------------------------------------------------------------- 1) exploded along the hinge axis (front half hidden)
only(SHOW1)
EXP = {"B_paka": (-9, 0, 0), "B_klzny_kruzok": (-25, 0, 0), "B_usko_kryt": (-35, 0, 0),
       "B_loziska_MR85_hlava": (10, 0, 0), "B_loziska_MR85_krk": (10, 0, 0), "B_usko_lozisko": (22, 0, 0)}
for o in horn_screw:
    EXP[o.name] = (-17, 0, 0)
for o in cross:
    EXP[o.name] = (-35 if ctr(o).x < 0 else 22, -9, 0)
saved = {}
for n, d in EXP.items():
    o = bpy.data.objects[n]
    saved[n] = o.location.copy()
    o.location += Vector(d)
vl.update()
aim(Vector((-5, 0, AXZ + 3)), (-115, -165, 78), 68)
L1 = {
    "krk": anchor(["B_krk_zadna_polovica"], (0.15, 0.6, 0.1)),
    "servo": anchor(["B_servo_MG90S"], (0.55, 0.0, 0.35)),
    "pena": anchor(["B_pena_serva"], (0.9, 0.0, 0.5)),
    "paka": anchor(["B_paka"], (0.5, 0.0, 0.85)),
    "skrutka": anchor([o.name for o in horn_screw], (0.0, 0.5, 0.5)),
    "ptfe": anchor(["B_klzny_kruzok"], (0.5, 0.2, 0.9)),
    "kryt": anchor(["B_usko_kryt"], (0.3, 0.0, 0.3)),
    "cap": anchor([o.name for o in pin], (0.7, 0.0, 0.5)),
    "lozisko": anchor(["B_loziska_MR85_hlava"], (0.5, 0.0, 0.8)),
    "usko": anchor(["B_usko_lozisko"], (0.6, 0.0, 0.3)),
    "skr_hlavy": anchor([o.name for o in cross if ctr(o).x > 0], (0.5, 0.0, 0.5)),
}
res["rozlozeny"] = {k: px(v) for k, v in L1.items() if v is not None}
sc.render.filepath = os.path.join(OUT, "E2_pant_rozlozeny.png")
bpy.ops.render.render(write_still=True)
for n, l in saved.items():
    bpy.data.objects[n].location = l
vl.update()
# ---------------------------------------------------------------- 2) assembled, cut VERTICALLY through the hinge axis
# (plane y = 0 = the neck parting plane; front half and everything in front of the plane removed), seen from the front
SHOW2 = (SHOW1 | {"B_kabel_krk", "B_kabel_hlava"}) - {o.name for o in cross}
only(SHOW2)
bpy.ops.mesh.primitive_cube_add(size=1)
box = bpy.context.active_object
box.scale = (200, 100, 200)
box.location = (0, -50 + 0.001, AXZ)
box.hide_render = box.hide_viewport = True
for n in SHOW2 - {"B_krk_zadna_polovica"}:
    o = bpy.data.objects[n]
    md = o.modifiers.new("ycut", "BOOLEAN")
    md.object, md.operation, md.solver = box, "DIFFERENCE", "EXACT"
vl.update()
aim(Vector((0, 0, AXZ + 5)), (-20, -175, 38), 90)
L2 = {
    "servo": anchor(["B_servo_MG90S"], (0.6, 1.0, 0.3)),
    "pena": anchor(["B_pena_serva"], (0.95, 1.0, 0.5)),
    "paka": anchor(["B_paka"], (0.5, 1.0, 0.95)),
    "skrutka": anchor([o.name for o in horn_screw], (0.1, 1.0, 0.5)),
    "kryt": anchor(["B_usko_kryt"], (0.2, 1.0, 0.2)),
    "ptfe": anchor(["B_klzny_kruzok"], (0.5, 1.0, 0.1)),
    "cap": anchor([o.name for o in pin], (0.3, 1.0, 0.0)),
    "lozisko": anchor(["B_loziska_MR85_hlava"], (0.5, 1.0, 0.0)),
    "usko": anchor(["B_usko_lozisko"], (0.85, 1.0, 0.15)),
    "vodice": anchor(["B_kabel_hlava"], (0.5, 0.5, 0.9)),
    "polovice": anchor(["B_krk_zadna_polovica"], (0.22, 0.5, 0.45)),
}
res["rez"] = {k: px(v) for k, v in L2.items() if v is not None}
sc.render.filepath = os.path.join(OUT, "E2_pant_rez.png")
bpy.ops.render.render(write_still=True)
json.dump(res, open(os.path.join(OUT, "anchors_pant.json"), "w"), indent=1)
print("DONE", json.dumps(res))
