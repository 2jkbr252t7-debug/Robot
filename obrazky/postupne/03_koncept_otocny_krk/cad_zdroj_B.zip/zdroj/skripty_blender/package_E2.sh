#!/bin/bash
# Variant B rev. E2 packaging: copy the finished renders / blend / glb / STL / docs from finalB_E2 into the repo.
set -euo pipefail
S=/tmp/claude-0/-home-user-Robot/e2af8646-c6f1-5ece-963d-7005cfdf5589/scratchpad
F=/tmp/claude-0/gapwf/fin
R=/home/user/Robot/obrazky/postupne/03_koncept_otocny_krk
O=$S/finalB_E2
cd $O
# ---------------------------------------------------------------- composite images
/opt/venv/cad/bin/python - "$O" <<'EOF'
import sys, os
from PIL import Image, ImageDraw
sys.path.insert(0, "/home/user/Robot")
from nova.render.sheet import font, INK, MUTED
O = sys.argv[1]
# animation frames 2 x 2 with captions
cap = [("f001.png", "pokoj – krk zasunutý"), ("f048.png", "otočenie doboku"),
       ("f210.png", "krk vysunutý, náklon 40° dole"), ("f288.png", "krk vysunutý, náklon 40° hore")]
ims = [Image.open(os.path.join(O, "prev", f)).convert("RGB") for f, _ in cap]
w, h = ims[0].size
S = Image.new("RGB", (w * 2, h * 2 + 150), (246, 247, 245)); d = ImageDraw.Draw(S)
d.text((30, 30), "NOVA mini · verzia B (E2) – pohyby hlavy", font=font(52), fill=INK)
for i, (im, (_, t)) in enumerate(zip(ims, cap)):
    x, y = (i % 2) * w, 150 + (i // 2) * h
    S.paste(im, (x, y)); d.text((x + 24, y + 16), t, font=font(30, "Medium"), fill=INK)
S.save(os.path.join(O, "NOVA_mini_B_animacia.png"))
# close-ups 4 x 2
cl = sorted(f for f in os.listdir(os.path.join(O, "close")) if f.endswith(".png"))
names = {"01": "pokoj, spredu", "02": "pokoj, zboku", "03": "pokoj, zozadu", "04": "krk vysunutý – detail",
         "05": "náklon dole, zdola", "06": "náklon hore, zozadu", "07": "krk vysunutý, zboku", "08": "spodok hlavy pri náklone", "09": "pokoj, zozadu zdola"}
ims = [Image.open(os.path.join(O, "close", f)).convert("RGB") for f in cl]
w, h = ims[0].size
cols = 4; rows = (len(ims) + cols - 1) // cols
S = Image.new("RGB", (w * cols, h * rows + 150), (246, 247, 245)); d = ImageDraw.Draw(S)
d.text((30, 30), "NOVA mini · verzia B (E2) – povrch zblízka", font=font(52), fill=INK)
for i, (im, f) in enumerate(zip(ims, cl)):
    x, y = (i % cols) * w, 150 + (i // cols) * h
    S.paste(im, (x, y)); d.text((x + 20, y + 14), names.get(f[:2], f), font=font(28, "Medium"), fill=INK)
S.save(os.path.join(O, "NOVA_mini_B_povrch_detaily.png"))
Image.open(os.path.join(O, "prev", "rez_B.png")).convert("RGB").save(os.path.join(O, "NOVA_mini_B_rez.png"))
print("composites ok")
EOF
# ---------------------------------------------------------------- repo
cd /home/user/Robot
git rm -r -q --ignore-unmatch "$R/stl/A_servo_v_hlave" "$R/stl/B_servo_v_krku" "$R/model_3d/NOVA_mini_A_servo_v_hlave.glb" \
  "$R/NOVA_mini_STL_A_B.zip"
rm -rf "$R/stl/A_servo_v_hlave" "$R/stl/B_servo_v_krku"
mkdir -p "$R/stl/B_servo_v_krku" "$R/model_3d"
for f in $F/B/stl/*.stl; do case "$(basename $f)" in CELOK_*) ;; *) cp "$f" "$R/stl/B_servo_v_krku/";; esac; done
cp $O/celok_glb/CELOK_*.glb "$R/stl/B_servo_v_krku/"     # viewing assemblies: smooth normals + colours
cp $F/B/montaz.txt "$R/stl/B_servo_v_krku/montaz.txt"
cp $F/B/ZMENY_E2.md "$R/stl/B_servo_v_krku/ZMENY_E2.md"
cp $F/B/checks.json "$R/stl/B_servo_v_krku/kontroly.json"
cp $S/stl_README_E2.txt "$R/stl/README.txt"
cp $O/NOVA_mini_B.blend "$R/NOVA_mini_B.blend"
cp $O/NOVA_mini_B_animacia.png $O/NOVA_mini_B_povrch_detaily.png $O/NOVA_mini_B_rez.png \
   $O/NOVA_mini_B_servo_a_kabel.png $O/NOVA_mini_B_modul_displeja.png "$R/"
cp $S/viewer/nova_b.glb "$R/model_3d/NOVA_mini_B_servo_v_krku.glb"
sed 's#"nova_b.txt"#"NOVA_mini_B_servo_v_krku.glb"#' $S/viewer/hlava_nova.html > "$R/model_3d/prehliadac.html"
# CAD sources (absolute paths of the build machine; see zdroj/CITAJ.txt)
mkdir -p $S/src_pack/zdroj/skripty_blender
cp $S/export_rig.py $S/make_blend_v3.py $S/to_glb3.py $S/detail_E2.py $S/sheet_E2.py $S/closeups_B.py \
   $S/package_E2.sh $S/src_pack/zdroj/skripty_blender/
rm -f "$R/cad_zdroj_B.zip"
(cd /tmp/claude-0 && zip -q -r "$R/cad_zdroj_B.zip" gapwf/fin/B/build.py gapwf/fin/B/checks*.py gapwf/fin/common/head_common.py \
   gapwf/c_hn3/*.py gapwf/c_hn4/*.py pan16/softhead.py gapwf/fin/E2/E2_spec.md gapwf/fin/E2/E1_exterior_spec.md)
(cd $S/src_pack && zip -q -r "$R/cad_zdroj_B.zip" zdroj)
# zip for the user: STL folder + README + blend
rm -f "$R/NOVA_mini_B_STL.zip"
(cd "$R" && zip -q -r NOVA_mini_B_STL.zip stl/README.txt stl/B_servo_v_krku NOVA_mini_B.blend)
du -sh "$R/NOVA_mini_B_STL.zip" "$R/NOVA_mini_B.blend" "$R/cad_zdroj_B.zip" "$R/model_3d/NOVA_mini_B_servo_v_krku.glb"
