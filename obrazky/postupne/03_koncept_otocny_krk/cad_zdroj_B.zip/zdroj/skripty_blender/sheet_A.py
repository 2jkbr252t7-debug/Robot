"""Labelled sheet: variant A – servo mounting in the head (Slovak).  Usage: python sheet_A.py <det_dir> <out.png>"""
import sys, json, os
sys.path.insert(0, "/home/user/Robot")
from PIL import Image, ImageDraw
from nova.render.sheet import font, INK, MUTED, ACCENT

D, OUT = sys.argv[1], sys.argv[2]
A = json.load(open(os.path.join(D, "anchors.json")))
PANELS = [
    ("A_zhora.png", "zhora", "Pohľad zhora – vrch hlavy odrezaný nad servom", {
        "servo": "servo MG90S",
        "skrutka_predna": "2 skrutky 2,0 × 6 cez úchyty\nserva (predná je vidieť,\nzadná je skrytá za servom)",
        "doska": "doska úchytov – vytlačená\nspolu s hlavou",
        "objimka": "C-objímka drží servo\npri hriadeli",
        "rameno": "rameno serva – odtiaľ ide\ntiahlo dole do ľavého uška",
    }),
    ("A_spredu.png", "spredu", "Rez spredu – krk vysunutý, hlava v 0°", {
        "servo": "servo sa zasunie zľava\ncez dosku úchytov",
        "kolíska": "kolíska: doska + objímka +\n3 rebrá spojené s uškami\n(jeden kus s hlavou)",
        "lozisko": "ložisko MR85 v nosiči uška",
        "paka": "páka pevne na čape krku –\nservo sa o ňu cez tiahlo opiera",
        "cap": "oceľový čap Ø5 v krku",
        "kabel": "kábel dutým čapom\ndo krku",
        "krk": "krk (predná polovica odrezaná)",
    }),
]
COL, IW, IH, GAP = 600, 1400, 1100, 30
W = COL * 2 + IW
TOP = 210
H = TOP + len(PANELS) * (IH + 90) + 40
S = Image.new("RGB", (W, H), (246, 247, 245))
d = ImageDraw.Draw(S)
d.text((40, 36), "NOVA mini · verzia A – uloženie a upevnenie serva v hlave", font=font(58), fill=INK)
d.multiline_text((40, 108), "Servo leží v kolíske, ktorá je vytlačená spolu so škrupinou hlavy. Drží ho doska úchytov "
                 "s 2 skrutkami a C-objímka pri hriadeli.\nNáklon hlavy: rameno serva → tiahlo → páka pevne na čape krku "
                 "(servo sa o ňu opiera, a tak nakláňa celú hlavu).", font=font(27, "Regular"), fill=MUTED, spacing=8)
fT, fL = font(34), font(27, "Medium")
y0 = TOP
for fn, key, title, labels in PANELS:
    im = Image.open(os.path.join(D, fn)).convert("RGB")
    d.text((COL, y0 + 8), title, font=fT, fill=INK)
    yi = y0 + 70
    S.paste(im, (COL, yi))
    sides = {"L": [], "R": []}
    for k, txt in labels.items():
        ax, ay = A[key][k]
        sides["L" if ax < IW * 0.5 else "R"].append([ay, ax, txt])
    for side, items in sides.items():
        items.sort()
        last = -1e9
        for it in items:
            ly = max(it[0] - 20, last + 110)
            it.append(ly)
            last = ly
        over = (items[-1][3] + 80 - IH) if items else 0          # keep the column inside the panel
        if over > 0:
            for it in items:
                it[3] -= over
        for ay, ax, txt, ly in items:
            px, py = COL + ax, yi + ay
            if side == "L":
                tx = 24
                w = max(d.textlength(t, font=fL) for t in txt.split("\n"))
                ex = tx + w + 14
            else:
                tx = COL + IW + 24
                ex = tx - 14
            d.multiline_text((tx, yi + ly), txt, font=fL, fill=INK, spacing=6)
            d.line([(ex, yi + ly + 16), (px, py)], fill=ACCENT, width=4)
            d.ellipse([px - 8, py - 8, px + 8, py + 8], fill=ACCENT, outline=(255, 255, 255), width=3)
    y0 = yi + IH + 20
S.save(OUT)
print("sheet", OUT, S.size)
