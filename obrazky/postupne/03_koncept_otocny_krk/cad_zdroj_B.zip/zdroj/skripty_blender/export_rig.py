"""Export every part of variant A or B in the EXTENDED pose (lift 0, tilt 0), split by motion group, for the
animated Blender rig.  Usage: /opt/venv/cad/bin/python export_rig.py A|B <outdir>
rig.json: constants of the kinematics + list of objects {name, group, file}."""
import sys, os, json, importlib.util, time
var, OUT = sys.argv[1], sys.argv[2]
os.makedirs(OUT, exist_ok=True)
t0 = time.time()


def load(name, path):
    s = importlib.util.spec_from_file_location(name, path)
    m = importlib.util.module_from_spec(s)
    sys.modules[name] = m
    s.loader.exec_module(m)
    return m


from build123d import Compound, export_stl

objs = []


def put(name, group, shapes):
    shapes = [s for s in shapes if s is not None]
    if not shapes:
        return
    s = shapes[0] if len(shapes) == 1 else Compound(shapes)
    fn = f"{name}__{group}.stl"
    export_stl(s, os.path.join(OUT, fn), tolerance=0.01, angular_tolerance=0.1)
    objs.append(dict(name=name, group=group, file=fn, valid=bool(s.is_valid)))
    print(f"[{time.time() - t0:5.0f}s] {fn}", flush=True)


if var == "A":
    D = "/tmp/claude-0/gapwf/fin/A"
    sys.path.insert(0, D)
    import build as M                                       # noqa: E402  (fin/A/build.py, round 2/3 geometry)
    import ast                                              # GROUPS straight from fin/A/export.py (no drift)
    _src = open(f"{D}/export.py").read()
    _t = ast.parse(_src)
    GROUPS = next(ast.literal_eval(n.value) for n in _t.body if isinstance(n, ast.Assign)
                  and getattr(n.targets[0], "id", "") == "GROUPS")
    P = M.parts(0.0)
    used = set()
    for name, keys in GROUPS.items():
        by = {}
        for k in keys:
            s, g = P[k]
            by.setdefault(g, []).append(s)
            used.add(k)
        for g, lst in by.items():
            put(name, g, lst)
    missing = sorted(set(P) - used)
    R = M.R
    meta = dict(var="A", LIFT=M.LIFT, AXZ=M.AXZ, ZS=M.ZS, R_ARM=M.R_ARM, HZ=M.HZ, missing=missing,
                groups={"head": "rotates with the head about (y 0, z AXZ)", "neck": "lifts only",
                        "horn": "translates with the servo shaft (0, -(ZS-AXZ) sin t, AXZ + (ZS-AXZ) cos t - ZS)",
                        "link": "rotates by t about (y R_ARM, z AXZ)"})
else:
    D = "/tmp/claude-0/gapwf/fin/B"
    M = load("nova_b_build", f"{D}/build.py")
    P = M.build_all()
    # E2: registry entries that hold differently coloured / separately shown items -> own objects
    SPLIT = {("displej", 0): "displej_sklo", ("magnety", 1): "magnety_skrupina", ("skrutky", 3): "skrutky_drziaka",
             ("skrutky", 4): "vlozky", ("kabel", 2): "kabel_serva", ("kabel", 3): "kabel_serva",
             ("pena_serva", 1): "zatka_kabla"}
    for name, lst in P.items():
        by = {}
        for i, (s, g) in enumerate(lst):
            by.setdefault((SPLIT.get((name, i), name), g), []).append(s)
        for (nm, g), shapes in by.items():
            put(nm, g, shapes)
    meta = dict(var="B", LIFT=M.LIFT, AXZ=M.AXZ, HZ=M.HZ, missing=[],
                groups={"H": "rotates with the head about (y 0, z AXZ), servo shaft on that axis",
                        "N": "lifts only", "T": "torso (static, pan only for the collar disc)"})
meta["objects"] = objs
json.dump(meta, open(os.path.join(OUT, "rig.json"), "w"), indent=1)
print("DONE", var, len(objs), "missing", meta["missing"], round(time.time() - t0), "s", flush=True)
