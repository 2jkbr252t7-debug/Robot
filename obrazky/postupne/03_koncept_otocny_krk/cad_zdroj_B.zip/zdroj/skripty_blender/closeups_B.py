"""Exterior close-ups of variant B for a surface-quality review (visor/shell seam, ears, neck, hinge, underside).
Usage: blender-python closeups_B.py <blend> <out_dir> [res] [samples]"""
import bpy, sys, os, math
from mathutils import Vector

args = sys.argv[sys.argv.index("--") + 1:] if "--" in sys.argv else sys.argv[1:]
BLEND, OUT = args[0], args[1]
RES = int(args[2]) if len(args) > 2 else 900
SMP = int(args[3]) if len(args) > 3 else 32
bpy.ops.wm.open_mainfile(filepath=BLEND)
sc = bpy.context.scene
vl = bpy.context.view_layer
for ob in bpy.data.objects:
    if ob.name.startswith("popis_"):
        ob.hide_render = True
sc.cycles.samples = SMP
sc.render.resolution_x, sc.render.resolution_y = RES, int(RES * 0.8)
cam = sc.camera
cam.data.lens = 70
DX = bpy.data.objects["zaklad_B"].matrix_world.translation.x
SHOTS = [  # name, frame, target (rel), camera offset
    ("01_pokoj_spredu_34", 1, (0, 0, 45), (-150, -260, 70)),
    ("02_pokoj_zboku", 1, (0, 0, 45), (-300, 0, 30)),
    ("03_pokoj_zozadu_34", 1, (0, 0, 45), (170, 250, 90)),
    ("04_vysunute_krk_detail", 174, (0, 0, 20), (-90, -150, 35)),
    ("05_naklon_dole_zdola", 210, (0, -5, 40), (-120, -220, -20)),
    ("06_naklon_hore_zozadu", 288, (0, 5, 40), (120, 220, 10)),
    ("07_vysunute_zboku_detail", 174, (0, 0, 20), (-170, -10, 15)),
    ("08_hlava_spodok_naklon", 288, (0, 0, 30), (-60, -140, -40)),
    ("09_pokoj_zozadu_zdola", 1, (0, 0, 40), (-130, 190, -25)),
]
ONLY_SHOTS = [x for x in os.environ.get("SHOTS_ONLY", "").split(",") if x]
for name, f, t, off in SHOTS:
    if ONLY_SHOTS and name[:2] not in ONLY_SHOTS:
        continue
    sc.frame_set(f)
    tgt = Vector((DX + t[0], t[1], t[2]))
    cam.location = tgt + Vector(off)
    cam.rotation_euler = (tgt - cam.location).to_track_quat("-Z", "Y").to_euler()
    vl.update()
    sc.render.filepath = os.path.join(OUT, name + ".png")
    bpy.ops.render.render(write_still=True)
    print("SHOT", name, flush=True)
