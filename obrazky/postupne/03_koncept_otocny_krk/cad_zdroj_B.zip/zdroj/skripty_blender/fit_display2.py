"""Official Waveshare 3.5B outline (glass 92.44 x 61.00 R6.0) vs head sections. Pure numpy (superellipse radial margin).
margin > 0 = the glass outline stays inside the given section by that many mm (radially)."""
import math, numpy as np
D, RF = 66.0, 9.0
def factor(y, F=0.86):
    YF = -D / 2; f = 1.0
    if y < YF + RF:
        s = min(1.0, ((YF + RF) - y) / RF); f = F + (1 - F) * math.sqrt(max(0.0, 1 - s * s))
    return f
def margin(W, H, N, y, shrink, GW=92.44, GH=61.0, R=6.0, F=0.86):
    k = factor(y, F); a, b = W / 2 * k - shrink, H / 2 * (0.25 + 0.75 * k) - shrink
    worst = 1e9
    for kk in range(0, 91, 1):
        t = math.radians(kk); x = GW / 2 - R + R * math.cos(t); z = GH / 2 - R + R * math.sin(t)
        ang = math.atan2(z, x); c, s = abs(math.cos(ang)), abs(math.sin(ang))
        rr = ((c / a) ** N + (s / b) ** N) ** (-1 / N)
        worst = min(worst, rr - math.hypot(x, z))
    return worst
print("A) glass BEHIND a visor at y=-26.9..-25.8 (as now): margin to INNER wall (2.5) / to outer skin")
for W, H, N in ((108, 77, 3.6), (108, 77, 4.2), (108, 77, 5.0), (110, 79, 3.6), (110, 79, 4.2), (112, 80, 3.6)):
    print(f"  head {W}x{H} N{N}:  inner {margin(W, H, N, -26.9, 2.5):+.2f}   outer {margin(W, H, N, -26.9, 0):+.2f}")
print("   old model outline 86x56 R2 in 108x77 N3.6: inner", round(margin(108, 77, 3.6, -26.9, 2.5, 86, 56, 2), 2))
print("B) glass FLUSH in the front face (y=-33): margin of the glass outline to the edge of the flat front face")
for W, H, N, F in ((108, 77, 3.6, 0.86), (108, 77, 5.0, 0.90), (110, 79, 5.0, 0.90), (112, 80, 5.0, 0.90), (112, 80, 6.0, 0.92), (114, 82, 5.0, 0.90), (114, 82, 6.0, 0.92)):
    k = F; print(f"  head {W}x{H} N{N} front factor {F}: flat face {W*k:.1f} x {H*(0.25+0.75*k):.1f}  margin {margin(W, H, N, -33.0, 0, F=F):+.2f}")
print("C) glass 1.1 behind the front face plane (y=-31.9), i.e. flush glass, wall beside the glass back edge")
for W, H, N, F in ((110, 79, 5.0, 0.90), (112, 80, 5.0, 0.90), (112, 80, 6.0, 0.92)):
    print(f"  head {W}x{H} N{N} F{F}: outer skin margin at glass back plane {margin(W, H, N, -31.9, 0, F=F):+.2f}")
