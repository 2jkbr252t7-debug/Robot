"""GLB for the interactive viewer, built from the same rig STLs as the .blend (extended pose, split by motion group).
Mesh names: '<part>__<group>' (group head/neck/horn/link for A, H/N for B, T for torso parts).
Usage: blender-python to_glb3.py <rigdir> <restdir> <outdir>"""
import bpy, os, sys, json, base64
RIG, REST, OUT = sys.argv[-3], sys.argv[-2], sys.argv[-1]
DEC = {"kabel": 0.35, "skrutky": 0.5, "trup": 0.5}
ONLY = os.environ.get("NOVA_ONLY")
for V, var in [x for x in (("A", "A_servo_v_hlave"), ("B", "B_servo_v_krku")) if not ONLY or x[0] == ONLY]:
    bpy.ops.wm.read_factory_settings(use_empty=True)
    meta = json.load(open(os.path.join(RIG, V, "rig.json")))
    items = [(os.path.join(RIG, V, o["file"]), o["name"], o["group"]) for o in meta["objects"] if o["group"] != "T"]
    items += [(os.path.join(REST, var, n + ".stl"), n, "T") for n in ("trup", "golier_prstenec", "golier_kotuc")]
    for path, n, g in items:
        bpy.ops.wm.stl_import(filepath=path)
        o = bpy.context.selected_objects[0]
        o.name = o.data.name = f"{n}__{g}"
        o.scale = (0.001, 0.001, 0.001)
        bpy.context.view_layer.objects.active = o
        try:
            bpy.ops.object.shade_smooth_by_angle(angle=0.6)
        except Exception as ex:
            print("smooth", n, ex)
        if n in DEC:
            m = o.modifiers.new("dec", "DECIMATE"); m.ratio = DEC[n]
    bpy.ops.object.select_all(action="SELECT")
    bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    out = os.path.join(OUT, f"nova_{V.lower()}.glb")
    bpy.ops.export_scene.gltf(filepath=out, export_format="GLB", export_apply=True, export_yup=False,
                              export_normals=True, export_materials="NONE", use_selection=False)
    data = open(out, "rb").read()
    open(out[:-4] + ".txt", "w").write(base64.b64encode(data).decode())
    print("glb", V, len(data), [o.name for o in bpy.data.objects])
