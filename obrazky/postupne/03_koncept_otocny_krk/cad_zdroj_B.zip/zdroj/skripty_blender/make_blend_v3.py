"""NOVA mini – animated Blender scene with both tilt variants side by side.
A (servo in the head, 1:1 parallelogram) at x = -170, B (servo in the neck, direct drive) at x = +170.
Parts come from export_rig.py (extended pose, split by motion group) + static torso/collar from the rest-pose STLs.
Rig per variant:  zaklad_X (static) > otacanie_X (pan, Z) > zdvih_X (lift) > naklon_X (tilt about the hinge axis)
                  A only: rameno_X (servo horn: translates with the servo shaft), tiahlo_X (link: rotates about the
                  lever pin).  Keyframes are baked on every frame (linear), the same pose curve for A and B.
Section toggle: object 'rez_A' / 'rez_B' (box) + Boolean modifiers on the head exterior, disabled by default.
Usage: blender-python make_blend_v3.py <rigdir with A/ B/> <restdir with A_servo_v_hlave/ B_servo_v_krku/> <out.blend>
       [--preview <dir>]
"""
import bpy, os, sys, json, math
from mathutils import Vector, Matrix

argv = sys.argv[sys.argv.index("--") + 1:] if "--" in sys.argv else sys.argv[1:]
PREV = None
ONLY = None
if "--only" in argv:
    i = argv.index("--only"); ONLY = argv[i + 1]; argv = argv[:i] + argv[i + 2:]
if "--preview" in argv:
    i = argv.index("--preview"); PREV = argv[i + 1]; argv = argv[:i] + argv[i + 2:]
RIG, REST, OUT = argv[-3], argv[-2], argv[-1]
bpy.ops.wm.read_factory_settings(use_empty=True)
scene = bpy.context.scene


def mat(name, rgb, rough=0.4, metal=0.0, emit=None, alpha=1.0, coat=0.0):
    m = bpy.data.materials.new(name)
    m.use_nodes = True
    b = m.node_tree.nodes["Principled BSDF"]
    b.inputs["Base Color"].default_value = (*rgb, 1)
    b.inputs["Roughness"].default_value = rough
    b.inputs["Metallic"].default_value = metal
    if coat:
        b.inputs["Coat Weight"].default_value = coat
    if emit:
        b.inputs["Emission Color"].default_value = (*emit, 1)
        b.inputs["Emission Strength"].default_value = 4.0
    if alpha < 1.0:
        b.inputs["Alpha"].default_value = alpha
        try:
            m.surface_render_method = "BLENDED"
        except Exception:
            pass
    m.diffuse_color = (*rgb, alpha)
    m.roughness, m.metallic = rough, metal
    return m


M = dict(
    biela=mat("biela_zivica", (0.82, 0.83, 0.82), 0.35, coat=0.3),
    satin=mat("cierna_saten", (0.025, 0.025, 0.03), 0.55),
    leskla=mat("cierna_leskla", (0.01, 0.01, 0.012), 0.06, coat=1.0),
    sklo=mat("sklo_displeja", (0.004, 0.004, 0.006), 0.03, coat=1.0),
    led=mat("led_tyrkys", (0.35, 0.85, 0.95), 0.3, emit=(0.3, 0.85, 0.95)),
    oci=mat("oci_displej", (1.0, 0.93, 0.80), 0.3, emit=(1.0, 0.90, 0.72)),
    kov=mat("ocel", (0.72, 0.73, 0.75), 0.25, 0.95),
    mosadz=mat("mosadz", (0.80, 0.62, 0.30), 0.3, 0.95),
    servo=mat("servo_modre", (0.10, 0.22, 0.70), 0.45),
    rameno=mat("rameno_biele", (0.92, 0.92, 0.90), 0.5),
    pcb=mat("doska_plosneho_spoja", (0.03, 0.12, 0.32), 0.5),
    kabel=mat("kabel_cerveny", (0.6, 0.08, 0.06), 0.6),
    pena=mat("pena_seda", (0.18, 0.18, 0.2), 0.9),
)
PART_MAT = {
    "hlava_skrupina": "biela", "trup": "biela", "ram_displeja": "leskla", "displej_sklo": "sklo", "displej": "pcb",
    "pena_displeja": "pena", "drziak_displeja": "satin", "magnety": "kov", "magnety_skrupina": "kov",
    "usi": "satin", "led_kruzky": "led", "led_dosky": "pcb", "oci_len_vizualizacia": "oci",
    "usko_kryt": "satin", "usko_lozisko": "satin", "paka": "rameno", "klzny_kruzok": "rameno",
    "servo_MG90S": "servo", "pena_serva": "pena", "zatka_kabla": "satin", "loziska_MR85": "kov", "capy": "kov",
    "skrutky": "kov", "skrutky_drziaka": "kov", "vlozky": "mosadz", "kabel": "kabel", "kabel_serva": "satin",
    "krk_predna_polovica": "satin", "krk_zadna_polovica": "satin", "golier_kotuc": "satin", "golier_prstenec": "satin",
}
EXTERIOR = {"hlava_skrupina", "ram_displeja", "displej_sklo", "usi", "led_kruzky", "usko_kryt", "usko_lozisko",
            "krk_predna_polovica", "krk_zadna_polovica", "golier_kotuc", "golier_prstenec", "oci_len_vizualizacia"}
HIDDEN = set()
GL = {"head": "hlava", "neck": "krk", "horn": "rameno", "link": "tiahlo", "H": "hlava", "N": "krk", "T": "trup"}
DISPLAY = {"displej", "pena_displeja", "drziak_displeja", "magnety", "magnety_skrupina", "led_dosky", "vlozky",
           "skrutky_drziaka"}
CUT = {"hlava_skrupina", "ram_displeja", "displej_sklo", "displej", "pena_displeja", "drziak_displeja",
       "oci_len_vizualizacia", "usi", "led_kruzky", "led_dosky", "usko_kryt", "usko_lozisko", "krk_predna_polovica",
       "krk_zadna_polovica", "magnety", "magnety_skrupina", "vlozky", "skrutky_drziaka"}


def import_stl(path):
    bpy.ops.wm.stl_import(filepath=path)
    o = bpy.context.selected_objects[0]
    for c in list(o.users_collection):
        c.objects.unlink(o)
    return o


def smooth(o):
    bpy.context.view_layer.objects.active = o
    o.select_set(True)
    try:
        bpy.ops.object.shade_smooth_by_angle(angle=math.radians(35))
    except Exception as e:
        print("smooth failed", o.name, e)
    o.select_set(False)


def new_col(name, parent):
    c = bpy.data.collections.new(name)
    parent.children.link(c)
    return c


def empty(name, col, parent=None, loc=(0, 0, 0), size=6.0, kind="PLAIN_AXES"):
    e = bpy.data.objects.new(name, None)
    e.empty_display_type, e.empty_display_size = kind, size
    col.objects.link(e)
    if parent:
        e.parent = parent
    e.location = loc
    return e


def parent_keep(o, p):
    bpy.context.view_layer.update()
    mw = o.matrix_world.copy()
    o.parent = p
    o.matrix_parent_inverse = p.matrix_world.inverted()
    bpy.context.view_layer.update()
    assert (o.matrix_world.translation - mw.translation).length < 1e-4, o.name


# ------------------------------------------------------------------ pose curve (same for A and B)
KEYS = [  # frame, pan deg, lift 0=rest..1=extended, tilt deg (+ = face down)
    (1, 0, 0, 0), (12, 0, 0, 0), (48, 35, 0, 0), (96, -35, 0, 0), (120, 0, 0, 0), (132, 0, 0, 0),
    (162, 0, 1, 0), (174, 0, 1, 0), (210, 0, 1, 40), (228, 0, 1, 40), (288, 0, 1, -40), (306, 0, 1, -40),
    (336, 0, 1, 0), (348, 0, 1, 0), (378, 0, 0, 0), (396, 0, 0, 0)]
MARKERS = [(1, "pokoj (krk zasunuty)"), (12, "otacanie do stran"), (132, "vysunutie krku"),
           (174, "naklon dole 40"), (228, "naklon hore 40"), (306, "spat na 0"), (348, "zasunutie krku")]


def pose_at(f):
    for (f0, *a), (f1, *b) in zip(KEYS, KEYS[1:]):
        if f0 <= f <= f1:
            u = (f - f0) / (f1 - f0)
            u = u * u * (3 - 2 * u)
            return [x + (y - x) * u for x, y in zip(a, b)]
    return list(KEYS[-1][1:])


rig_all = {}
labels = []
VARIANTS = [("A", "A_servo_v_hlave", -170.0), ("B", "B_servo_v_krku", 170.0)]
if ONLY:
    VARIANTS = [(V, var, 0.0) for V, var, dx in VARIANTS if V == ONLY]
for V, var, dx in VARIANTS:
    meta = json.load(open(os.path.join(RIG, V, "rig.json")))
    top = new_col(f"{V}_{var}", scene.collection)
    cols = {k: new_col(f"{V}_{k}", top) for k in ("1_obal", "2_displej", "3_mechanika", "4_trup", "5_rez", "6_osi")}
    rc = cols["6_osi"]
    base = empty(f"zaklad_{V}", rc, loc=(dx, 0, 0), size=20, kind="ARROWS")
    pan = empty(f"otacanie_{V}", rc, base, size=12, kind="CIRCLE")
    pan.rotation_euler = (0, 0, 0)
    lift = empty(f"zdvih_{V}", rc, pan, size=8, kind="SINGLE_ARROW")
    tilt = empty(f"naklon_{V}", rc, lift, loc=(0, 0, meta["AXZ"]), size=10)
    E = {"head": tilt, "H": tilt, "neck": lift, "N": lift}
    if V == "A":
        E["horn"] = empty(f"rameno_{V}", rc, lift, size=4)
        E["link"] = empty(f"tiahlo_{V}", rc, lift, loc=(0, meta["R_ARM"], meta["AXZ"]), size=4)
    bpy.context.view_layer.update()
    names = [(o["name"], o["group"], o["file"]) for o in meta["objects"] if o["group"] != "T"]   # T = torso: from REST
    multi = {n for n, g, f in names if sum(1 for m in names if m[0] == n) > 1}
    objs = {}
    for n, g, fn in names:
        o = import_stl(os.path.join(RIG, V, fn))
        o.name = f"{V}_{n}" + (f"_{GL[g]}" if n in multi else "")
        o.location.x += dx
        col = cols["1_obal"] if n in EXTERIOR else cols["2_displej"] if n in DISPLAY else cols["3_mechanika"]
        col.objects.link(o)
        o.data.materials.clear()
        o.data.materials.append(M[PART_MAT[n]])
        smooth(o)
        parent_keep(o, E[g])
        if (V, n) in HIDDEN:
            o.hide_set(True); o.hide_render = True
        objs[o.name] = (o, n)
    # static torso + collar from the rest-pose deliverables (group T); the collar disc turns with the pan
    for n in ("trup", "golier_prstenec", "golier_kotuc"):
        o = import_stl(os.path.join(REST, var, n + ".stl"))
        o.name = f"{V}_{n}"
        o.location.x += dx
        (cols["4_trup"] if n == "trup" else cols["1_obal"]).objects.link(o)
        o.data.materials.clear(); o.data.materials.append(M[PART_MAT[n]])
        smooth(o)
        parent_keep(o, pan if n == "golier_kotuc" else base)
        objs[o.name] = (o, n)
    # section copies (collection X_5_rez, hidden): head/neck exterior + display stack cut open in front of y = -1
    bpy.context.view_layer.update()
    bpy.ops.mesh.primitive_cube_add(size=1)
    cut = bpy.context.active_object
    for c in list(cut.users_collection):
        c.objects.unlink(cut)
    rc.objects.link(cut)
    cut.scale = (200, 120, 300)
    cut.location = (dx, -1.0 - 60, meta["AXZ"])       # extended pose, tilt 0 (setup state)
    bpy.context.view_layer.update()
    dg = bpy.context.evaluated_depsgraph_get()
    rez_objs = {}
    for on, (o, n) in list(objs.items()):
        if n not in CUT or (V, n) in HIDDEN:
            continue
        md = o.modifiers.new("rez", "BOOLEAN")
        md.object, md.operation, md.solver = cut, "DIFFERENCE", "EXACT"
        dg = bpy.context.evaluated_depsgraph_get()
        me = bpy.data.meshes.new_from_object(o.evaluated_get(dg))
        o.modifiers.remove(md)
        r = bpy.data.objects.new(o.name + "_rez", me)
        cols["5_rez"].objects.link(r)
        r.parent = o.parent
        r.matrix_parent_inverse = o.matrix_parent_inverse.copy()
        r.matrix_basis = o.matrix_basis.copy()
        rez_objs[r.name] = (r, n)
    bpy.data.objects.remove(cut, do_unlink=True)
    cut = None
    # baked animation
    L = meta.get("ZS", 0) - meta["AXZ"]
    for f in range(1, KEYS[-1][0] + 1):
        p, l, t = pose_at(f)
        pan.rotation_euler = (0, 0, math.radians(p)); pan.keyframe_insert("rotation_euler", index=2, frame=f)
        lift.location = (0, 0, -meta["LIFT"] * (1 - l)); lift.keyframe_insert("location", index=2, frame=f)
        tilt.rotation_euler = (math.radians(t), 0, 0); tilt.keyframe_insert("rotation_euler", index=0, frame=f)
        if V == "A":
            tr = math.radians(t)
            E["horn"].location = (0, -L * math.sin(tr), L * (math.cos(tr) - 1))
            E["horn"].keyframe_insert("location", frame=f)
            E["link"].rotation_euler = (tr, 0, 0); E["link"].keyframe_insert("rotation_euler", index=0, frame=f)
    rig_all[V] = dict(pan=pan, lift=lift, tilt=tilt, objs=objs, rez=rez_objs, dx=dx, cols=cols, top=top)
    labels.append((V, dx))

for ob in bpy.data.objects:
    ad = ob.animation_data
    if ad and ad.action:
        try:
            for fc in ad.action.fcurves:
                for kp in fc.keyframe_points:
                    kp.interpolation = "LINEAR"
        except Exception:
            pass
scene.frame_start, scene.frame_end = 1, KEYS[-1][0]
scene.render.fps = 24
for f, txt in MARKERS:
    scene.timeline_markers.new(txt, frame=f)
scene.frame_set(1)
bpy.context.view_layer.update()

# bounds at rest for labels + camera
zmax, zmin = -1e9, 1e9
for V, d in rig_all.items():
    for o, n in d["objs"].values():
        for c in o.bound_box:
            w = o.matrix_world @ Vector(c)
            zmax, zmin = max(zmax, w.z), min(zmin, w.z)
print("Z range at rest", round(zmin, 1), round(zmax, 1))
TXT = {"A": "A – servo v hlave", "B": "NOVA mini B"}
for V, dx in labels:
    cu = bpy.data.curves.new("popis_" + V, "FONT")
    cu.body, cu.size, cu.align_x = TXT[V], 13, "CENTER"
    ob = bpy.data.objects.new("popis_" + V, cu)
    ob.location = (dx, 0, zmax + 40)
    ob.rotation_euler = (math.radians(90), 0, 0)
    ob.data.materials.append(M["satin"])
    scene.collection.objects.link(ob)

w = bpy.data.worlds.new("svet")
w.use_nodes = True
w.node_tree.nodes["Background"].inputs["Color"].default_value = (0.86, 0.88, 0.91, 1)
w.node_tree.nodes["Background"].inputs["Strength"].default_value = 0.7
scene.world = w
for nm, rot, en in (("svetlo_kluc", (50, 0, -35), 3.0), ("svetlo_vypln", (65, 0, 150), 1.0)):
    ld = bpy.data.lights.new(nm, "SUN"); ld.energy = en; ld.angle = math.radians(8)
    lo = bpy.data.objects.new(nm, ld); lo.rotation_euler = tuple(math.radians(a) for a in rot)
    scene.collection.objects.link(lo)
cd = bpy.data.cameras.new("kamera"); cd.lens = 50; cd.clip_start, cd.clip_end = 1, 10000
cam = bpy.data.objects.new("kamera", cd); scene.collection.objects.link(cam)
target = Vector((0, 0, (zmin + zmax) / 2 + (10 if not ONLY else 14)))
cam.location = target + (Vector((-210, -680, 250)) if not ONLY else Vector((-175, -500, 195)))
cam.rotation_euler = (target - cam.location).to_track_quat("-Z", "Y").to_euler()
scene.camera = cam
scene.unit_settings.system = "METRIC"; scene.unit_settings.scale_length = 0.001
scene.unit_settings.length_unit = "MILLIMETERS"
for scr in bpy.data.screens:
    for area in scr.areas:
        for sp in area.spaces:
            if sp.type == "VIEW_3D":
                sp.clip_start, sp.clip_end = 1, 20000
                sp.shading.color_type = "MATERIAL"
                if sp.region_3d:
                    sp.region_3d.view_location = target
                    sp.region_3d.view_distance = 900 if not ONLY else 520
scene.render.engine = "CYCLES"; scene.cycles.device = "CPU"; scene.cycles.samples = 32
scene.view_settings.exposure = -0.35
scene.render.film_transparent = False
for V, d in rig_all.items():
    lc = bpy.context.view_layer.layer_collection.children[d["top"].name]
    for k in ("5_rez", "6_osi"):
        lc.children[f"{V}_{k}"].hide_viewport = True
        d["cols"][k].hide_render = True
bpy.ops.wm.save_as_mainfile(filepath=OUT, compress=True)
print("BLEND", OUT, os.path.getsize(OUT))
for V, d in rig_all.items():
    print(V, sorted(d["objs"]), "rez:", sorted(d["rez"]))

if PREV:
    os.makedirs(PREV, exist_ok=True)
    scene.cycles.samples = 24
    scene.render.resolution_x, scene.render.resolution_y = (1100, 640) if not ONLY else (760, 960)
    if ONLY:
        cd.lens = 85
    for f in (1, 48, 210, 288):
        scene.frame_set(f)
        scene.render.filepath = os.path.join(PREV, f"f{f:03d}.png")
        bpy.ops.render.render(write_still=True)
        print("PREVIEW", f, flush=True)
    # section close-ups (neck extended, tilt 0), head + neck cut open at y = -1
    scene.frame_set(174)
    for ob in bpy.data.objects:
        if ob.name.startswith("popis_"):
            ob.hide_render = True
    for V in rig_all:
        d = rig_all[V]
        d["cols"]["1_obal"].hide_render = d["cols"]["2_displej"].hide_render = True
        d["cols"]["5_rez"].hide_render = False
        tgt = Vector((d["dx"], 0, 45))
        cam.location = tgt + Vector((-150, -260, 90))
        cam.rotation_euler = (tgt - cam.location).to_track_quat("-Z", "Y").to_euler()
        cd.lens = 50
        scene.render.resolution_x, scene.render.resolution_y = 1000, 800
        scene.render.filepath = os.path.join(PREV, f"rez_{V}.png")
        bpy.ops.render.render(write_still=True)
        d["cols"]["1_obal"].hide_render = d["cols"]["2_displej"].hide_render = False
        d["cols"]["5_rez"].hide_render = True
        print("PREVIEW rez", V, flush=True)
