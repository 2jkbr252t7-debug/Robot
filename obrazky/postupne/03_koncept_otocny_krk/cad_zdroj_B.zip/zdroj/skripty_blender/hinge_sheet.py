"""Labelled sheet: variant B rev. E2 – the hinge, what each part does and how it is held (Slovak).
Usage: python hinge_sheet.py <dir with E2_pant_*.png + anchors_pant.json> <out.png>"""
import sys, json, os
sys.path.insert(0, "/home/user/Robot")
from PIL import Image, ImageDraw
from nova.render.sheet import font, INK, MUTED, ACCENT

D, OUT = sys.argv[1], sys.argv[2]
A = json.load(open(os.path.join(D, "anchors_pant.json")))
PANELS = [
    ("E2_pant_rozlozeny.png", "rozlozeny", "1  Rozložený pánt – diely roztiahnuté pozdĺž osi pántu (predná polovica krku skrytá)", {
        "kryt": "KRYT PRAVÉHO UŠKA (−X, usko_kryt) –\notáča sa s hlavou. Nasunie sa na ramená\npáky, 4 rebrá ich zovrú → servo točí hlavou",
        "ptfe": "PTFE KRÚŽOK 0,25 mm – vložený v drážke\nkrytu (kvapka vazelíny); klzná podložka,\nhlava nemá vôľu do strán",
        "skrutka": "SKRUTKA PÁKY – malá skrutka z balenia\nserva; drží páku na hriadeli",
        "paka": "PÁKA SERVA – z balenia, skrátená na 12 mm,\nboky ramien zapílené na šírku 5,0;\nnasunutá na drážkovaný hriadeľ",
        "servo": "SERVO MG90S – vložené v kapse krku,\nos hriadeľa = os pántu. Drží ho tvar\nkapsy a pena, NElepí sa",
        "pena": "PENA – pásiky a podložky,\nservo sedí bez vôle",
        "krk": "KRK (zadná polovica) – polovice spájajú\n4 skrutky M2×12 do mosadzných vložiek\n+ 2 kolíky; servo je medzi nimi",
        "cap": "DUTÝ ČAP Ø5 (oceľ) – ZALEPENÝ epoxidom\nlen v PREDNEJ polovici krku (lôžko v zadnej\nsa navoskuje); nehýbe sa, dnu idú vodiče",
        "lozisko": "LOŽISKO MR85 – najprv sa VLEPÍ do ľavého\nuška (len vonkajší krúžok), potom sa uško\naj s ložiskom len NASUNIE na čap",
        "usko": "ĽAVÉ UŠKO (+X, usko_lozisko) – otáča\nsa s hlavou na ložisku okolo čapu",
        "skr_hlavy": "4× SKRUTKA M2×8 (2 na každé uško) – čap\nuška zapadne do drážky v podlahe hlavy,\nskrutky sa zaskrutkujú zvnútra hlavy\ncez predný otvor (závit si vyrežú samy)",
    }),
    ("E2_pant_rez.png", "rez", "2  Rez osou pántu – zložený stav (pohľad spredu)", {
        "kryt": "kryt uška – ramená páky sú\nzovreté medzi jeho 4 rebrami",
        "paka": "páka na hriadeli serva",
        "skrutka": "skrutka páky",
        "ptfe": "PTFE krúžok medzi\nkrytom a krkom",
        "servo": "servo – jeho hriadeľ\nje os pántu",
        "polovice": "krk (zadná polovica)",
        "cap": "čap – zalepený v prednej polovici\nkrku (zadné lôžko len navoskované)",
        "lozisko": "ložisko – vnútorný krúžok voľne na čape,\nvonkajší vlepený v uške",
        "usko": "ľavé uško (otáča sa s hlavou)",
        "vodice": "4 vodiče z trupu idú dutým čapom do hlavy –\nležia v osi otáčania, preto sa pri náklone\nlen mierne skrútia, nenaťahujú sa ani nelámu",
    }),
]
SUMMARY = [
    ("Čo drží čo", [
        "trup  →  krk (vysúva sa v šachte trupu)",
        "krk  →  servo (zovreté medzi polovicami, pena)",
        "hriadeľ serva  →  páka (nasunutá + skrutka)",
        "páka  →  kryt pravého uška (4 rebrá)  →  HLAVA",
        "krk  →  dutý čap (lepený)  →  ložisko  →  ľavé uško  →  HLAVA",
        "obe uška  →  hlava (čapy v drážkach + 4× M2×8)",
        "vodiče serva  →  DOLE drážkou v prednej polovici krku",
        "  do trupu (servo upravené, kábel nejde cez pánt)",
    ]),
    ("Ako je čo uchytené", [
        "LEPENÉ epoxidom: čap (len v prednej polovici krku),",
        "  ložisko v uške (len vonkajší krúžok), 4 vložky",
        "  a 2 kolíky (len v zadnej polovici krku)",
        "SKRUTKY: krk 4× M2×12, páka 1×, hlava k uškám 4× M2×8",
        "NASUNUTÉ / ZOVRETÉ: servo (pena), páka v rebrách krytu,",
        "  ložisko na čape, PTFE krúžok (kvapka vazelíny)",
        "NELEPIŤ: polovice krku k sebe, servo, ložisko na čap,",
        "  páku do krytu – inak sa servo nedá vymeniť",
    ]),
]
COL, IW, IH = 640, 1400, 1100
W = COL * 2 + IW
TOP = 250
H = TOP + len(PANELS) * (IH + 90) + 600
S = Image.new("RGB", (W, H), (246, 247, 245))
d = ImageDraw.Draw(S)
d.text((40, 36), "NOVA mini · verzia B – pánt hlavy: čo je čo a ako to drží", font=font(58), fill=INK)
d.multiline_text((40, 112), "Hlava sa nakláňa okolo osi pántu. Na pravej strane (−X) ju točí servo cez páku, na ľavej strane (+X) sa otáča\n"
                 "na ložisku na dutom čape. Obe uška pántu (usko_kryt, usko_lozisko) sú samostatné tlačené diely, ktoré sa otáčajú\n"
                 "s hlavou – hlava je k nim priskrutkovaná 4 skrutkami. Servo aj čap sedia v krku, ktorý sa vysúva z trupu.",
                 font=font(27, "Regular"), fill=MUTED, spacing=8)
fT, fL = font(34), font(26, "Medium")
y0 = TOP
for fn, key, title, labels in PANELS:
    im = Image.open(os.path.join(D, fn)).convert("RGB")
    d.text((COL, y0 + 8), title, font=fT, fill=INK)
    yi = y0 + 70
    S.paste(im, (COL, yi))
    sides = {"L": [], "R": []}
    for k, txt in labels.items():
        if k not in A.get(key, {}):
            print("missing anchor", key, k)
            continue
        ax, ay = A[key][k]
        ax, ay = min(max(ax, 4), IW - 4), min(max(ay, 4), IH - 4)
        sides["L" if ax < IW * 0.5 else "R"].append([ay, ax, txt])
    for side, items in sides.items():
        items.sort()
        last = -1e9
        for it in items:
            n = it[2].count("\n") + 1
            ly = max(it[0] - 20, last)
            it.append(ly)
            last = ly + 34 * n + 30
        over = (items[-1][3] + 34 * (items[-1][2].count("\n") + 1) - IH) if items else 0
        if over > 0:
            for it in items:
                it[3] -= over
        top_lim = min((it[3] for it in items), default=0)
        if top_lim < 0:
            for it in items:
                it[3] -= top_lim
        for ay, ax, txt, ly in items:
            px, py = COL + ax, yi + ay
            if side == "L":
                tx = 20
                w = max(d.textlength(t, font=fL) for t in txt.split("\n"))
                ex = tx + w + 12
            else:
                tx = COL + IW + 20
                ex = tx - 12
            d.multiline_text((tx, yi + ly), txt, font=fL, fill=INK, spacing=6)
            d.line([(ex, yi + ly + 15), (px, py)], fill=ACCENT, width=4)
            d.ellipse([px - 8, py - 8, px + 8, py + 8], fill=ACCENT, outline=(255, 255, 255), width=3)
    y0 = yi + IH + 20
# ---------------------------------------------------------------- summary boxes
bx = 40
bw = (W - 120) // 2
for title, lines in SUMMARY:
    d.rounded_rectangle([bx, y0 + 30, bx + bw, y0 + 560], radius=18, fill=(255, 255, 255), outline=(214, 219, 217), width=3)
    d.text((bx + 30, y0 + 55), title, font=font(38), fill=INK)
    d.multiline_text((bx + 30, y0 + 120), "\n".join(lines), font=font(27, "Regular"), fill=INK, spacing=13)
    bx += bw + 40
S.save(OUT)
print("sheet", OUT, S.size)
