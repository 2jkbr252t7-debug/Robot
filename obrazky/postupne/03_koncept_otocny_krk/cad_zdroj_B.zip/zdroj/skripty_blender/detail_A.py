"""Variant A – servo mounting in the head: two cut-away renders + 2-D label anchors (JSON).
 view 'zhora': head cut horizontally above the shaft axis (z = ZS + 2.5), seen from above-front-left
 view 'spredu': the X_5_rez section (y = -1), seen from front-left
Usage: blender-python detail_A.py <blend> <out_dir>"""
import bpy, sys, os, json, math
from mathutils import Vector
from bpy_extras.object_utils import world_to_camera_view

BLEND, OUT = sys.argv[-2], sys.argv[-1]
bpy.ops.wm.open_mainfile(filepath=BLEND)
sc = bpy.context.scene
sc.frame_set(174)                                   # neck extended, tilt 0, pan 0
vl = bpy.context.view_layer
DX, ZS, HZ, AXZ = -170.0, 47.5, 26.0, 17.5          # fin/A/build_r1.py (extended pose) + A offset in the scene
for c in bpy.data.collections:
    if c.name.startswith("B_"):
        c.hide_render = True
for ob in bpy.data.objects:
    if ob.name.startswith("popis_"):
        ob.hide_render = True
bpy.data.objects["A_trup"].hide_render = True
bpy.data.objects["A_displej_zona_suciastok"].hide_render = True
sc.cycles.samples = 64
sc.render.resolution_x, sc.render.resolution_y = 1400, 1100
cam = sc.camera


def aim(tgt, off, lens):
    cam.location = tgt + Vector(off)
    cam.rotation_euler = (tgt - cam.location).to_track_quat("-Z", "Y").to_euler()
    cam.data.lens = lens
    vl.update()


def px(p):
    c = world_to_camera_view(sc, cam, Vector(p))
    return [round(c.x * sc.render.resolution_x, 1), round((1 - c.y) * sc.render.resolution_y, 1)]


res = {}
# ---------------------------------------------------------------- 1) horizontal cut above the servo shaft
ZC = ZS + 2.5
bpy.ops.mesh.primitive_cube_add(size=1)
box = bpy.context.active_object
box.scale = (300, 300, 200)
box.location = (DX, 0, ZC + 100)
box.hide_render = True
cutp = ["A_hlava_skrupina", "A_sklo", "A_usi", "A_led_kruzky", "A_displej", "A_drziak_displeja", "A_led_dosky",
        "A_oci_dekal"]
for n in cutp:
    md = bpy.data.objects[n].modifiers.new("hcut", "BOOLEAN")
    md.object, md.operation, md.solver = box, "DIFFERENCE", "EXACT"
for k, show in (("1_obal", True), ("2_displej", True), ("3_mechanika", True), ("5_rez", False), ("6_osi", False)):
    bpy.data.collections[f"A_{k}"].hide_render = not show
aim(Vector((DX - 1, 5, 46)), (-55, -88, 135), 78)
A1 = {
    "servo": (DX - 8.6, 5.5, ZS + 6.1),
    "skrutka_zadna": (DX - 6.4, 19.3, ZS),
    "skrutka_predna": (DX - 6.4, -8.3, ZS),
    "doska": (DX - 0.15, 22.0, ZC),
    "objimka": (DX + 4.6, -7.5, ZC),
    "rameno": (DX + 12.0, 0.0, ZS + 2.0),
}
res["zhora"] = {k: px(v) for k, v in A1.items()}
sc.render.filepath = os.path.join(OUT, "A_zhora.png")
bpy.ops.render.render(write_still=True)
for n in cutp:
    o = bpy.data.objects[n]
    o.modifiers.remove(o.modifiers["hcut"])
bpy.data.objects.remove(box, do_unlink=True)
# ---------------------------------------------------------------- 2) front section (pre-cut copies in A_5_rez)
for k, show in (("1_obal", False), ("2_displej", False), ("3_mechanika", True), ("5_rez", True), ("6_osi", False)):
    bpy.data.collections[f"A_{k}"].hide_render = not show
bpy.data.objects["A_golier_kotuc"].hide_render = True
bpy.data.objects["A_golier_prstenec"].hide_render = True
aim(Vector((DX + 1, 0, 32)), (-60, -125, 40), 58)
A2 = {
    "servo": (DX - 12, -0.5, ZS - 4),
    "kolíska": (DX + 1.75, 0.0, HZ + 9),
    "lozisko": (DX + 9.6, -1.0, AXZ + 3.5),
    "paka": (DX + 13.0, 0.0, AXZ - 3.0),
    "cap": (DX - 3.0, 0.0, AXZ + 2.5),
    "kabel": (DX - 13.4, 0.0, AXZ + 9),
    "krk": (DX + 6, 1.0, AXZ - 18),
}
res["spredu"] = {k: px(v) for k, v in A2.items()}
sc.render.filepath = os.path.join(OUT, "A_spredu.png")
bpy.ops.render.render(write_still=True)
json.dump(res, open(os.path.join(OUT, "anchors.json"), "w"), indent=1)
print("DONE", json.dumps(res))
