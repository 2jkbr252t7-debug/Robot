"""Labelled sheet: variant B – servo mounting in the neck (Slovak).  Usage: python sheet_A.py <det_dir> <out.png>"""
import sys, json, os
sys.path.insert(0, "/home/user/Robot")
from PIL import Image, ImageDraw
from nova.render.sheet import font, INK, MUTED, ACCENT

D, OUT = sys.argv[1], sys.argv[2]
SKR = sys.argv[3].replace("\\n", "\n") if len(sys.argv) > 3 else "skrutky M2 sťahujú polovice\n(vložky v zadnej polovici)"
A = json.load(open(os.path.join(D, "anchors.json")))
PANELS = [
    ("B_spredu.png", "spredu", "Rez spredu – krk vysunutý, hlava v 0° (predná polovica krku odrezaná)", {
        "servo": "servo MG90S v kapse\nmedzi polovicami krku",
        "pena": "penový pásik 0,5 mm z oboch\nstrán – servo sedí bez vôle",
        "paka": "páka serva (originálna,\nskrátená na 12 mm)",
        "kryt": "kryt pravého uška (−X):\npáka sedí v jeho drážke,\nservo točí hlavou priamo",
        "lozisko": "ložisko MR85 v ľavom\nuchu (+X)",
        "cap": "dutý čap Ø5 – cez neho\nidú vodiče do hlavy",
        "skrutky": SKR,
        "krk": "zadná polovica krku",
        "kabel": "vodiče hlavy",
    }),
    ("B_zhora.png", "zhora", "Pohľad zhora – krk prerezaný v osi kĺbu, hlava skrytá", {
        "servo": "os hriadeľa serva = os kĺbu",
        "polovice": "predná a zadná polovica\nkrku (zovrú servo)",
        "paka": "páka v drážke krytu uška",
        "kryt": "kryt uška (−X)",
        "lozisko": "ložisko MR85 (+X)",
    }),
]
COL, IW, IH, GAP = 600, 1400, 1100, 30
W = COL * 2 + IW
TOP = 210
H = TOP + len(PANELS) * (IH + 90) + 40
S = Image.new("RGB", (W, H), (246, 247, 245))
d = ImageDraw.Draw(S)
d.text((40, 36), "NOVA mini · verzia B – uloženie a upevnenie serva v krku", font=font(58), fill=INK)
d.multiline_text((40, 108), "Servo leží v kapse medzi prednou a zadnou polovicou krku. Drží ho tvar kapsy, penové pásiky "
                 "z oboch strán a skrutky, ktoré sťahujú polovice.\nOs serva je zároveň os kĺbu: páka serva sedí v drážke "
                 "krytu pravého uška, takže servo točí hlavou priamo, bez tiahla.", font=font(27, "Regular"), fill=MUTED, spacing=8)
fT, fL = font(34), font(27, "Medium")
y0 = TOP
for fn, key, title, labels in PANELS:
    im = Image.open(os.path.join(D, fn)).convert("RGB")
    d.text((COL, y0 + 8), title, font=fT, fill=INK)
    yi = y0 + 70
    S.paste(im, (COL, yi))
    sides = {"L": [], "R": []}
    for k, txt in labels.items():
        ax, ay = A[key][k]
        sides["L" if ax < IW * 0.5 else "R"].append([ay, ax, txt])
    for side, items in sides.items():
        items.sort()
        last = -1e9
        for it in items:
            ly = max(it[0] - 20, last + 110)
            it.append(ly)
            last = ly
        over = (items[-1][3] + 80 - IH) if items else 0          # keep the column inside the panel
        if over > 0:
            for it in items:
                it[3] -= over
        for ay, ax, txt, ly in items:
            px, py = COL + ax, yi + ay
            if side == "L":
                tx = 24
                w = max(d.textlength(t, font=fL) for t in txt.split("\n"))
                ex = tx + w + 14
            else:
                tx = COL + IW + 24
                ex = tx - 14
            d.multiline_text((tx, yi + ly), txt, font=fL, fill=INK, spacing=6)
            d.line([(ex, yi + ly + 16), (px, py)], fill=ACCENT, width=4)
            d.ellipse([px - 8, py - 8, px + 8, py + 8], fill=ACCENT, outline=(255, 255, 255), width=3)
    y0 = yi + IH + 20
S.save(OUT)
print("sheet", OUT, S.size)
