"""Variant B – how the tilt servo sits in the neck: two cut-away renders + 2-D label anchors (JSON).
 'spredu': the B_5_rez section (y = -1), neck extended, tilt 0, seen from front-left
 'zhora' : neck + lugs cut horizontally at the hinge axis (head hidden), seen from above-front
Anchors are picked automatically: a vertex of the part near its middle that the camera actually sees (ray cast).
Usage: blender-python detail_B.py <blend> <out_dir>"""
import bpy, sys, os, json, math
from mathutils import Vector
from bpy_extras.object_utils import world_to_camera_view

BLEND, OUT = sys.argv[-2], sys.argv[-1]
bpy.ops.wm.open_mainfile(filepath=BLEND)
sc = bpy.context.scene
vl = bpy.context.view_layer
sc.frame_set(174)                                   # neck extended, tilt 0, pan 0
DX = bpy.data.objects["zaklad_B"].matrix_world.translation.x
AXZ = bpy.data.objects["naklon_B"].matrix_world.translation.z
print("DX", DX, "AXZ", AXZ)
sc.cycles.samples = 64
sc.render.resolution_x, sc.render.resolution_y = 1400, 1100
cam = sc.camera
top = [c for c in vl.layer_collection.children if c.name.startswith("B_")][0]
LC = {c.name[2:]: c for c in top.children}          # '1_obal', '2_displej', ...
for ob in bpy.data.objects:
    if ob.name.startswith("popis_"):
        ob.hide_render = True
        ob.hide_viewport = True


def show(cols):
    for k, lc in LC.items():
        lc.exclude = k not in cols
        if k in cols:
            lc.hide_viewport = False
            lc.collection.hide_render = False
            lc.collection.hide_viewport = False
    vl.update()


def aim(tgt, off, lens):
    cam.location = tgt + Vector(off)
    cam.rotation_euler = (tgt - cam.location).to_track_quat("-Z", "Y").to_euler()
    cam.data.lens = lens
    vl.update()


def px(p):
    c = world_to_camera_view(sc, cam, p)
    return [round(c.x * sc.render.resolution_x, 1), round((1 - c.y) * sc.render.resolution_y, 1)]


def anchor(names, bias=(0.5, 0.5, 0.5)):
    """visible vertex near the 'bias' point of the parts' world bbox"""
    dg = bpy.context.evaluated_depsgraph_get()
    P = []
    obs = [bpy.data.objects[n] for n in names if n in bpy.data.objects and bpy.data.objects[n].visible_get()]
    for o in obs:
        me = o.evaluated_get(dg).to_mesh()
        P += [(o.matrix_world @ v.co, o) for v in me.vertices]
    if not P:
        return None
    lo = Vector((min(p.x for p, _ in P), min(p.y for p, _ in P), min(p.z for p, _ in P)))
    hi = Vector((max(p.x for p, _ in P), max(p.y for p, _ in P), max(p.z for p, _ in P)))
    tgt = Vector([lo[i] + (hi[i] - lo[i]) * bias[i] for i in range(3)])
    cand = sorted(P, key=lambda q: (q[0] - tgt).length)[:400]
    eye = cam.matrix_world.translation
    for p, o in cand:
        d = p - eye
        hit, loc, nrm, idx, hob, mx = sc.ray_cast(dg, eye, d.normalized(), distance=d.length + 0.05)
        if hit and (hob.original if hasattr(hob, "original") else hob) == o and (loc - p).length < 0.6:
            return p
    return cand[0][0]


res = {}
B = lambda *n: [f"B_{x}" for x in n]
# ---------------------------------------------------------------- 1) front section
show({"3_mechanika", "4_trup", "5_rez"})
bpy.data.objects["B_trup"].hide_viewport = True
bpy.data.objects["B_trup"].hide_render = True
aim(Vector((DX + 2, 0, AXZ - 7)), (-62, -128, 42), 62)
L1 = {
    "servo": anchor(B("servo_MG90S"), (0.45, 0.5, 0.55)),
    "pena": anchor(B("pena_serva"), (0.5, 0.5, 0.5)),
    "paka": anchor(B("paka"), (0.5, 0.5, 0.5)),
    "kryt": anchor(B("usko_kryt_rez"), (0.3, 0.5, 0.3)),
    "lozisko": anchor(B("loziska_MR85_hlava", "loziska_MR85_krk"), (0.5, 0.5, 0.6)),
    "cap": anchor(B("capy"), (0.75, 0.5, 0.5)),
    "skrutky": anchor(B("skrutky_krk"), (0.5, 0.5, 0.2)),
    "krk": anchor(B("krk_zadna_polovica_rez"), (0.12, 0.5, 0.12)),
    "kabel": anchor(B("kabel_krk"), (0.5, 0.5, 0.3)),
}
res["spredu"] = {k: px(v) for k, v in L1.items() if v is not None}
sc.render.filepath = os.path.join(OUT, "B_spredu.png")
bpy.ops.render.render(write_still=True)
# ---------------------------------------------------------------- 2) horizontal cut at the hinge axis, head hidden
show({"1_obal", "3_mechanika", "4_trup"})
for n in ("hlava_skrupina", "sklo", "usi", "led_kruzky", "oci_len_vizualizacia", "skrutky_hlava", "golier_prstenec"):
    o = bpy.data.objects.get("B_" + n)
    if o:
        o.hide_viewport = o.hide_render = True
bpy.ops.mesh.primitive_cube_add(size=1)
box = bpy.context.active_object
box.scale = (400, 400, 300)
box.location = (DX, 0, AXZ + 150)
box.hide_render = True
box.hide_viewport = True
for n in ("krk_predna_polovica", "krk_zadna_polovica", "usko_kryt", "usko_lozisko", "kabel_hlava", "kabel_krk"):
    o = bpy.data.objects.get("B_" + n)
    if o:
        md = o.modifiers.new("hcut", "BOOLEAN")
        md.object, md.operation, md.solver = box, "DIFFERENCE", "EXACT"
vl.update()
aim(Vector((DX + 1, 2, AXZ - 3)), (-27, -62, 108), 72)
L2 = {
    "servo": anchor(B("servo_MG90S"), (0.45, 0.5, 0.9)),
    "pena": anchor(B("pena_serva"), (0.5, 0.0, 0.9)),
    "polovice": anchor(B("krk_predna_polovica"), (0.2, 0.1, 1.0)),
    "paka": anchor(B("paka"), (0.5, 0.5, 1.0)),
    "lozisko": anchor(B("loziska_MR85_hlava", "loziska_MR85_krk"), (0.5, 0.3, 1.0)),
    "kryt": anchor(B("usko_kryt"), (0.2, 0.3, 1.0)),
}
res["zhora"] = {k: px(v) for k, v in L2.items() if v is not None}
sc.render.filepath = os.path.join(OUT, "B_zhora.png")
bpy.ops.render.render(write_still=True)
json.dump(res, open(os.path.join(OUT, "anchors.json"), "w"), indent=1)
print("DONE", json.dumps(res))
