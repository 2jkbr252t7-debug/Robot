"""Variant B, buildable neck (user: no extra holes, dust-tight, how is the servo held):
* head lugs closed on the outside (pin/bearing/horn pockets open only toward the knuckle);
* neck top under the lugs = saddle concentric with the hinge (uniform 0.5 mm seam, no see-through corners);
* neck printed as 2 halves (front/back, split y=0), SOLID inside except a fitted servo pocket (+0.2) and one cable
  channel; the MG90S (tabs cut) is clamped by the halves; 2x M2 screws + inserts in the bottom 12 mm of the neck,
  which always stays inside the torso (also when extended); 2 dowels at the top; horn screwed to the right lug from
  inside the head.  Head = 108 x 77 with the real 86 x 56 display."""
import sys, math, json
sys.path.insert(0, "/home/user/Robot"); sys.path.insert(0, "/tmp/claude-0/pan16"); sys.path.insert(0, "/tmp/claude-0/gapwf/c_hn3")
from build123d import Pos, Rot, Box, Cylinder, Axis, Location, fillet, export_stl, Torus, Solid
from nova.cad.common import PartRec, export_parts
from nova import spec
import build as B3                                # c_hn3: head, constants, servo(), head_internals()
SH = B3.SH
spec.MATERIALS["servo_blue"] = dict(desc="servo", rgb=(0.22, 0.42, 0.86), rough=0.45)
spec.MATERIALS["pcb"] = dict(desc="doska", rgb=(0.10, 0.32, 0.20), rough=0.5)
spec.MATERIALS["bracket"] = dict(desc="držiak", rgb=(0.60, 0.38, 0.86), rough=0.45)
B = "/tmp/claude-0/gapwf/c_hn4"
HZ, BW, BT, RK, AXZ, KN, LUG0, LUG1, ZB = B3.HZ, B3.BW, B3.BT, B3.RK, B3.AXZ, B3.KN, B3.LUG0, B3.LUG1, B3.ZB
xcyl, zcyl = B3.xcyl, B3.zcyl
XC = 16.0                                          # cable channel x (left side, under the hollow pin)


def ycyl(r, y0, y1, x, z):
    return Pos(x, (y0 + y1) / 2, z) * Rot(90, 0, 0) * Cylinder(r, abs(y1 - y0))


def servo_envelope(g=0.2):
    case = Pos(-8.4 + 22.5 / 2, 0, AXZ + 5.9 - 22.8 / 2) * Box(22.5 + 2 * g, 12.2 + 2 * g, 22.8 + 2 * g)
    return case + xcyl(5.9 + g, -14.4 - g, -8.4, 0, AXZ) + xcyl(3.2, -18.0, -14.4, 0, AXZ)


def blade_full():
    body = Pos(0, 0, (ZB + AXZ) / 2) * Box(BW, BT, AXZ - ZB)
    body = fillet(body.edges().filter_by(Axis.Z), 2.0)
    for sx in (-1, 1):
        x0, x1 = sorted((sx * (KN + 0.25), sx * (BW / 2 + 1.0)))
        cut = Pos((x0 + x1) / 2, 0, AXZ + (RK + 1.0) / 2) * Box(x1 - x0, BT + 2, RK + 1.0) + xcyl(RK + 0.5, x0, x1, 0, AXZ)
        body = body - cut
    body = body + xcyl(RK, -KN, KN, 0, AXZ)
    body = body - servo_envelope()
    # one cable channel: hollow pin bore -> down the left knuckle end wall -> out at the neck bottom
    chan = xcyl(1.6, KN - 3.2, KN + 0.5, 0, AXZ) + zcyl(2.1, ZB - 1, AXZ, x=XC) + xcyl(2.1, 13.0, XC, 0, AXZ - 6.0)
    body = body - chan
    body = body - xcyl(2.55, KN - 3.0, KN + 0.5, 0, AXZ)                 # hollow pin seat (Ø5) in the left end wall
    # 2x M2 at the bottom (hidden in the torso): clearance + counterbore in the front half, insert in the back half
    for sx in (-1, 1):
        x = sx * 13.0; z = ZB + 6.0
        body = body - ycyl(1.15, -BT / 2 - 1, 0.5, x, z) - ycyl(2.1, -BT / 2 - 1, -BT / 2 + 2.0, x, z) - ycyl(1.6, 0, 6.0, x, z)
    # 2 dowel holes at the split plane (top)
    for x in (-12.0, 12.0):
        body = body - ycyl(1.05, -3.0, 3.0, x, AXZ - 12.0)
    return body


def halves():
    full = blade_full()
    front = full & (Pos(0, -50 - 0.15, 0) * Box(200, 100, 400))
    back = full & (Pos(0, 50 + 0.15, 0) * Box(200, 100, 400))
    return front, back


def lugs_closed():
    L = None
    for sx in (-1, 1):
        x0, x1 = sorted((sx * LUG0, sx * LUG1))
        zw0 = AXZ + 4.0                                                  # web starts above the barrel's widest part
        l = xcyl(RK, x0, x1, 0, AXZ) + Pos((x0 + x1) / 2, 0, (zw0 + HZ + 1.5) / 2) * Box(x1 - x0, 18.0, HZ + 1.5 - zw0)
        if sx < 0:      # right lug: horn pocket open toward the knuckle only (outer 1.5 mm stays closed)
            l = l - xcyl(6.3, -LUG1 + 1.5, -LUG0 + 0.01, 0, AXZ)
            for a in (0, 180):                                          # 2 horn screws from inside the head (vertical)
                pass
        else:           # left lug: MR85 pocket + pin bore open toward the knuckle, cable hole up into the head
            l = l - xcyl(4.05, LUG0 - 0.01, LUG0 + 2.5, 0, AXZ) - xcyl(2.6, LUG0 + 2.4, LUG1 - 1.5, 0, AXZ) - zcyl(1.4, AXZ, HZ + 2, x=LUG1 - 2.6)
            l = l - xcyl(1.4, LUG0 + 2.4, LUG1 - 2.0, 0, AXZ)
        L = l if L is None else L + l
    return L


def parts():
    head = (SH.outer() - SH.white_cut()).moved(Location((0, 0, HZ)))
    lg = lugs_closed()
    head = head - lg
    visor = SH.visor().moved(Location((0, 0, HZ)))
    ears, leds = (s.moved(Location((0, 0, HZ))) for s in SH.ears(ear_z=SH.H / 2))
    eyes = None
    for sx in (-1, 1):
        e = Pos(sx * 11.0, SH.YF - 0.2, B3.ZC) * Box(10.0, 0.4, 17.5)
        e = fillet([ed for ed in e.edges() if abs(ed.tangent_at(0.5).Y) > 0.9], 4.9)
        eyes = e if eyes is None else eyes + e
    nf, nb = halves()
    I = {}
    I["servo"] = B3.servo()
    I["horn"] = xcyl(6.0, -LUG1 + 1.6, -LUG0 - 0.3, 0, AXZ) + xcyl(3.0, -LUG0 - 0.3, -17.3, 0, AXZ)
    I["pins"] = xcyl(2.5, KN - 3.0, LUG0 + 2.5, 0, AXZ) - xcyl(1.5, KN - 3.5, LUG0 + 3.0, 0, AXZ)
    I["brg"] = xcyl(4.0, LUG0 + 0.05, LUG0 + 2.55, 0, AXZ) - xcyl(2.5, LUG0, LUG0 + 2.6, 0, AXZ)
    I["screws"] = None
    for sx in (-1, 1):
        x = sx * 13.0; z = ZB + 6.0
        s = ycyl(1.0, -BT / 2 + 2.0, 4.0, x, z) + ycyl(1.9, -BT / 2 + 0.3, -BT / 2 + 2.0, x, z)
        ins = ycyl(1.55, 0.3, 4.3, x, z) - ycyl(1.0, 0.2, 4.4, x, z)
        I["screws"] = (s + ins) if I["screws"] is None else I["screws"] + s + ins
    I["dowels"] = ycyl(1.0, -2.8, 2.8, -12.0, AXZ - 12.0) + ycyl(1.0, -2.8, 2.8, 12.0, AXZ - 12.0)
    I["cable"] = zcyl(1.4, ZB - 0.5, AXZ - 6.0, x=XC) + xcyl(1.3, 13.0, XC, 0, AXZ - 6.0) + xcyl(1.2, KN - 2.5, LUG0 + 2.5, 0, AXZ)
    I.update(B3.head_internals())
    return dict(H=head, V=visor, E=ears, L=leds, Y=eyes, NF=nf, NB=nb, K=lg), I


if __name__ == "__main__":
    S, I = parts()
    print("valid", {k: v.is_valid for k, v in S.items()}, {k: v.is_valid for k, v in I.items()}, flush=True)
    nfb = S["NF"] + S["NB"]
    rep = {"servo into neck": round((I["servo"] & nfb).volume, 2), "servo to neck mm": round(I["servo"].distance_to(nfb), 2),
           "neck halves solid % of envelope": round(100 * nfb.volume / (BW * BT * (AXZ - ZB)), 1),
           "lugs outer face closed (bore through?)": round((S["K"] & xcyl(1.0, -LUG1 - 0.1, -LUG1 + 0.6, 0, AXZ)).volume, 3),
           "left lug outer face closed": round((S["K"] & xcyl(1.0, LUG1 - 0.6, LUG1 + 0.1, 0, AXZ)).volume, 3)}
    ax = Axis((0, 0, AXZ), (1, 0, 0))
    for th in (-40, 0, 40):
        rep[f"lugs th{th:+d} to neck mm"] = round(S["K"].rotate(ax, th).distance_to(nfb), 2)
        rep[f"head th{th:+d} to neck mm"] = round(S["H"].rotate(ax, th).distance_to(nfb), 2)
    for k, v in rep.items():
        print(" ", k, v, flush=True)
    mats = dict(H="white", V="black_gloss", E="black_satin", L="cyan_led", Y="eye", NF="black_satin", NB="black_satin", K="black_satin")
    mi = dict(servo="servo_blue", horn="metal", pins="metal", brg="metal", screws="metal", dowels="metal", cable="rubber",
              lcd="display", pcb="pcb", comp="grey")
    recs = []
    for tag, th in (("0", 0.0), ("D", 40.0)):
        for k, v in S.items():
            recs.append(PartRec(f"{k}{tag}", k, v.rotate(ax, th) if k not in ("NF", "NB") else v, mats[k], "head", "J3"))
        for k, v in I.items():
            v2 = v.rotate(ax, th) if k in ("horn", "brg", "lcd", "pcb", "comp") else v
            recs.append(PartRec(f"{k}{tag}", k, v2, mi[k], "head", "J3", internal=True))
    export_parts(recs, "hn4", step=False, out_dir=B)
    for r in recs:
        export_stl(r.shape, f"{B}/stl/{r.id}.stl", tolerance=0.012, angular_tolerance=0.1)
    print("done", flush=True)
