import json, math
B = "/tmp/claude-0/gapwf/c_hn4"
AXZ = 16.5
SHL = ["H", "V", "E", "L", "Y", "NF", "NB", "K"]
INT = ["servo", "horn", "pins", "brg", "screws", "dowels", "cable", "lcd", "pcb", "comp"]
def job(name, parts, view, res=(1200, 1200), samples=56, xray=False, internal=False, **kw):
    j = dict(out=f"{B}/{name}", glb_dir=B, manifest_dir=f"{B}/manifest", parts=parts, internal=internal or xray, res=list(res),
             samples=samples, shadow=False, exposure=-1.5, write_meta=True, views=[view])
    if xray:
        j.update(xray=True, xray_alpha=0.13)
    j.update(kw)
    return j
def iso(yaw, el, d=900, zt=AXZ):
    a, e = math.radians(yaw), math.radians(el)
    return [d * math.cos(e) * math.sin(a), -d * math.cos(e) * math.cos(a), zt + d * math.sin(e)]
t = lambda L, tag="0": [p + tag for p in L]
jobs = {
  "hinge_side": job("hinge_side", t(SHL), {"name": "v", "loc": [800, 0, AXZ + 4], "target": [0, 0, AXZ + 4], "lens": 50, "ortho": True, "ortho_scale": 75}),
  "hinge_low": job("hinge_low", t(SHL), {"name": "v", "loc": iso(-40, -12, 230, AXZ + 2), "target": [0, 0, AXZ + 2], "lens": 60}, res=(1300, 1000)),
  "hinge_tilt": job("hinge_tilt", t(SHL, "D"), {"name": "v", "loc": iso(55, 2, 240, AXZ + 4), "target": [0, 0, AXZ + 4], "lens": 60}, res=(1300, 1000)),
  "xray": job("xray", t(SHL + INT), {"name": "v", "loc": [0, -800, AXZ + 2], "target": [0, 0, AXZ + 2], "lens": 50, "ortho": True, "ortho_scale": 95}, xray=True),
  "explode": job("explode", t(["NF", "NB", "servo", "horn", "pins", "brg", "screws", "dowels", "cable", "K", "H", "V", "E", "L"]),
                 {"name": "v", "loc": iso(-32, 18, 900, AXZ + 10), "target": [0, 0, AXZ + 10], "lens": 50, "ortho": True, "ortho_scale": 150},
                 internal=True, explode=1.0,
                 explode_override={"NF0": [0, -42, 0], "screws0": [0, -62, 0], "horn0": [0, 0, 0], "K0": [0, 0, 46], "H0": [0, 0, 46],
                                   "V0": [0, 0, 46], "E0": [0, 0, 46], "L0": [0, 0, 46], "brg0": [0, 0, 46], "pins0": [10, 0, 0],
                                   "servo0": [0, -16, 0], "dowels0": [0, -21, 0]}),
}
for k, j in jobs.items():
    open(f"{B}/{k}.json", "w").write(json.dumps(j))
print(list(jobs))
