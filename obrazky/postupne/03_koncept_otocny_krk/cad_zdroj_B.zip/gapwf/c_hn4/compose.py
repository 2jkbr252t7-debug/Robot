import sys, json, textwrap
sys.path.insert(0, "/home/user/Robot")
from PIL import Image, ImageDraw
from nova.render import sheet as S
B = "/tmp/claude-0/gapwf/c_hn4"
OUT = "/home/user/Robot/obrazky/postupne/03_koncept_otocny_krk/NOVA_mini_krk_B_pant_a_servo.png"
BG = (243, 243, 241); OR = (230, 120, 40); GR = (110, 110, 110); INK = S.INK
AXZ, ZB = 16.5, -16.5
W = 2900; M = 50; NC = 3; GX = 40; COLW = (W - 2 * M - (NC - 1) * GX) // NC; CELLH = 1000
CELLS = [
  [("hinge_side", "ZBOKU – uško hlavy zvonka zatvorené", [("len tenká škára, žiadna diera", (20, 0, AXZ - 9.5), (40, 120)),
                                                         ("deliaca škára dvoch polovíc krku", (22.5, 0, -2), (40, 230))]),
   ("hinge_low", "ZOSPODU – skrutky sú dole na krku", [("2× skrutka M2 – táto časť je vždy v trupe", (13, -10.2, ZB + 6), (-60, 170))]),
   ("hinge_tilt", "NAKLONENÁ – škára ostáva rovnaká", [])],
  [("xray", "PRIEHĽADNE SPREDU", [("servo – pevne v lôžku", (2.85, 0, AXZ - 8), (-80, -290)), ("páka serva v uchu hlavy", (-19, 0, AXZ), (-330, -150)),
                                  ("ložisko + dutý čap (kábel)", (20.5, 0, AXZ), (60, -300)), ("kábel", (16, 0, -2), (90, 40)),
                                  ("2× M2", (13, -8, ZB + 6), (90, 120)), ("kolík", (-12, 0, AXZ - 12), (-260, 60))]),
   ("explode", "ROZLOŽENÉ – ako sa to skladá", [("hlava s uškami", (0, 0, AXZ + 62 + 4), (140, -60)), ("zadná polovica krku", (-10, 8, 0), (-380, 60)),
                                                ("servo (bez úchytiek)", (2.85, -18, AXZ - 4), (-430, -140)), ("predná polovica krku", (14, -52, -4), (110, -130)),
                                                ("2× M2", (13, -74, ZB + 6), (60, 90))]),
   None]]
def load(k):
    im = Image.open(f"{B}/{k}/v.png").convert("RGBA")
    return im, im.getchannel("A").point(lambda a: 255 if a > 8 else 0).getbbox()
H = 170 + 2 * (CELLH + 80) + 20
out = Image.new("RGB", (W, H), BG); d = ImageDraw.Draw(out)
d.text((M, 36), "NOVA mini / KRK B – PÁNT BEZ DIER A UPEVNENIE SERVA", fill=INK, font=S.font(56, "Bold"))
d.text((M, 108), "uško hlavy je zvonka zatvorené · krk z dvoch plných polovíc, vnútri len lôžko serva a kanálik pre kábel – prach sa dnu nedostane",
       fill=GR, font=S.font(29))
F = S.font(27, "Bold")
for ri, row in enumerate(CELLS):
    y0 = 170 + ri * (CELLH + 80)
    for ci, cell in enumerate(row):
        x0 = M + ci * (COLW + GX)
        if cell is None:
            bul = ["Krk sa vytlačí ako dve polovice – predná a zadná. Vnútri sú plné, len s presným lôžkom pre servo a kanálikom pre kábel.",
                   "Servo (s odstrihnutými úchytkami) zapadne do lôžka a polovice ho zovrú – nepohne sa ani nepretočí.",
                   "Polovice stiahnu 2 skrutky M2 dole na krku; hore ich vedú 2 kolíky. Dolná časť krku je vždy v trupe, aj keď je vysunutý.",
                   "Páka serva sa priskrutkuje do uška hlavy zvnútra hlavy, ložisko a dutý čap sa vkladajú zvnútra – zvonka žiadna diera.",
                   "Kábel z hlavy ide dutým čapom a kanálikom v krku dole do trupu."]
            by = y0 + 40
            for i, t in enumerate(bul):
                d.ellipse((x0, by + 4, x0 + 36, by + 40), fill=OR)
                d.text((x0 + 18, by + 22), str(i + 1), fill="white", font=S.font(23, "Bold"), anchor="mm")
                for ln in textwrap.wrap(t, 46):
                    d.text((x0 + 54, by), ln, fill=INK, font=S.font(31)); by += 42
                by += 24
            continue
        k, lab, calls = cell
        d.text((x0, y0), lab, fill=OR, font=S.font(36, "Bold"))
        im, bb = load(k)
        f = min(COLW / (bb[2] - bb[0]), (CELLH - 70) / (bb[3] - bb[1]))
        c = im.crop(bb).resize((round((bb[2] - bb[0]) * f), round((bb[3] - bb[1]) * f)), Image.LANCZOS)
        px = x0 + (COLW - c.size[0]) // 2; py = y0 + 60 + (CELLH - 70 - c.size[1]) // 2
        out.paste(c, (px, py), c)
        if calls:
            vm = json.load(open(f"{B}/{k}/views.json"))["views"]["v"]
            for txt, p, off in calls:
                ax_, ay_ = S.project(vm, p)
                ax_, ay_ = px + (ax_ - bb[0]) * f, py + (ay_ - bb[1]) * f
                tw = d.textlength(txt, font=F)
                lx = min(max(x0 + 4, ax_ + off[0]), x0 + COLW - tw - 10)
                ly = min(max(y0 + 60, ay_ + off[1]), y0 + CELLH - 40)
                ex = lx - 4 if lx > ax_ else lx + tw + 8
                d.line((ex, ly + 16, ax_, ay_), fill=OR, width=3)
                d.ellipse((ax_ - 6, ay_ - 6, ax_ + 6, ay_ + 6), fill=OR)
                d.rounded_rectangle((lx - 6, ly - 4, lx + tw + 8, ly + 36), 8, fill=(255, 255, 255))
                d.text((lx, ly), txt, fill=OR, font=F)
out.save(OUT, optimize=True); print(out.size)
