"""NOVA mini - SHARED hollow head, revision E2 (real display dimensions, bezel + magnets, smooth exterior).
World mm, Z up, front -Y, robot right -X.  Every public function takes HZ = world z of the head bottom (B: 27 with
the neck extended) and returns solids already in world position.

Head-local frame (before +HZ): bottom z=0, centre y=0, head centre z ZC_L() = H/2 = 39.5, front face y = -33.

EXTERIOR (E2s): W 110 x H 79 x D 66, front-view superellipse N = 5, CURVATURE-CONTINUOUS side profile (see ab()):
  front round y -33..-24 (exponent 2.4, equal inset 7.5), straight y -24..-6, squircle back y -6..33 (exponent 3.5)
  down to a 15 x 11 closing cap; no prism->round line, no flat back plate (user: the back looked like a cube).
  Sections: 144 points evenly spaced in arc length; loft stations every 1.2 mm along the profile arc.
  Internal features are clipped 0.4 inside the exterior (clip_inside) - never on the exterior face itself.

FRONT STACK (y, local) - DEVIATIONS from E2 marked (*):
  -33.0          bezel front (flat), window 90.0 x 58.6 R4.8, front edge R0.7 (*E2: R1.0)
  -33.0..-31.3   bezel lip 1.7 (*E2: 1.5 - with 1.5 / R1.0 the lip is 0.84..1.07 at the window / pocket corners)
  -31.3..-31.0   foam gasket (pena_displeja), 0.5 free -> 0.3
  -31.0..-29.9   cover glass 92.44 x 61.00 R6 x 1.10 in the pocket 92.84 x 61.40 R6.2      (*E2: -31.2..-30.1)
  -29.9..-25.1   LCD module + frame            -25.1..-23.5  PCB 78.0 x 54.6 (back face = 7.50 behind the glass front)
  -23.5..-19.5   4 x M2 standoffs D3.8 x 4.0: their ENDS are 11.50 behind the glass front (official side view: the
                 7.50 dimension ends on the PCB back, 11.50 on the standoff ends) = MOUNTING PLANE Y_MP (*E2: -23.7)
  -23.5..-18.5   2x16 female header, 5.0 tall = 12.5 behind the glass front - the tallest part (*E2: 11.5)
  -19.5..-16.5   carrier bars (drziak_displeja) 3.0 thick on the standoff ends and on the 4 bezel posts
  -26.0          colour break: bezel flange face = shell rim face, V-seam 0.25 x 0.12
  -26.0..-25.1   bezel spigot (shrink 1.6) in the shell rabbet (shrink 1.5, floor -25.0)
  -25.0          magnet faces (6 pairs D4 x 2: bezel ring / shell bosses)
INTEGRATION (build.py): head_parts(HZ, cuts, adds) is the registry fragment used by build_all(); the cable bridge deck
top is at local z 9.1 (was 7.6) so the servo lead runs level from the floor slot over the -X pad onto the deck;
header_pin(n) gives the plug positions for the servo lead (pin 4) and the head wires (pin 2).
"""
import sys, math, functools, io
sys.path.insert(0, "/home/user/Robot"); sys.path.insert(0, "/tmp/claude-0/pan16")
from build123d import (Pos, Rot, Box, Cylinder, Sphere, Axis, Location, Solid, Compound, Edge, Wire, Vector, Plane,
                       fillet, chamfer, export_brep, import_brep)
import softhead as SH

# ---------------------------------------------------------------- exterior (head-local, mm)
W, H, D, N = 110.0, 79.0, 66.0, 5.0
YF, YB = -D / 2, D / 2
R_FRONT, FRONT_IN = 9.0, 7.5              # front round: 9 deep, EQUAL inset 7.5 in x and z (quarter ellipse)
R_BACK, BACK_F = 30.0, 0.30               # (round 5 back round - replaced by the squircle back below, kept for reports)
FRONT_P = 2.4                             # E2s: front round exponent (2 = ellipse, G1 to the side; > 2 = G2, no line)
BACK_Y0, BACK_M, BACK_KE = -6.0, 3.5, 0.14   # E2s: squircle back from y -6 to the pole: k = (1 - t^M)^(1/M), G2 at
                                          # y -6 (no prism->round line, no flat back plate); loft ends at k = 0.14
Y_END = BACK_Y0 + (YB - BACK_Y0) * (1 - BACK_KE ** BACK_M) ** (1 / BACK_M)   # 32.99 last section (tiny closing cap)
SEC_N = 144                               # points per section (evenly spaced in ARC LENGTH, start at the TOP centre)
STA_DS = 1.2                              # loft stations every 1.2 mm along the side-profile arc (front, middle, back)
WALL = 2.5                                # nominal shell wall
Y_SEAM = -26.0                            # colour break: black bezel y -33..-26, white shell from -26 back
RAB_SH, RAB_D = 1.5, 1.0                  # shell rabbet: sec(Y_SEAM, 1.5) cut 1.0 deep -> floor y = -25.0
SPIG_SH, SPIG_GAP = 1.6, 0.1              # bezel spigot sec(Y_SEAM, 1.6): 0.1 radial, 0.1 axial clearance
Y_RAB = Y_SEAM + RAB_D                    # -25.0 rabbet floor = magnet face plane
Y_BB = Y_RAB - SPIG_GAP                   # -25.1 bezel back face (spigot end)
V_CH = 0.12                               # seam V: chamfer 0.12 x 45 deg on the bezel edge and on the shell rim edge
INNER_Y0, INNER_Y1 = YF + WALL, 29.5      # cavity loft range (starts inside the bezel zone, cut off by the rabbet)

# ---------------------------------------------------------------- display: Waveshare ESP32-S3-Touch-LCD-3.5B, bare
GLASS_W, GLASS_H, GLASS_R, GLASS_T = 92.44, 61.00, 6.00, 1.10
AA_W, AA_H = 73.44, 48.96                 # active area, centred on the glass
SO_X, SO_Z = 36.0, 24.25                  # M2 standoffs: pattern 72.00 x 48.50 centred on the glass
SO_D, SO_L = 3.8, 4.0                     # standoff OD (measured 3.75..3.9), length (11.50 - 7.50)
DEP_PCB, DEP_MP, DEP_HDR = 7.50, 11.50, 12.50   # depth behind the glass FRONT: PCB back / standoff ends / header top
PCB_W, PCB_H, PCB_T, PCB_R = 78.0, 54.6, 1.6, 1.0   # measured on the official back view (72 + 2 x 3.0, 48.5 + 2 x 3.05)
LCD_X0, LCD_X1, LCD_H = -43.2, 43.2, 55.5       # LCD module + metal frame behind the glass (measured, side view)
FPC_X1 = 44.5                             # LCD FPC bend sticks out of the +X side of the module (to 44.5)
HDR_L, HDR_W, HDR_Z = 40.9, 5.2, -24.25   # 2x16 female header, centre line on the lower standoff row
NOTCH = 5.5                               # keep-out is absent in the 5.5 x 5.5 PCB corner zones (standoff + bar tab)
# ---------------------------------------------------------------- bezel (ram_displeja)
WIN_W, WIN_H, WIN_R, WIN_FIL = 90.0, 58.6, 4.8, 0.7   # E2 says R1.0: R0.7 + lip 1.7 keep every lip wall >= 1.2
LIP_T = 1.7                               # E2 says 1.5: 1.7 keeps >= 1.2 at the pocket / window corners (see checks)
POCK_W, POCK_H, POCK_R = GLASS_W + 0.4, GLASS_H + 0.4, 6.2
GASK_W, GASK_T, GASK_IN = 1.0, 0.3, 0.1   # foam frame width, compressed thickness, inset from the glass edge
Y_LIP = YF + LIP_T                        # -31.3 lip back face
Y_G0 = Y_LIP + GASK_T                     # -31.0 glass front
Y_PCB = Y_G0 + DEP_PCB                    # -23.5 PCB back face
Y_MP = Y_G0 + DEP_MP                      # -19.5 mounting plane: standoff ends = post faces = bar front face
Y_HDR = Y_G0 + DEP_HDR                    # -18.5 header top
POST_X, POST_Z, POST_D = 21.0, 33.65, 5.86    # 4 bezel posts (top / bottom ring) with glued M2 inserts, wall 1.23
INS_D, INS_L, INS_OD, INS_LEN = 3.4, 4.0, 3.2, 3.0   # insert hole D3.4 x 4.0, brass insert OD 3.2 x 3.0
BAR_T = 3.0                               # carrier bar thickness (y -19.5..-16.5)
BAR_Z0, BAR_Z1 = 27.8, 30.2               # beam |z - ZC| range: 0.5 outside the PCB edge (27.3), inside the magnet bosses
BAR_XE = 38.4                             # beam half length
TAB_R, LUG_R = 2.4, 2.8                   # pad radius at the standoff holes / at the post holes
SCR_DK, SCR_K = 3.8, 1.3                  # ISO 7380-1 M2 button head
# ---------------------------------------------------------------- magnets (6 pairs N35 D4 x 2)
MAG_D, MAG_T, MAG_HOLE, MAG_DEPTH, MAG_SUB = 4.0, 2.0, 4.2, 2.1, 0.05
MAG_XT = 29.0                             # |x| of the 4 top/bottom pairs (clear of the D4 service tool at |x| <= 24.3)
MBOSS_R, MBOSS_Y1 = 3.33, -21.67          # shell boss radius (wall 1.23) and back face (pocket floor wall 1.23)
# ---------------------------------------------------------------- ear pods (E1 section 3)
EAR_Y, EAR_R, EAR_CL = -1.0, 13.0, 0.15
EAR_X0, EAR_X1 = W / 2 - 4.5, W / 2 + 1.5      # pod inner face / cylinder-dome edge (1.5 proud of the side x=55)
DOME_R, POD_FIL = 38.0, 1.5
LIP_R0, LIP_TE, BOSS_R = 11.0, 1.5, 16.0  # ear seat lip (inner r, thickness) and boss outer r
RING_R0, RING_R1, GROOVE_CL, GROOVE_D = 8.6, 10.5, 0.1, 1.65
LED_HOLE_R, LED_HOLE_PCD = 0.8, 9.55
EAR_HOLE_FIL = 0.8                        # round on the white hole edge
# ---------------------------------------------------------------- cable bridge for the servo lead (floor, -X side)
# integration: deck top raised 7.6 -> 9.1 so the lead (r 1.3, centre local z 10.4) runs LEVEL from the floor slot over
# the -X pad (top 8.5, 0.6 under the lead) onto the deck; the tunnel under the deck is unchanged (deck 3.3 thick)
BRIDGE = dict(x0=-37.5, x1=-30.5, hy=2.2, foot=2.0, z_deck0=5.8, z_deck1=9.1)


def ZC_L():
    return H / 2


def ab(y):
    """semi-axes (a, b) of the exterior section at depth y (E2s - curvature-continuous everywhere):
    front zone y -33..-24: s=(-24-y)/9, u = 7.5 (1 - (1 - s^P)^(1/P)), a = W/2 - u, b = H/2 - u   (P = 2.4: G2 at -24)
    middle     y -24..-6 : a = W/2, b = H/2
    back       y -6..33  : t = (y+6)/39, k = (1 - t^M)^(1/M), a = W/2 k, b = H/2 k            (M = 3.5: G2 at -6)"""
    a, b = W / 2, H / 2
    if y > BACK_Y0:
        t = min(1.0, (y - BACK_Y0) / (YB - BACK_Y0))
        k = (1 - t ** BACK_M) ** (1 / BACK_M)
        a, b = a * k, b * k
    if y < YF + R_FRONT:
        s = min(1.0, ((YF + R_FRONT) - y) / R_FRONT)
        u = FRONT_IN * (1 - max(0.0, 1 - s ** FRONT_P) ** (1 / FRONT_P))
        a, b = a - u, b - u
    return a, b


def se_r(a, b, th):
    """polar radius of the superellipse |x/a|^N + |z/b|^N = 1 at polar angle th (rad, from +x toward +z)"""
    c, s = abs(math.cos(th)), abs(math.sin(th))
    return ((c / a) ** N + (s / b) ** N) ** (-1.0 / N)


@functools.lru_cache(maxsize=4096)
def _se_arc_pts(a, b, count):
    """superellipse points evenly spaced in ARC LENGTH (dense polar sample resampled), starting at the top centre"""
    n = 6000
    P = []
    for i in range(n + 1):
        th = math.pi / 2 + 2 * math.pi * i / n
        r = se_r(a, b, th)
        P.append((r * math.cos(th), r * math.sin(th)))
    S = [0.0]
    for i in range(1, len(P)):
        S.append(S[-1] + math.hypot(P[i][0] - P[i - 1][0], P[i][1] - P[i - 1][1]))
    out, j = [], 0
    for k in range(count):
        tg = S[-1] * k / count
        while S[j + 1] < tg:
            j += 1
        f = (tg - S[j]) / (S[j + 1] - S[j])
        out.append((P[j][0] + f * (P[j + 1][0] - P[j][0]), P[j][1] + f * (P[j + 1][1] - P[j][1])))
    return tuple(out)


def wire_ab(a, b, y, count=SEC_N):
    """closed periodic spline of the superellipse (a, b, N) in the plane y, centre z = H/2; points evenly spaced in ARC
    LENGTH (E2s: no parameterisation ripple on the flat sides) starting at the TOP centre (the loft seam runs over the
    top of the head, away from every feature)"""
    pts = [Vector(x, y, H / 2 + z) for x, z in _se_arc_pts(round(a, 9), round(b, 9), count)]
    return Wire([Edge.make_spline(pts, periodic=True, parameters=[i / count for i in range(count + 1)])])


def sec(y, shrink=0.0, count=SEC_N):
    """exterior section wire at depth y, semi-axes reduced by shrink (replaces softhead.sec)"""
    a, b = ab(y)
    return wire_ab(a - shrink, b - shrink, y, count)


def stations(y0, y1, ds=STA_DS):
    """loft stations y0..y1 evenly spaced (ds) along the arc of the side profile (y, a(y)) - E2s: the same spacing in
    the front round, the middle and the back (uneven spacing / profile kinks made the interpolating loft ripple)"""
    n = 20000
    yy = [y0 + (y1 - y0) * i / n for i in range(n + 1)]
    aa = [ab(y)[0] for y in yy]
    S = [0.0]
    for i in range(1, len(yy)):
        S.append(S[-1] + math.hypot(yy[i] - yy[i - 1], aa[i] - aa[i - 1]))
    m = max(2, int(round(S[-1] / ds)))
    res, j = [], 0
    for k in range(m + 1):
        tg = S[-1] * k / m
        while j < len(S) - 2 and S[j + 1] < tg:
            j += 1
        f = (tg - S[j]) / max(1e-12, S[j + 1] - S[j])
        res.append(yy[j] + f * (yy[j + 1] - yy[j]))
    return res


BACK_CUT = 0.02                           # E2s: the closing cap zone is sliced 0.02 behind the last section Y_END


def _outer_solid():
    """exterior loft: 4 sections IN the front plane (flat front tangent to the front round) + stations along the whole
    profile + 2 sections IN the plane Y_END (the squircle back meets its tiny 15 x 11 closing cap tangentially, the cap
    is sliced 0.02 behind it).  E2s: no prism->round line at y 3 and no flat back plate any more."""
    a0, b0 = ab(YF)
    a1, b1 = ab(Y_END)
    secs = [wire_ab(a0 - k, b0 - k, YF) for k in (4.0, 3.0, 2.0, 1.0)]
    secs += [sec(y) for y in stations(YF, Y_END)]
    secs += [wire_ab(a1 * f, b1 * f, Y_END) for f in (0.7, 0.4)]
    return _one(Solid.make_loft(secs) & box(-W, W, YF - 5, Y_END - BACK_CUT, -10, H + 10))


def _factor(y):
    return ab(y)[0] / (W / 2)


def setup():
    """patch softhead to the E2 exterior (idempotent) and clear the caches"""
    SH.W, SH.H, SH.N, SH.D, SH.YF, SH.YB = W, H, N, D, YF, YB
    SH.sec, SH.factor, SH.outer = sec, _factor, _outer_solid
    for f in (_outer_l, _inner_l, _outer_in_l, _shell_base_l, _bezel_l, _front_zone_l, _pods_l, _rings_l, _mag_pts):
        f.cache_clear()


def _w(s, HZ):
    return s.moved(Location((0, 0, HZ)))


def xcyl(r, x0, x1, y, z):
    x0, x1 = sorted((x0, x1))
    return Pos((x0 + x1) / 2, y, z) * Rot(0, 90, 0) * Cylinder(r, x1 - x0)


def ycyl(r, y0, y1, x, z):
    y0, y1 = sorted((y0, y1))
    return Pos(x, (y0 + y1) / 2, z) * Rot(90, 0, 0) * Cylinder(r, y1 - y0)


def zcyl(r, z0, z1, x, y):
    z0, z1 = sorted((z0, z1))
    return Pos(x, y, (z0 + z1) / 2) * Cylinder(r, z1 - z0)


def box(x0, x1, y0, y1, z0, z1):
    return Pos((x0 + x1) / 2, (y0 + y1) / 2, (z0 + z1) / 2) * Box(abs(x1 - x0), abs(y1 - y0), abs(z1 - z0))


def rbox_y(w, h, r, y0, y1, zc, x=0.0):
    b = Pos(x, (y0 + y1) / 2, zc) * Box(w, y1 - y0, h)
    return fillet(b.edges().filter_by(Axis.Y), r) if r > 0 else b


def prism_y(shrink, y_sec, y0, y1):
    """straight prism (along Y) of the exterior section taken at y_sec"""
    a, b = ab(y_sec)
    return Solid.make_loft([wire_ab(a - shrink, b - shrink, y0), wire_ab(a - shrink, b - shrink, y1)])


def _one(s):
    """single solid as a FRESH Solid wrapper (build123d's solids()[0] keeps topo_parent -> later fillet() calls would
    look for their edges in the old parent and fail with 'no suitable edges')"""
    if hasattr(s, "solids"):
        sl = s.solids()
        if len(sl) == 1:
            return Solid(sl[0].wrapped)
    return s


def _rt(shape):
    """BREP round trip (in memory) - normalises the loft B-rep before the booleans / fillets"""
    from OCP.BRepTools import BRepTools
    from OCP.BRep import BRep_Builder
    from OCP.TopoDS import TopoDS_Shape
    buf = io.BytesIO()
    BRepTools.Write_s(shape.wrapped, buf)
    buf.seek(0)
    out = TopoDS_Shape()
    BRepTools.Read_s(out, buf, BRep_Builder())
    return _one(Compound(out))


def _dA(y, h=1e-3):
    return (ab(y + h)[0] - ab(y - h)[0]) / (2 * h)


def inner_shrink(y):
    """2.5 everywhere; in the big back round the section shrink is increased to 2.5*sqrt(1+(da/dy)^2) so the
    NORMAL wall stays ~2.5 (a constant 2.5 section shrink leaves only 0.8 mm at the back)."""
    return WALL * math.sqrt(1 + _dA(y) ** 2) if y > BACK_Y0 else WALL


@functools.lru_cache(None)
def _outer_l():
    return _rt(_outer_solid())


@functools.lru_cache(None)
def _inner_l():
    return _rt(Solid.make_loft([sec(y, shrink=inner_shrink(y)) for y in stations(INNER_Y0, INNER_Y1)]))


def _front_box():
    """everything in front of the colour break"""
    return box(-W, W, YF - 5, Y_SEAM, -10, H + 10)


@functools.lru_cache(None)
def _front_zone_l():
    """exterior volume in front of the colour break (the bezel's outer form = the SAME loft as the shell)"""
    return _one(_outer_l() & _front_box())


def head_outer(HZ):
    """full exterior volume of the head (white shell zone + black bezel zone), solid"""
    return _w(_outer_l(), HZ)


def inner_skin(HZ):
    """cavity solid: loft of sec(y, shrink 2.5) (slope-compensated in the back round), y -30.5..29.5; in front of
    y=-25 it lies inside the bezel / rabbet zone"""
    return _w(_inner_l(), HZ)


CLIP_IN = 0.4                             # E2s: internal features are clipped this much INSIDE the exterior


@functools.lru_cache(None)
def _outer_in_l():
    """the exterior shrunk by CLIP_IN (same stations, sections shrink 0.4): clipping internal features with it keeps
    them 0.4 inside the skin, overlapping the 2.5 wall - never on the exterior B-spline face itself (coincident faces
    made the fuse with the shell invalid once the sections were resampled in arc length)"""
    return _rt(Solid.make_loft([sec(y, shrink=CLIP_IN) for y in stations(YF + 0.5, Y_END - 1.0)]))


def clip_inside(shape, HZ):
    """helper for variants: clip an internal feature 0.4 inside the WHITE shell's exterior (never shows outside)"""
    return shape & _w(_outer_in_l() - _front_box(), HZ)


def _v_cutter(sgn):
    """seam V: ring that chamfers the outer edge at y=Y_SEAM by V_CH x 45 deg; sgn -1 = bezel side (material at
    y < seam), +1 = shell side.  A cone through (Y_SEAM + sgn*V_CH, true surface) and (Y_SEAM, surface - V_CH) is
    extended both ways (it crosses the exterior transversally and is outside it beyond the chamfer start; on the
    bezel side it stays 0.8 clear of the spigot); everything outside the cone within +-1 mm of the seam is removed."""
    c = V_CH
    ys = Y_SEAM + sgn * c
    a0, b0 = ab(ys)
    a1, b1 = ab(Y_SEAM)
    a1, b1 = a1 - c, b1 - c

    def w(y):
        t = (ys - y) / (ys - Y_SEAM)
        return wire_ab(a0 + (a1 - a0) * t, b0 + (b1 - b0) * t, y)
    fr = Solid.make_loft([w(Y_SEAM - 1.2), w(Y_SEAM + 1.2)])
    return box(-W, W, Y_SEAM - 1.0, Y_SEAM + 1.0, -10, H + 10) - fr


# ---------------------------------------------------------------- magnets
@functools.lru_cache(None)
def _mag_pts():
    """(x, z_local, ux, uz): 6 magnet axes (along Y), centred in the bezel ring between the glass pocket and the
    spigot outline; (ux, uz) = outward direction toward the shell wall"""
    a, b = ab(Y_SEAM)
    a, b = a - SPIG_SH, b - SPIG_SH
    xs = (POCK_W / 2 + a) / 2
    zt = b * (1 - (MAG_XT / a) ** N) ** (1 / N)              # spigot outline at x = MAG_XT
    zm = (POCK_H / 2 + zt) / 2
    pts = [(sx * xs, H / 2, sx, 0) for sx in (-1, 1)]
    pts += [(sx * MAG_XT, H / 2 + sz * zm, 0, sz) for sx in (-1, 1) for sz in (-1, 1)]
    return tuple((round(x, 3), round(z, 3), ux, uz) for x, z, ux, uz in pts)


def magnet_positions(HZ=0.0):
    """[(x, z_world)] of the 6 magnet axes (parallel to Y)"""
    return [(x, z + HZ) for x, z, _, _ in _mag_pts()]


def magnets(HZ):
    """dict(bezel=..., shell=...): 6 + 6 N35 discs D4 x 2, axial; bezel side y -27.15..-25.15 (0.05 below the bezel
    back face -25.1), shell side y -24.95..-22.95 (0.05 below the rabbet-floor plane -25.0) -> 0.2 between the
    magnet faces.  Glue with opposite poles facing; mark polarity before gluing."""
    bz = [ycyl(MAG_D / 2, Y_BB - MAG_SUB - MAG_T, Y_BB - MAG_SUB, x, z) for x, z, _, _ in _mag_pts()]
    sh = [ycyl(MAG_D / 2, Y_RAB + MAG_SUB, Y_RAB + MAG_SUB + MAG_T, x, z) for x, z, _, _ in _mag_pts()]
    return dict(bezel=_w(Compound(bz), HZ), shell=_w(Compound(sh), HZ))


def _mag_bosses_l():
    """shell side: D6.6 boss around every magnet axis, webbed out to the wall, clipped by the inner skin"""
    cav, out = _inner_l(), []
    for x, z, ux, uz in _mag_pts():
        c = ycyl(MBOSS_R, Y_RAB - 0.6, MBOSS_Y1, x, z)
        if ux:
            web = box(x, x + ux * 9.0, Y_RAB - 0.6, MBOSS_Y1, z - MBOSS_R, z + MBOSS_R)
        else:
            web = box(x - MBOSS_R, x + MBOSS_R, Y_RAB - 0.6, MBOSS_Y1, z, z + uz * 9.0)
        out.append(_one((c + web) & cav))
    return out


# ---------------------------------------------------------------- bezel (ram_displeja) - opaque black, gloss paint
def post_positions(HZ=0.0):
    """[(x, z_world)] of the 4 bezel posts (insert axes, along Y)"""
    return [(sx * POST_X, HZ + H / 2 + sz * POST_Z) for sx in (-1, 1) for sz in (-1, 1)]


@functools.lru_cache(None)
def _bezel_l():
    zc = H / 2
    b = _front_zone_l() - rbox_y(WIN_W, WIN_H, WIN_R, YF - 3, Y_LIP + 0.2, zc)          # window through the lip
    eds = [e for e in b.edges() if e.center().Y < YF + 0.6 and abs(e.center().X) < WIN_W / 2 + 0.5
           and abs(e.center().Z - zc) < WIN_H / 2 + 0.5 and e.length > 0.5]
    b = fillet(eds, WIN_FIL)                                                             # soft window edge R0.7
    b = b + prism_y(SPIG_SH, Y_SEAM, Y_SEAM - 1.0, Y_BB)                                 # spigot
    b = b - rbox_y(POCK_W, POCK_H, POCK_R, Y_LIP, Y_BB + 1.0, zc)                        # glass pocket, open behind
    b = b - _v_cutter(-1)
    for x, z in post_positions():
        b = b + ycyl(POST_D / 2, Y_SEAM - 0.5, Y_MP, x, z)
    for x, z in post_positions():
        b = b - ycyl(INS_D / 2, Y_MP - INS_L, Y_MP + 1.0, x, z)
    for x, z, _, _ in _mag_pts():
        b = b - ycyl(MAG_HOLE / 2, Y_BB - MAG_DEPTH, Y_BB + 1.0, x, z)
    return _one(b)


def bezel(HZ):
    """ram_displeja: ONE opaque black part.  Outer form = the head loft for y -33..-26 (step 0 to the shell), flange
    face y=-26 on the shell rim, V-chamfer 0.12, spigot sec(-26, 1.6) to y=-25.1; window 90.0 x 58.6 R4.8 with the
    front edge R0.7, lip 1.7; glass pocket 92.84 x 61.40 R6.2 open to the back; 4 posts D5.86 to the mounting plane
    y=-19.5 with D3.4 x 4.0 insert holes; 6 magnet pockets D4.2 x 2.1 in the back face."""
    return _w(_bezel_l(), HZ)


def gasket(HZ):
    """pena_displeja: closed-cell foam frame 1.0 wide on the lip back face, drawn COMPRESSED (0.5 -> 0.3),
    outline = glass - 0.1 per side"""
    zc = H / 2
    wo, ho, ro = GLASS_W - 2 * GASK_IN, GLASS_H - 2 * GASK_IN, GLASS_R - GASK_IN
    g = rbox_y(wo, ho, ro, Y_LIP, Y_G0, zc) - rbox_y(wo - 2 * GASK_W, ho - 2 * GASK_W, ro - GASK_W, Y_LIP - 1, Y_G0 + 1, zc)
    return _w(_one(g), HZ)


# ---------------------------------------------------------------- display model (official drawing, bare board)
def header_pin(n, HZ=0.0):
    """world (x, y, z) of the mouth of header pin n (1..32) on the header top face.  Pin 1 (BAT) / 2 (5V) are at the
    +X end; odd pins = outer row (toward the PCB bottom edge), even pins = inner row.
    Row order from +X: odd  BAT G 21 38 39 40 41 42 45 46 47 48 TX RX G 3V3;  even 5V G 19 20 11 10 9 17 18 0 RST PWR
    SCL SDA G 3V3."""
    col = (n - 1) // 2
    x = 2.54 * 7.5 - 2.54 * col
    z = H / 2 + HDR_Z + (-1.27 if n % 2 else 1.27)
    return (x, Y_HDR, z + HZ)


def _yd(d):
    return Y_G0 + d


def _display_l():
    zc = H / 2
    d = {}
    d["glass"] = rbox_y(GLASS_W, GLASS_H, GLASS_R, Y_G0, Y_G0 + GLASS_T, zc)
    yl0, yp0 = Y_G0 + GLASS_T, Y_PCB - PCB_T
    lcd = box(LCD_X0, LCD_X1, yl0, yp0, zc - LCD_H / 2, zc + LCD_H / 2)
    lcd = fillet(lcd.edges().filter_by(Axis.Y), 1.0)
    d["lcd"] = lcd + box(LCD_X1 - 1.0, FPC_X1, yl0 + 1.0, Y_PCB, zc - 9.5, zc + 21.4)     # + LCD FPC bend (+X side)
    pcb = rbox_y(PCB_W, PCB_H, PCB_R, yp0, Y_PCB, zc)
    so, soh = [], []
    for sx in (-1, 1):
        for sz in (-1, 1):
            x, z = sx * SO_X, zc + sz * SO_Z
            so.append(ycyl(SO_D / 2, Y_PCB, Y_MP, x, z) - ycyl(0.8, Y_PCB - 0.5, Y_MP + 0.5, x, z))
    d["pcb"] = pcb
    d["standoffs"] = Compound(so)
    d["header"] = box(-HDR_L / 2, HDR_L / 2, Y_PCB, Y_HDR, zc + HDR_Z - HDR_W / 2, zc + HDR_Z + HDR_W / 2)
    d["usbc"] = fillet(box(31.8, 40.2, Y_PCB, Y_PCB + 3.2, zc - 4.47, zc + 4.47).edges().filter_by(Axis.X), 1.2)
    small = [box(-33.7, -16.3, Y_PCB, Y_PCB + 1.9, zc + 12.25, zc + 27.0)]                 # TF socket
    small += [box(x - 2.75, x + 2.75, Y_PCB, Y_PCB + 2.0, zc + 22.6, zc + 27.3) for x in (25.0, 16.5, 8.0)]  # PWR RESET BOOT
    small.append(box(-3.5, 4.7, Y_PCB, Y_PCB + 3.4, zc + 18.8, zc + 23.4))                 # SPK (MX1.25 2P)
    small.append(box(20.9, 28.6, Y_PCB, Y_PCB + 3.4, zc - 26.65, zc - 20.6))               # BAT (MX1.25 2P)
    small.append(box(28.85, 33.4, Y_PCB, Y_PCB + 3.0, zc - 24.95, zc - 20.85))             # RTC_BKP
    small.append(box(9.3, 16.0, Y_PCB, Y_PCB + 2.0, zc - 12.4, zc + 12.25))                # LCD FFC connector
    small.append(box(16.0, 22.1, Y_PCB, Y_PCB + 0.6, zc - 11.0, zc + 11.0))                # LCD FPC tail on the PCB
    small.append(box(-20.45, -14.4, Y_PCB, Y_PCB + 2.0, zc - 8.5, zc + 8.1))               # touch FFC connector
    small.append(box(-31.0, -22.5, Y_PCB, Y_PCB + 1.0, zc - 12.3, zc + 3.0))               # ESP32-S3R8 + flash zone
    small.append(box(-39.0, -36.0, Y_PCB, Y_PCB + 1.3, zc - 17.5, zc - 13.5))              # IPEX
    d["small"] = Compound(small)
    # keep-out: everything behind the PCB to the 11.50 plane, except the 4 corner zones (standoff + bar tab), and
    # the header + plug zone up to 12.50
    ko = box(-PCB_W / 2, PCB_W / 2, Y_PCB, Y_MP, zc - PCB_H / 2, zc + PCB_H / 2)
    for sx in (-1, 1):
        for sz in (-1, 1):
            xc, zcn = sx * (PCB_W / 2 - NOTCH / 2 + 0.5), zc + sz * (PCB_H / 2 - NOTCH / 2 + 0.5)
            ko = ko - Pos(xc, (Y_PCB + Y_MP) / 2, zcn) * Box(NOTCH + 1.0, Y_MP - Y_PCB + 1.0, NOTCH + 1.0)
    ko = ko + box(-HDR_L / 2 - 0.5, HDR_L / 2 + 0.5, Y_MP - 0.1, Y_HDR, zc + HDR_Z - HDR_W / 2 - 0.5,
                  zc + HDR_Z + HDR_W / 2 + 0.5)
    d["keepout"] = _one(ko)
    return d


def display_parts(HZ):
    """dict of separate solids (world): glass (92.44 x 61 R6 x 1.10), lcd (LCD module + frame + FPC bend), pcb
    (78.0 x 54.6 x 1.6, back face 7.50 behind the glass front), standoffs (4 x M2 D3.8 x 4.0 at +-36.0 / +-24.25,
    ends 11.50 behind the glass front), header (2x16 female, 5.0 tall), usbc (robot +X side), small (TF, 3 buttons,
    JST SPK/BAT/RTC, FFC connectors, IPEX - real heights), keepout (virtual: PCB footprint to the 11.50 plane minus the
    four 5.5 x 5.5 corner zones, plus the header zone to 12.50; NOT a part - do not put it in the registry)."""
    return {k: _w(v, HZ) for k, v in _display_l().items()}


def eyes(HZ):
    """oci_len_vizualizacia: two vertical pills 10 x 17.5 (R4.9), 0.05 thick, 0.01 in front of the glass front,
    inside the active area 73.44 x 48.96 (LCD content - do not print)"""
    out = None
    for sx in (-1, 1):
        e = Pos(sx * 11.0, Y_G0 - 0.035, H / 2) * Box(10.0, 0.05, 17.5)
        e = fillet([ed for ed in e.edges() if abs(ed.tangent_at(0.5).Y) > 0.9], 4.9)
        out = e if out is None else out + e
    return _w(out, HZ)


# ---------------------------------------------------------------- carrier (drziak_displeja): 2 printed black bars
def _bar_l(sz):
    """one bar (sz = +1 top, -1 bottom): beam outside the PCB edge, 2 tabs on the standoff ends, 2 lugs on the posts"""
    zc = H / 2
    y0, y1 = Y_MP, Y_MP + BAR_T
    za, zb = sorted((zc + sz * BAR_Z0, zc + sz * BAR_Z1))
    bar = box(-BAR_XE, BAR_XE, y0, y1, za, zb)
    for sx in (-1, 1):
        x, z = sx * SO_X, zc + sz * SO_Z
        bar = bar + ycyl(TAB_R, y0, y1, x, z) + box(x - TAB_R, x + TAB_R, y0, y1, z, zc + sz * (BAR_Z0 + 0.5))
        x, z = sx * POST_X, zc + sz * POST_Z
        bar = bar + ycyl(LUG_R, y0, y1, x, z) + box(x - LUG_R, x + LUG_R, y0, y1, zc + sz * (BAR_Z1 - 0.5), z)
    bar = _one(bar)
    try:                                                    # soften the outline (edges along Y)
        eds = [e for e in bar.edges().filter_by(Axis.Y) if e.length > BAR_T - 0.01]
        cand = fillet(eds, 0.5)
        if cand.is_valid and len(cand.solids()) == 1:
            bar = cand
    except Exception:
        pass
    for sx in (-1, 1):
        bar = bar - ycyl(1.1, y0 - 1, y1 + 1, sx * SO_X, zc + sz * SO_Z) - ycyl(1.1, y0 - 1, y1 + 1, sx * POST_X, zc + sz * POST_Z)
    return _one(bar)


def carrier(HZ):
    """dict(bars, inserts, screws): bars = 2 printed bars 3.0 thick (front face on the mounting plane y=-19.5);
    inserts = 4 x M2 brass OD 3.2 x 3.0 glued flush in the post holes; screws = 4 x M2x5 (bar -> standoff, 2.0 in the
    standoff) + 4 x M2x6 (bar -> insert, 3.0 in the insert), ISO 7380-1 button head dk 3.8 x k 1.3"""
    zc = H / 2
    bars = Compound([_bar_l(1), _bar_l(-1)])
    ins, scr = [], []
    yb = Y_MP + BAR_T
    for x, z in post_positions():
        ins.append(ycyl(INS_OD / 2, Y_MP - INS_LEN, Y_MP, x, z) - ycyl(0.85, Y_MP - INS_LEN - 0.5, Y_MP + 0.5, x, z))  # bore 0.05 over the modelled shank: no coincident faces in the STL
        scr.append(ycyl(SCR_DK / 2, yb, yb + SCR_K, x, z) + ycyl(0.8, yb - 6.0, yb, x, z))
    for sx in (-1, 1):
        for sz in (-1, 1):
            x, z = sx * SO_X, zc + sz * SO_Z
            scr.append(ycyl(SCR_DK / 2, yb, yb + SCR_K, x, z) + ycyl(0.8, yb - 5.0, yb, x, z))
    return dict(bars=_w(bars, HZ), inserts=_w(Compound(ins), HZ), screws=_w(Compound(scr), HZ))


# ---------------------------------------------------------------- ears + light-guide rings + LED boards (E1 s.3)
def _dome_xc():
    """x of the dome sphere centre: sphere R38 through the cylinder edge (r 13, x EAR_X1)"""
    return EAR_X1 - math.sqrt(DOME_R ** 2 - EAR_R ** 2)


def _dome_x(r):
    return _dome_xc() + math.sqrt(DOME_R ** 2 - r * r)


def _groove_floor_x():
    return _dome_x((RING_R0 + RING_R1) / 2) - GROOVE_D


def _ear_axis_pts():
    zc = H / 2
    return [(EAR_Y + LED_HOLE_PCD * math.cos(math.radians(a)), zc + LED_HOLE_PCD * math.sin(math.radians(a)))
            for a in (45, 135, 225, 315)]


def _rev_x(edges):
    """solid of revolution about the ear axis (X through y=EAR_Y, z=H/2) of a closed profile given as edges in the
    plane z = H/2 with coordinates (x, r) -> (x, EAR_Y + r, H/2)"""
    from build123d import Face, revolve
    f = Face(Wire(edges))
    return _one(revolve(f, Axis((0, EAR_Y, H / 2), (1, 0, 0)), 360))


def _P(x, r):
    return Vector(x, EAR_Y + r, H / 2)


SEAM_CH = 0.2                             # edge break (45 deg) on the ring front edges and the groove mouth edges


@functools.lru_cache(None)
def _pods_l():
    """+X pod (the -X one is mirrored): cylinder R13 from the inner face x 50.5, dome R38 (apex 3.8 proud), fillet
    R1.5 cylinder -> dome (built into the revolved profile: exact G1), groove r 8.5..10.6 for the ring with the two
    mouth edges broken 0.2 x 45 deg (revolved cutter), 4 light holes D1.6"""
    zc = H / 2
    xc, R, rho = _dome_xc(), DOME_R, POD_FIL
    xf = xc + math.sqrt((R - rho) ** 2 - (EAR_R - rho) ** 2)          # fillet centre x (= end of the straight cylinder)
    al = math.atan2(EAR_R - rho, xf - xc)                             # direction sphere centre -> fillet centre
    T = (xc + R * math.cos(al), R * math.sin(al))                     # tangent point fillet / dome
    am = (math.pi / 2 + al) / 2
    M = (xf + rho * math.cos(am), EAR_R - rho + rho * math.sin(am))
    S = (xc + R * math.cos(al / 2), R * math.sin(al / 2))
    edges = [Edge.make_line(_P(EAR_X0, 0), _P(EAR_X0, EAR_R)), Edge.make_line(_P(EAR_X0, EAR_R), _P(xf, EAR_R)),
             Edge.make_three_point_arc(_P(xf, EAR_R), _P(*M), _P(*T)),
             Edge.make_three_point_arc(_P(*T), _P(*S), _P(xc + R, 0)), Edge.make_line(_P(xc + R, 0), _P(EAR_X0, 0))]
    pod = _rev_x(edges)
    gf, xa, c = _groove_floor_x(), xc + R, SEAM_CH
    r0, r1 = RING_R0 - GROOVE_CL, RING_R1 + GROOVE_CL
    a1, b1 = (_dome_x(r1) - c, r1), (_dome_x(r1 + c), r1 + c)         # outer mouth chamfer: wall point -> dome point
    a0, b0 = (_dome_x(r0) - c, r0), (_dome_x(r0 - c), r0 - c)
    e1 = (a1[0] + 3 * (b1[0] - a1[0]), a1[1] + 3 * (b1[1] - a1[1]))   # extended beyond the dome
    e0 = (a0[0] + 3 * (b0[0] - a0[0]), a0[1] + 3 * (b0[1] - a0[1]))
    pts = [(gf, r0), (gf, r1), a1, e1, (xa + 2.0, e1[1]), (xa + 2.0, e0[1]), e0, a0]
    cut = _rev_x([Edge.make_line(_P(*pts[i]), _P(*pts[(i + 1) % len(pts)])) for i in range(len(pts))])
    cut = cut.rotate(Axis((0, EAR_Y, zc), (1, 0, 0)), 137.0)      # seam away from the pod seam (coincident seams break the cut)
    pod = _one(pod - cut)
    if not pod.is_valid:
        raise RuntimeError("ear pod groove cut failed")
    for y, z in _ear_axis_pts():
        pod = pod - xcyl(LED_HOLE_R, EAR_X0 - 1.0, gf + 0.01, y, z)
    return _one(pod)


POD_NOTES = {}


@functools.lru_cache(None)
def _rings_l():
    """+X light-guide ring r 8.6..10.5 on the groove floor, front face = the SAME sphere R38 as the pod (flush, step
    0), both front edges broken 0.2 x 45 deg (in the revolved profile)"""
    gf, c = _groove_floor_x(), SEAM_CH
    x0, x1 = _dome_x(RING_R0), _dome_x(RING_R1)
    rm = (RING_R0 + RING_R1) / 2
    edges = [Edge.make_line(_P(gf, RING_R0), _P(gf, RING_R1)), Edge.make_line(_P(gf, RING_R1), _P(x1 - c, RING_R1)),
             Edge.make_line(_P(x1 - c, RING_R1), _P(_dome_x(RING_R1 - c), RING_R1 - c)),
             Edge.make_three_point_arc(_P(_dome_x(RING_R1 - c), RING_R1 - c), _P(_dome_x(rm), rm), _P(_dome_x(RING_R0 + c), RING_R0 + c)),
             Edge.make_line(_P(_dome_x(RING_R0 + c), RING_R0 + c), _P(x0 - c, RING_R0)),
             Edge.make_line(_P(x0 - c, RING_R0), _P(gf, RING_R0))]
    return _rev_x(edges)


def _mirror_x(s):
    return s.mirror(Plane.YZ)


def ears(HZ):
    """usi: 2 black ear pods (satin): R13 cylinder + dome R38 (apex x = +-58.8 = 3.8 proud of the side), fillet R1.5,
    inner face x = +-50.5 on the shell lip, annular groove r 8.5..10.6 for the ring, 4 light holes D1.6 (PCD r 9.55)"""
    p = _pods_l()
    return _w(Compound([p, _mirror_x(p)]), HZ)


def led_rings(HZ):
    """led_kruzky: 2 cyan light-guide rings r 8.6..10.5, flush with the dome sphere (0 step), edges R0.2"""
    r = _rings_l()
    return _w(Compound([r, _mirror_x(r)]), HZ)


def led_boards(HZ):
    """internal: D21 x 1.0 LED PCB + 4 x 1.5x1.5x0.8 RGB LEDs (SK6805-EC15) on the pod back face, inside the lip hole"""
    zc, out = H / 2, None
    for sx in (-1, 1):
        b = xcyl(10.5, sx * (EAR_X0 - 1.8), sx * (EAR_X0 - 0.8), EAR_Y, zc)
        for y, z in _ear_axis_pts():
            b = b + Pos(sx * (EAR_X0 - 0.4), y, z) * Box(0.8, 1.5, 1.5)
        out = b if out is None else out + b
    return _w(out, HZ)


# ---------------------------------------------------------------- shell (hlava_skrupina)
def _bridge_l():
    """printed cable bridge for the servo lead on the floor, -X side beyond the tenon pad: deck along X (the lead
    runs parallel to the hinge axis and is tied onto the deck with a 2.5 mm cable tie through the tunnel).
    Deck top at local z 9.1 = level of the lead coming over the -X pad (see build.lead_path)."""
    B = BRIDGE
    zf = 0.5                                                 # feet start inside the floor wall (outer bottom z ~ 0)
    deck = box(B["x0"], B["x1"], -B["hy"], B["hy"], B["z_deck0"], B["z_deck1"])
    f1 = box(B["x0"], B["x0"] + B["foot"], -B["hy"], B["hy"], zf, B["z_deck1"])
    f2 = box(B["x1"] - B["foot"], B["x1"], -B["hy"], B["hy"], zf, B["z_deck1"])
    br = _one(deck + f1 + f2)
    top = [e for e in br.edges() if abs(e.center().Z - B["z_deck1"]) < 1e-6]
    try:
        cand = fillet(top, 0.8)
        if cand.is_valid:
            br = cand
    except Exception:
        pass
    # E2s: clipped 0.4 INSIDE the exterior (a prism of the section at y 0): the feet overlap the 2.5 wall instead of
    # sharing the exterior B-spline face with the shell (coincident faces made the fuse invalid)
    return _one(br & _outer_in_l())


def bridge_tie_point(HZ=0.0):
    """world point on top of the cable-bridge deck where the servo lead is tied (lead direction = X)"""
    B = BRIDGE
    return ((B["x0"] + B["x1"]) / 2, 0.0, HZ + B["z_deck1"])


def _ear_hole_edges(s):
    """outer edges of the two ear through-holes (cylinder R13.15 x exterior surface)"""
    zc, out = H / 2, []
    for e in s.edges():
        c = e.center()
        if abs(c.X) < W / 2 - 3.0 or e.length < 20:
            continue
        ok = True
        for t in (0.0, 0.21, 0.47, 0.73, 0.9):
            p = e.position_at(t)
            if abs(math.hypot(p.Y - EAR_Y, p.Z - zc) - (EAR_R + EAR_CL)) > 0.02 or abs(p.X) < W / 2 - 3.0:
                ok = False
                break
        if ok:
            out.append(e)
    return out


SHELL_NOTES = {}


@functools.lru_cache(None)
def _shell_base_l():
    """white shell with every COMMON feature: hollow, ear seats (boss + through hole R13.15 + lip hole r11 + hole
    edge R0.8), magnet bosses + pockets, cable bridge, rabbet, seam chamfer"""
    zc = H / 2
    cav = _inner_l()
    s = _outer_l() - _front_box() - cav
    for sx in (-1, 1):
        s = s + (xcyl(BOSS_R, sx * (EAR_X0 - LIP_TE), sx * 75, EAR_Y, zc) & cav)
    for sx in (-1, 1):
        s = s - xcyl(EAR_R + EAR_CL, sx * EAR_X0, sx * 70, EAR_Y, zc)
    s = _one(s)
    eds = _ear_hole_edges(s)
    SHELL_NOTES["ear_hole_edges"] = len(eds)
    try:
        cand = fillet(eds, EAR_HOLE_FIL)
        ok = cand.is_valid and len(cand.solids()) == 1
    except Exception as ex:
        ok = False
        SHELL_NOTES["ear_fillet_error"] = repr(ex)[:200]
    SHELL_NOTES["ear_hole_fillet"] = EAR_HOLE_FIL if ok else 0.0
    if ok:
        s = cand
    for sx in (-1, 1):
        s = s - xcyl(LIP_R0, sx * (EAR_X0 - LIP_TE - 1.0), sx * (EAR_X0 + 0.5), EAR_Y, zc)
    for a in _mag_bosses_l():
        s = s + a
    s = s + _bridge_l()
    s = s - prism_y(RAB_SH, Y_SEAM, Y_SEAM - 1.0, Y_RAB)                                 # rabbet
    for x, z, _, _ in _mag_pts():
        s = s - ycyl(MAG_HOLE / 2, Y_RAB - 1.0, Y_RAB + MAG_DEPTH, x, z)
    s = s - _v_cutter(1)
    return _one(s)


def _fuse(base, items):
    if items is None:
        return base
    for it in (items if isinstance(items, (list, tuple)) else [items]):
        base = base + it
    return base


def _cut(base, items):
    if items is None:
        return base
    for it in (items if isinstance(items, (list, tuple)) else [items]):
        base = base - it
    return base


def head_shell(HZ, cuts=None, adds=None):
    """HOLLOW white shell (wall 2.5), front rim face y=-26: rabbet for the bezel spigot (floor y=-25), 6 magnet
    bosses behind the opening, ear seats (through hole R13.15 with the outer edge R0.8, lip 1.5, boss R16), cable
    bridge on the floor (-X side).  NO display seats / ribs / inserts.
    Order: common base -> + variant adds -> - variant cuts (world solids / lists)."""
    s = _fuse(_w(_shell_base_l(), HZ), adds)
    s = _cut(s, cuts)
    return _one(s)


def head_parts(HZ, cuts=None, adds=None):
    """registry fragment for build_all(): {name: [(shape, "H"), ...]} with the E2 section-D names of the head"""
    dp, ca, mg = display_parts(HZ), carrier(HZ), magnets(HZ)
    P = {}
    P["hlava_skrupina"] = [(head_shell(HZ, cuts=cuts, adds=adds), "H")]
    P["ram_displeja"] = [(bezel(HZ), "H")]
    P["displej"] = [(dp[k], "H") for k in ("glass", "lcd", "pcb", "standoffs", "header", "usbc", "small")]
    P["pena_displeja"] = [(gasket(HZ), "H")]
    P["drziak_displeja"] = [(ca["bars"], "H")]
    P["magnety"] = [(mg["bezel"], "H"), (mg["shell"], "H")]
    P["usi"] = [(ears(HZ), "H")]
    P["led_kruzky"] = [(led_rings(HZ), "H")]
    P["led_dosky"] = [(led_boards(HZ), "H")]
    P["oci_len_vizualizacia"] = [(eyes(HZ), "H")]
    P["skrutky"] = [(ca["screws"], "H"), (ca["inserts"], "H")]
    return P


def mesh_volume(shape, tol=0.01):
    """reliable volume: OCC GProp is WRONG for the closed periodic B-spline loft faces - use this (signed tetra sum
    of the tessellation) for all volume checks"""
    import numpy as np
    if shape is None or not shape.solids():
        return 0.0
    v, t = shape.tessellate(tol, 0.1)
    if not t:
        return 0.0
    V = np.array([[p.X, p.Y, p.Z] for p in v]); T = np.array(t)
    return float(np.einsum('ij,ij->i', V[T[:, 0]], np.cross(V[T[:, 1]], V[T[:, 2]])).sum() / 6)


setup()
