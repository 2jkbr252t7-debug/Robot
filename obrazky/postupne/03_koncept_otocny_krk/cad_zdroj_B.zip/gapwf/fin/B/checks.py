"""NOVA mini - variant B, revision E2f - CONSOLIDATED acceptance checks of the INTEGRATED model -> checks.json (E1..E10)
E2f (user option 1): the servo lead goes DOWN into the torso (modified MG90S, 3 x AWG30 in a groove of the FRONT neck
half, kabel[2] group N).  E10 is re-defined (servo wires vs H parts / inside the neck), E9 has no lead exception, the
floor slot / vault / foam plug / cable bridge / lead nub checks are gone.

run:  /opt/venv/cad/bin/python /tmp/claude-0/gapwf/fin/B/checks.py              full run, ~45-55 min on 4 cores:
          0. build.py           build_all() + export(P) -> stl/ (stale STL names are deleted by export)
          1. three worker scripts in parallel, each on the integrated model, each with its own json + log:
               checks_e2_neck.py    neck / hinge / servo pocket / servo wires (E1 E2 E3 E4 E5 E6 E10, walls W incl. the
                                    servo-wire groove, lift L, assembly A)
               checks_e2_head.py    head: shell, bezel, display, carrier, magnets, ears  (E1 E4 E7 E8, window view)
               checks_e2_integr.py  interfaces between the two sides, E9 visibility, tilt-vs-lift table, STL files,
                                    registry, the round-5 checks that are still valid
          2. merge -> checks.json with the E1..E10 verdicts, key numbers, the registry and the open deviations
      checks.py --merge              only step 2 (re-read the worker json files)
      checks.py --no-export          skip step 0
      checks.py --seq                run the workers one after another
      checks.py --only neck:E10,E4 integr:X head:5      re-run only these sections of these workers, then merge
Round-5 sections that no longer exist in the model were dropped: visor / tape / corner pads, display seats and ribs,
aprons and apron pegs, tab slot, 2nd-bump relief, lead channel down the neck, 35 deg saddle land (see r5/checks.py).
"""
import sys, os, json, time, subprocess

D = "/tmp/claude-0/gapwf/fin/B"
PY = "/opt/venv/cad/bin/python"
WORKERS = dict(neck="checks_e2_neck.py", head="checks_e2_head.py", integr="checks_e2_integr.py")
t0 = time.time()


def log(*a):
    print(f"[{time.time() - t0:7.1f}]", *a, flush=True)


def run_step(name, args, logname):
    return subprocess.Popen([PY] + args, cwd=D, stdout=open(f"{D}/{logname}", "w"), stderr=subprocess.STDOUT), name


def load(name):
    try:
        return json.load(open(f"{D}/checks_e2_{name}.json"))
    except Exception as ex:
        return {"_load_error": repr(ex)}


def g(d, *path, default=None):
    for p in path:
        if not isinstance(d, dict) or p not in d:
            return default
        d = d[p]
    return d


# failure-name prefix -> E check (a failure may count for several checks)
MAP = {"neck": {"E1": ["E1"], "E2": ["E2"], "E3": ["E3"], "E4": ["E4"], "E5": ["E5"], "E6": ["E6"], "E10": ["E10"], "W": ["E4"],
                "A": ["A"]},
       "head": {"H1": ["E1"], "H2": ["E7"], "H3": ["E7"], "H4": ["E8"], "H5": ["E4"], "H6": ["E2"], "H7": ["E7"], "H8": ["X"],
                "H9": ["X"], "H10": ["E1"], "H11": ["E9"]},
       "integr": {"REG": ["E1"], "X1": ["X", "E4"], "X2": ["X", "E2"], "X3": ["X"], "X4": ["X"], "X5": ["X", "E3"], "T": ["T"],
                  "E9": ["E9"], "S": ["S"], "R5": ["R5"]}}
# json sections that must exist for a check to count as RUN
NEED = {"E1": [("neck", "E1_validity"), ("head", "1_E1_validity_volumes"), ("integr", "REG_registry")],
        "E2": [("neck", "E2_overlaps_extended_tilt0"), ("neck", "E2_E3_tilt_sweep"), ("neck", "E2_E3_rest_pose"),
               ("head", "6_interference_clearance"), ("integr", "X_interfaces", "X2_cables_in_head")],
        "E3": [("neck", "E2_E3_tilt_sweep"), ("neck", "E3_hinge_seams"), ("neck", "L_lift_vs_collar"),
               ("integr", "X_interfaces", "X5_head_vs_collar_torso")],
        "E4": [("neck", "E4_raycast_walls"), ("neck", "W_walls_passages"), ("head", "5_E4_walls"),
               ("integr", "X_interfaces", "X1_pads_tenons_floor")],
        "E5": [("neck", "E5_servo_range")], "E6": [("neck", "E6_horn_range")],
        "E7": [("head", "3_E7_display"), ("head", "7_module_through_opening"), ("head", "2_seam_step_72pts")],
        "E8": [("head", "4_E8_magnets")],
        "E9": [("integr", "V_E9_visibility", "worst_internal_area_mm2"), ("head", "11_visible_through_window")],
        "E10": [("neck", "E10_servo_wires"), ("neck", "W_walls_passages", "servo_wire_groove")],
        "X": [("integr", "X_interfaces", "X1_pads_tenons_floor"), ("integr", "X_interfaces", "X2_cables_in_head"),
              ("integr", "X_interfaces", "X3_tool_path_cross_screws"), ("integr", "X_interfaces", "X4_bosses_bars_posts"),
              ("integr", "X_interfaces", "X5_head_vs_collar_torso"), ("head", "8_tool_path_cross_screws"), ("head", "9_floor_closed"),
              ("head", "10_ear_pods")],
        "A": [("neck", "A_assembly_paths")], "T": [("integr", "T_tilt_vs_lift", "rule_min_clear")], "S": [("integr", "S_stl")],
        "R5": [("integr", "R5_still_valid")]}
TITLE = {"E1": "every solid valid, mesh volumes sane", "E2": "zero interference (rest, extended, tilt -40..+40 step 5)",
         "E3": "clearances H vs N/T >= 0.25 over the sweep, hinge seams 0.3 uniform", "E4": "walls >= 1.2 (ray cast), listed exceptions only",
         "E5": "MG90S envelope range (modified servo, no lead nub) fits the closed halves", "E6": "horn arm top 8.9 / 9.6 / 10.3: cap fits, sweep clear",
         "E7": "display: official outline fits, module passes the opening, bezel/shell step <= 0.02",
         "E8": "magnets: walls >= 1.0, pairs aligned <= 0.1", "E9": "visibility ray cast: no internal part visible",
         "E10": "servo wires (group N) never touch an H part (>= 0.5, rest / extended / tilt -40..+40), stay inside the neck "
                "to its bottom; groove fits 3 x D0.8 with walls >= 1.2", "X": "integration: interfaces between head and neck side",
         "A": "assembly paths free", "T": "tilt vs lift (firmware rule) for the new head", "S": "exported STL files",
         "R5": "round-5 checks that are still valid"}


def merge():
    J = {k: load(k) for k in WORKERS}
    N, H, I = J["neck"], J["head"], J["integr"]
    fails = {k: [] for k in TITLE}
    raw = dict(neck=g(N, "summary", "failed", default=[]) or [], head=H.get("failed", []) or [],
               integr=g(I, "summary", "failed", default=[]) or [])
    for w, lst in raw.items():
        for f in lst:
            for e in MAP[w].get(f.split(" ")[0], ["X"]) + (["E10"] if "servo-wire groove" in f else []):   # E2f: groove = E4 + E10
                fails[e].append(f"[{w}] {f}")
    missing = {e: [".".join(p) for p in need if g(J[p[0]], *p[1:]) is None] for e, need in NEED.items()}
    for w in WORKERS:
        if "_load_error" in J[w]:
            for e in TITLE:
                if any(p[0] == w for p in NEED[e]):
                    fails[e].append(f"[{w}] json not readable: {J[w]['_load_error']}")
    # ---- key numbers
    sw = g(N, "E2_E3_tilt_sweep", default={})
    e4n = g(N, "E4_raycast_walls", "parts", default={})
    e4h = {k: v for k, v in g(H, "5_E4_walls", default={}).items() if isinstance(v, dict)}
    e7, e8 = g(H, "3_E7_display", default={}), g(H, "4_E8_magnets", default={})
    v9 = g(I, "V_E9_visibility", default={})
    e10 = g(N, "E10_servo_wires", default={})
    grv = g(N, "W_walls_passages", "servo_wire_groove", default={})
    x = g(I, "X_interfaces", default={})
    reg = g(I, "REG_registry", "parts", default={})
    e6r = g(N, "E6_horn_range", "rows", default={})
    e5v = g(N, "E5_servo_range", "variants", default={})
    KEY = {
        "E1": dict(parts=len(reg), solids=sum(r["solids"] for v in reg.values() for r in v), all_valid=g(I, "REG_registry", "all_valid", "passed"),
                   shell_mesh_volume=g(H, "1_E1_validity_volumes", "hlava_skrupina", "mesh_volume"),
                   bezel_mesh_volume=g(H, "1_E1_validity_volumes", "ram_displeja", "mesh_volume"),
                   printed_parts_solid_count=g(I, "REG_registry", "printed_parts_solid_count", "value")),
        "E2": dict(worst_unintended_overlap_tilt0_mm3=g(N, "E2_overlaps_extended_tilt0", "worst_unintended_mm3", "value"),
                   intended_overlaps=g(N, "E2_overlaps_extended_tilt0", "nonzero_pairs"),
                   sweep_interference_mm3=g(sw, "interference_mm3", "value"),
                   head_internal_overlaps=g(H, "6_interference_clearance", "overlaps_above_0p0001_mm3"),
                   head_internal_pairs_tested=g(H, "6_interference_clearance", "pairs_tested"),
                   cables_in_head_overlap_mm3=dict(
                       head_wires=max(list(g(x, "X2_cables_in_head", "head_wires", "overlap_mm3", default={0: None}).values()), key=lambda v: v or 0),
                       servo_wires_in_head=g(x, "X2_cables_in_head", "servo_wires_never_in_the_head", "overlap_with_head_exterior_mm3")),
                   rest_pose_min_distance_to_torso_side=g(N, "E2_E3_rest_pose", "overall", "value")),
        "E3": dict(min_clearance_over_sweep=g(sw, "overall_min_clearance", "value"), at=min(
                       (g(sw, "min_per_angle", default={}) or {"-": [None, None]}).items(), key=lambda kv: (kv[1] or [9e9])[0] if kv[1] and kv[1][0] is not None else 9e9),
                   rest_pose_min=g(N, "E2_E3_rest_pose", "overall", "value"), hinge_seams=g(N, "E3_hinge_seams", "seam_0p3_uniform", "value"),
                   head_axial_float=g(N, "E3_hinge_seams", "head_axial_float", "float"),
                   collar_slot_clearance_over_lift=g(N, "L_lift_vs_collar", "slot_clearance", "value"),
                   head_exterior_vs_collar_torso_sweep_min=g(x, "X5_head_vs_collar_torso", "sweep_min", "value"),
                   head_exterior_vs_collar_torso_rest_min=g(x, "X5_head_vs_collar_torso", "rest_min", "value")),
        "E4": dict(neck_side={k: dict(min=v.get("min"), n_lt_1p19=v.get("n_lt_1p19"), exceptions=v.get("listed_exceptions"),
                                      unexplained=v.get("n_unexplained")) for k, v in e4n.items()},
                   head_side={k: dict(min=v.get("min"), n_lt_1p19=v.get("n_lt_1p19")) for k, v in e4h.items()},
                   shell_hinge_zone=dict(min=g(x, "X1_pads_tenons_floor", "shell_hinge_zone_raycast", "min"),
                                         n_lt_1p19=g(x, "X1_pads_tenons_floor", "shell_hinge_zone_raycast", "n_lt_1p19")),
                   neck_void_walls_min=g(N, "W_walls_passages", "neck_min_wall", "value"),
                   wire_passages_ok=g(N, "W_walls_passages", "wire_passages", "all_ge_0p3", "value"),
                   servo_wire_groove=dict(to_voids_min=g(grv, "walls_min", "value", "voids"), to_outside=g(grv, "walls_min", "value", "outside"),
                                          raycast_min=g(grv, "raycast_front_half_around_groove", "min"),
                                          raycast_n_lt_1p19=g(grv, "raycast_front_half_around_groove", "n_lt_1p19"))),
        "E5": dict(all_fit=g(N, "E5_servo_range", "all_fit", "value"), variants=len(e5v),
                   max_stack=e5v.get("MAX stack: w12.3 L22.8 h23.0 turret 6.2 lobe 6.5/3.1"),
                   servo_wires_room_x_min=min((v.get("servo_wires_room_x_cover_to_groove_end", 9e9) for v in e5v.values()), default=None),
                   min_stack=e5v.get("MIN stack: w12.0 L22.4 h22.4 turret 5.4 lobe 5.0/2.6"), note=g(N, "summary", "notes")),
        "E6": dict(all_fit=g(N, "E6_horn_range", "all_fit", "value"),
                   rows={k: dict(fits=v.get("fits"), min_clear_static_over_sweep=v.get("min_clear_static_over_sweep"),
                                 arm_top_to_slot_bottom=v.get("arm_top_to_slot_bottom")) for k, v in e6r.items()}),
        "E7": dict(glass_to_pocket=g(e7, "glass_to_pocket_clearance_xz"), lip_overlap=[g(e7, "lip_overlap_on_glass", "min"), g(e7, "lip_overlap_on_glass", "max")],
                   window_clear_of_active_area=[g(e7, "window_clear_of_active_area", "x"), g(e7, "window_clear_of_active_area", "z")],
                   standoff_pattern=g(e7, "standoffs", "pattern"), screw_axis_offset_max=g(e7, "standoffs", "screw_axis_offset_max"),
                   keepout_nothing_inside=g(e7, "keepout", "nothing_inside"), keepout_min_distance=g(e7, "keepout", "min_distance"),
                   module_through_opening_worst_overlap_mm3=g(H, "7_module_through_opening", "worst_overlap_mm3"),
                   module_min_clearance_during_pull=g(H, "7_module_through_opening", "min_clearance_posts_bars_display_to_shell_during_pull"),
                   seam_step_abs_max=g(H, "2_seam_step_72pts", "step_bezel_minus_shell", "abs_max"),
                   stack_depth_behind_glass_front=g(e7, "mounting_plane", "depth_behind_glass_front")),
        "E8": dict(bezel_pocket_min_wall=min(g(e8, "bezel_pocket_min_wall", default=[None]) or [None]),
                   shell_pocket_min_wall=min(g(e8, "shell_pocket_min_wall", default=[None]) or [None]),
                   pair_misalignment_max=g(e8, "pair_misalignment_max"), face_gap=g(e8, "face_gap"),
                   hold_total_N=g(e8, "hold_force_N", "total_6_pairs"), magnets="6 pairs N35 D4 x 2"),
        "E9": dict(worst_internal_area_mm2=g(v9, "worst_internal_area_mm2", "value"), lead_exceptions=g(v9, "lead_exceptions"),
                   servo_wires_visible_area_mm2=g(v9, "servo_wires_visible_area_mm2"),
                   through_window_other_parts_mm2=g(H, "11_visible_through_window", "worst_area_of_other_parts_mm2")),
        "E10": dict(group=g(e10, "group", "value"), min_to_H_over_tilt=g(e10, "min_to_H_over_tilt", "value"),
                    rest_min=g(e10, "rest_pose", "min", "value"), wires_top_z=g(e10, "wires_top_z"),
                    outside_neck_mm3=g(e10, "inside_the_neck", "outside_the_closed_neck_exterior_above_its_bottom_mm3", "value"),
                    min_clearance_to_neck_side=g(e10, "inside_the_neck", "min_clearance_to_neck_side"),
                    groove=dict(section=g(grv, "wires", "section"), clear_x=g(grv, "wires", "clear_x"),
                                clear_y_3_in_a_row=g(grv, "wires", "clear_y_3_in_a_row"), walls=g(grv, "walls_min", "value"),
                                raycast_min=g(grv, "raycast_front_half_around_groove", "min"))),
        "X": dict(tenon_in_slot=[g(x, "X1_pads_tenons_floor", k, "tenon_to_floor_slot_wall") for k in ("usko_kryt", "usko_lozisko")],
                  head_floor_closed=g(x, "X1_pads_tenons_floor", "head_floor_closed_between_pads", "closed", "passed"),
                  front_module_pull_out_before_taut=g(x, "X2_cables_in_head", "head_wires", "front_module_pull_out_before_taut"),
                  servo_wires_never_in_the_head=g(x, "X2_cables_in_head", "servo_wires_never_in_the_head", "passed", "passed"),
                  tool_path_min_clearance=g(x, "X3_tool_path_cross_screws", "min_clearance"),
                  bosses_bars_posts_min=g(x, "X4_bosses_bars_posts", "min_all", "value"),
                  head_vs_collar_torso=[g(x, "X5_head_vs_collar_torso", "rest_min", "value"), g(x, "X5_head_vs_collar_torso", "sweep_min", "value")]),
        "A": dict(all_paths_free=g(N, "A_assembly_paths", "all_paths_free", "passed")),
        "T": dict(table=g(I, "T_tilt_vs_lift", "max_tilt_deg_keeping_0p25_vs_collar_and_torso"), rule_min_clear=g(I, "T_tilt_vs_lift", "rule_min_clear", "value")),
        "S": dict(names=g(I, "S_stl", "names", "value"), open_edges={k: v["open_edges"] for k, v in (g(I, "S_stl", "files", default={}) or {}).items()}),
        "R5": dict(containment=g(I, "R5_still_valid", "containment", "all_inside", "passed"),
                   pin_grip_len=g(I, "R5_still_valid", "pin_grip", "grip_len_cov_ge_0p85")),
    }
    summary = {}
    for e in TITLE:
        ran = not missing[e]
        summary[e] = dict(check=TITLE[e], passed=bool(ran and not fails[e]), run_complete=ran, failed=fails[e],
                          not_run=missing[e], key_numbers=KEY[e])
    ECH = [f"E{i}" for i in range(1, 11)]
    table = [dict(name=k, item=r["item"], group=r["group"], solids=r["solids"], valid=r["valid"], mesh_volume=r["mesh_volume"])
             for k, v in reg.items() for r in v]
    out = dict(
        revision="E2f integrated (neck/hinge build.py + head common/head_common.py); servo lead DOWN into the torso", units="mm / mm3 / N",
        written=time.strftime("%Y-%m-%d %H:%M:%S"),
        how="checks.py: build + export, then checks_e2_neck.py / checks_e2_head.py / checks_e2_integr.py on the integrated model, merged here",
        all_E_checks_pass=all(summary[e]["passed"] for e in ECH), all_checks_pass=all(v["passed"] for v in summary.values()),
        failed={e: summary[e]["failed"] + [f"NOT RUN: {m}" for m in summary[e]["not_run"]] for e in summary if not summary[e]["passed"]},
        summary=summary, registry=table, deviations_from_E2_spec=DEVIATIONS,
        worker_times_s=dict(neck=g(N, "summary", "time_s"), head=H.get("time_s"), integr=g(I, "summary", "time_s")),
        neck=N, head=H, integration=I)
    json.dump(out, open(f"{D}/checks.json", "w"), indent=1, ensure_ascii=False)
    for e in TITLE:
        s = summary[e]
        log(f"{e:3s} {'PASS' if s['passed'] else 'FAIL'}  {s['check']}" + ("" if s["passed"] else f"  {s['failed']} {s['not_run']}"))
    log("all E checks pass:", out["all_E_checks_pass"], "| all checks pass:", out["all_checks_pass"])
    return out


DEVIATIONS = [
    "B2 stack: lip 1.7 / window edge R0.7 (E2: 1.5 / R1.0) - keeps every lip wall >= 1.2 (min 1.205); glass front y -31.0 (E2 -31.2)",
    "A1/B2 depth: the official side view dimensions 7.50 to the PCB BACK and 11.50 to the STANDOFF ENDS -> mounting plane (standoff "
    "ends = bezel post faces = bar front face) at y -19.5, i.e. 11.5 behind the glass front (E2 text: 7.5 -> -23.7); 2x16 header "
    "modelled 5.0 tall = 12.5 behind the glass front, y -18.5 (E2: 11.5 -> -19.7); keep-out to 11.5 over the PCB + header zone to 12.5",
    "A1: PCB modelled 78.0 x 54.6 (measured on the drawing: 72 + 2 x 3.0, 48.5 + 2 x 3.05; E2: 'about 79.5 x 55')",
    "B2 carrier: bars 3.0 thick on 4 bezel POSTS D5.86 at (+-21, +-33.65) in the top / bottom ring; screws M2x5 into the standoffs "
    "(E2: M2x4; 2.0 thread engagement behind the 3.0 bar) and M2x6 into the inserts",
    "E2f (user option 1, replaces E2 C2): the servo lead goes DOWN into the torso, not up into the head.  The MG90S is MODIFIED "
    "(original cable unsoldered, 3 x AWG30 silicone D <= 0.8 soldered to the pads, led out through a 2 x 2 notch filed into the "
    "FRONT long edge of the bottom cover 12.4 from the end face of the original cable) -> no lead nub, no knuckle-top slot, no "
    "foam plug, no head floor slot, no vault, no cable bridge, no servo lead in the head; servo connected in the torso",
    "E2f groove (servo_wire_groove, FRONT neck half): x 13.15..14.55 (= +X end of the pocket), y -6.75..-3.75 design = "
    "-6.70..-3.70 closed (3.0 wide), from the neck bottom up to z 11.6.  Widened from the orchestrator's -6.2..-3.75 (2.45): "
    "3 x D0.8 in a row need 2.4 + 0.3 after the 0.15 print shrink per wall (same rule as the head-wire passages)",
    "E2f: +X pocket-wall foam pads narrowed to |y| 2.3..3.5 (were 2.4..5.8): they sit between the head-wire chamber and the groove",
    "C3 cap: open knuckle bore r6.65 + cap plug (2 cheeks r6.3) instead of only a deeper arm slot; blind cap end wall 1.0 (allowed by E2)",
    "C3 lug: concave web blend R4 and end-face round R3 (E1: R3 / R2) - the barrel must pass the collar slot corner R3.25; web half "
    "width 8.25 (E1: 8.0 = tenon) so the web covers the 0.1 clearance strip of the floor slot (E9: screw shank visible, 0.02 mm2)",
    "C1/E5: far case end -> spline axis above 17.06 (drawing max 17.1) needs 0.05 filed off the far case end (assembly text)",
    "C1: the longer pocket moved the hollow pin to x 13.4..18.5 (length 5.1): glued seat 2.6 long (round 5: 3.2)",
    "neck: 4th screw = oblique M2x12 (round 5: M2x14); head-wire passage = slot 1.6 x 4.0 in the +X lug / tenon",
    "E1 6.2 torso rim R1.0: not applied to the ILLUSTRATIVE torso of this builder when OCC refuses the fillet (see R5.collar_ring.torso_rim_round_R)",
]


if __name__ == "__main__":
    a = sys.argv[1:]
    only = {}
    if "--only" in a:
        for tok in a[a.index("--only") + 1:]:
            if tok.startswith("--"):
                break
            w, _, secs = tok.partition(":")
            only[w] = [s for s in secs.split(",") if s]
    if "--merge" not in a:
        if "--no-export" not in a and not only:
            log("step 0: build + export")
            p, _ = run_step("build", ["build.py"], "build_run.log")
            if p.wait() != 0:
                log("build.py FAILED - see build_run.log")
                sys.exit(1)
            log("exported:", open(f"{D}/build_run.log").read().strip().splitlines()[-1])
        jobs = []
        for w, script in WORKERS.items():
            if only and w not in only:
                continue
            j = run_step(w, [script] + only.get(w, []), f"checks_run_{w}.log")
            jobs.append(j)
            log("started", w, only.get(w, "all sections"))
            if "--seq" in a:
                j[0].wait()
        for p, w in jobs:
            rc_ = p.wait()
            log("worker", w, "finished, exit code", rc_)
    out = merge()
    sys.exit(0 if out["all_checks_pass"] else 2)
