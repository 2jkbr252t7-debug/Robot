"""Variant B rev. E2 - NECK / HINGE side checks on the INTEGRATED model (build.py + live E2 head) -> checks_e2_neck.json
(written by the neck engineer against the frozen round-5 head; integration: head part names, lead run, section list)
run: /opt/venv/cad/bin/python checks_e2_neck.py [sections...]   (no argument = all; e.g. "E5 E6" re-runs only those and
keeps the other sections of the existing json).  Sections: E1, E2 (static overlaps), E3 (tilt sweep, rest pose, seams),
E4, E5, E6, E10, W (walls / passages), L (lift vs collar), A (assembly paths)."""
import sys, json, time, math, os, warnings
warnings.filterwarnings("ignore")
sys.path.insert(0, "/tmp/claude-0/gapwf/fin/B")
import numpy as np
import build as B
import head_common as HC
import rc
from build123d import Pos, Box, Compound, Location, Axis
t0 = time.time()
OUT = "/tmp/claude-0/gapwf/fin/B/checks_e2_neck.json"
SEC = set(sys.argv[1:]) or {"E1", "E2", "E3", "E4", "E5", "E6", "E10", "W", "L", "A"}
try:
    R = json.load(open(OUT)) if sys.argv[1:] else {}
except Exception:
    R = {}
R.update(units="mm / mm3", pose="extended (HZ 27, axis z 16.5) unless stated; rest = lift -20; neck halves CLOSED",
         head="INTEGRATED: live E2 head module " + HC.__file__, revision="E2 neck side, integrated model")
FAIL, NOTE = [], []


def _sec_of(name):
    """section that produces a failure name (for partial re-runs: failures of the other sections are kept)"""
    t = name.split(" ")[0]
    if name.startswith("E2 sweep") or (t == "E3" and "collar" not in name):
        return "E3"
    if t == "E3":
        return "L"
    return t


if sys.argv[1:]:
    FAIL = [f for f in R.get("summary", {}).get("failed", []) if _sec_of(f) not in SEC]
    NOTE = [n for n in R.get("summary", {}).get("notes", []) if n.split(":")[0] not in SEC]


def r3(x):
    return round(float(x), 3)


def log(*a):
    print(f"[{time.time() - t0:6.1f}]", *a, flush=True)


def save():
    R["summary"] = dict(failed=FAIL, notes=NOTE, time_s=round(time.time() - t0, 1))
    json.dump(R, open(OUT, "w"), indent=1, ensure_ascii=False)


def ok(name, cond, val):
    if not cond:
        FAIL.append(f"{name}: {val}")
    return dict(value=val, passed=bool(cond))


def ivol(a, b):
    x = a & b
    return 0.0 if x is None or not x.solids() else float(sum(s.volume for s in x.solids()))


def bb_overlap(a, b, m=0.05):
    A, Bb = a.bounding_box(), b.bounding_box()
    a0, a1, b0, b1 = [tuple(v) for v in (A.min, A.max, Bb.min, Bb.max)]
    return all(a0[i] - m <= b1[i] and b0[i] - m <= a1[i] for i in range(3))


P = B.build_all()
log("built")
nf, nb = P["krk_predna_polovica"][0][0], P["krk_zadna_polovica"][0][0]
cap, lug, horn, ptfe = P["usko_kryt"][0][0], P["usko_lozisko"][0][0], P["paka"][0][0], P["klzny_kruzok"][0][0]
servo, foam, plug = P["servo_MG90S"][0][0], P["pena_serva"][0][0], P["pena_serva"][1][0]
bo, bi = [s for s, g in P["loziska_MR85"]]
pin, dowels = [s for s, g in P["capy"]]
nscr, hscr, xscr = [s for s, g in P["skrutky"][:3]]
cab_n, cab_h, stub, lrun = [s for s, g in P["kabel"]]
disc, ring = P["golier_kotuc"][0][0], P["golier_prstenec"][0][0]
shell = P["hlava_skrupina"][0][0]
neck = nf + nb
MINE = dict(krk_predna_polovica=nf, krk_zadna_polovica=nb, usko_kryt=cap, usko_lozisko=lug, paka=horn, klzny_kruzok=ptfe,
            servo_MG90S=servo, pena_serva=foam, zatka_drazky=plug, MR85_outer=bo, MR85_inner=bi, cap_pin=pin, koliky=dowels, skrutky_krk=nscr,
            skrutka_paky=hscr, skrutky_hlava=xscr, kabel_krk=cab_n, kabel_hlava=cab_h, privod_serva_krk=stub,
            privod_serva_hlava=lrun, golier_kotuc=disc, golier_prstenec=ring)
GRP = dict(krk_predna_polovica="N", krk_zadna_polovica="N", usko_kryt="H", usko_lozisko="H", paka="H", klzny_kruzok="H",
           servo_MG90S="N", pena_serva="N", zatka_drazky="N", MR85_outer="H", MR85_inner="N", cap_pin="N", koliky="N", skrutky_krk="N",
           skrutka_paky="H", skrutky_hlava="H", kabel_krk="N", kabel_hlava="H", privod_serva_krk="N",
           privod_serva_hlava="H", golier_kotuc="T", golier_prstenec="T")
HEAD = {}
for k in ("hlava_skrupina", "ram_displeja", "displej", "pena_displeja", "drziak_displeja", "magnety", "usi", "led_kruzky",
          "led_dosky"):
    for i, (s, g) in enumerate(P.get(k, [])):
        HEAD[f"{k}#{i}"] = s
for i, (s, g) in enumerate(P["skrutky"][3:]):
    HEAD[f"skrutky_hlava_modul#{i}"] = s
INTENDED = {("usko_kryt", "paka"): "4 crush ribs 0.1 on the arm flanks (intended press, zero backlash)",
            ("krk_zadna_polovica", "koliky"): "D2.0 reamed hole + epoxy in the BACK half (nominal line contact)",
            ("kabel_krk", "kabel_hlava"): "same wire group, joint on the hinge axis",
            ("paka", "servo_MG90S"): "horn sits ON the spline", ("MR85_outer", "MR85_inner"): "same bearing",
            ("skrutka_paky", "servo_MG90S"): "horn screw threads into the output shaft"}


def intended(a, b):
    return INTENDED.get((a, b)) or INTENDED.get((b, a))


# ---------------------------------------------------------------- E1 validity / volumes
if "E1" in SEC:
    val = {}
    for k, lst in P.items():
        row = []
        for s, g in lst:
            v = HC.mesh_volume(s) if k in ("hlava_skrupina", "sklo", "ram_displeja") else sum(x.volume for x in s.solids())
            row.append(dict(valid=bool(s.is_valid), solids=len(s.solids()), volume=r3(v), group=g))
            if not s.is_valid or v <= 0:
                FAIL.append(f"E1 {k}: invalid or zero volume")
        val[k] = row
    single = {k: len(MINE[k].solids()) for k in ("krk_predna_polovica", "krk_zadna_polovica", "usko_kryt", "usko_lozisko",
                                                 "golier_kotuc", "golier_prstenec", "klzny_kruzok")}
    R["E1_validity"] = dict(parts=val, printed_parts_single_solid=ok("E1 single solids", all(v == 1 for v in single.values()), single),
                            servo_model=dict(turret_top_above_bottom=r3(22.5 + B.TUR_H), spec_range=[28.0, 28.5],
                                             horn_top_above_bottom=r3(22.5 + B.ARM_TOP[1]), spec_horn=[32.0, 32.6],
                                             spline_top_above_bottom=r3(22.5 + B.TUR_H + 3.0),
                                             case=[22.5, 12.2, 22.8], lobe=dict(r=B.LOBE[0], centre=B.LOBE[1], reach=r3(sum(B.LOBE))),
                                             spline_axis_from_near_end=r3(B.SZ1 - B.AXZ), nub_x_above_bottom_cover=[
                                                 r3(B.XB - B.NUB[1]), r3(B.XB - B.NUB[0])], nub_on="end face nearest the shaft (pocket top)",
                                             tabs="none (both cut flush)"))
    sm = R["E1_validity"]["servo_model"]
    ok("E1 turret top in 28.0..28.5", 28.0 <= sm["turret_top_above_bottom"] <= 28.5, sm["turret_top_above_bottom"])
    ok("E1 horn top in 32.0..32.6", 32.0 <= sm["horn_top_above_bottom"] <= 32.6, sm["horn_top_above_bottom"])
    log("E1", single)
    save()

# ---------------------------------------------------------------- E2 / E3 interference + clearance
if "E2" in SEC:
    names = list(MINE)
    allp = dict(MINE); allp.update(HEAD)
    pairs, worst = {}, 0.0
    an = list(allp)
    for i, a in enumerate(an):
        for b in an[i + 1:]:
            if a in HEAD and b in HEAD:
                continue                                               # head x head = head side / integration
            if not bb_overlap(allp[a], allp[b]):
                continue
            x = allp[a] & allp[b]
            if x is None or not x.solids():
                continue
            v = HC.mesh_volume(x) if ("hlava_skrupina#0" in (a, b) or "ram_displeja#0" in (a, b)) else sum(s.volume for s in x.solids())
            if v > 1e-3:
                why = intended(a, b)
                pairs[f"{a} x {b}"] = f"{r3(v)} ({why})" if why else r3(v)
                if not why:
                    worst = max(worst, v)
    R["E2_overlaps_extended_tilt0"] = dict(nonzero_pairs=pairs, worst_unintended_mm3=ok("E2 overlaps tilt0", worst < 1e-3, r3(worst)),
                                           n_parts=len(an))
    log("E2 static", pairs)
    save()
# ---------------------------------------------------------------- E3: sweep, moving H vs static N / T (distance; 0 -> overlap volume)
if "E3" in SEC:
    torso = B.torso()
    torso_top = torso & (Pos(0, 0, 0.175) * Box(200, 200, 8.15))
    hinge_box = Pos(0, 0, B.HZ + 4) * Box(70, 50, 22)
    MOV = dict(hlava_pri_pante=shell & hinge_box, hlava_obal_spodok=HC.head_outer(B.HZ) & (Pos(0, 0, B.HZ + 10) * Box(200, 200, 20)),
               usko_kryt=cap, usko_lozisko=lug, paka=horn, skrutka_paky=hscr, MR85_outer=bo, klzny_kruzok=ptfe,
               kabel_hlava=cab_h, privod_serva_hlava=lrun, skrutky_hlava=xscr)
    top = Pos(0, 0, B.AXZ + 40 - 13) * Box(200, 200, 80)                 # static parts above z AXZ-13 (hinge zone)
    one = lambda x: x.solids()[0] if len(x.solids()) == 1 else x
    FULL = dict(krk_predna_polovica=nf, krk_zadna_polovica=nb, kabel_krk=cab_n)   # unclipped (re-check of suspicious values)
    STA = dict(krk_predna_polovica=one(nf & top), krk_zadna_polovica=one(nb & top), servo_MG90S=servo, cap_pin=pin, MR85_inner=bi,
               kabel_krk=one(cab_n & top), privod_serva_krk=stub, pena_serva=foam, zatka_drazky=plug, golier_kotuc=disc, golier_prstenec=ring,
               trup=torso_top)
    ONLY_T = {"hlava_obal_spodok"}                                       # exterior envelope: only vs collar / torso
    EXC = {("klzny_kruzok", "krk_predna_polovica"): "PTFE thrust ring runs on the static lip tip: 0.05 axial float by design",
           ("klzny_kruzok", "krk_zadna_polovica"): "PTFE thrust ring runs on the static lip tip: 0.05 axial float by design",
           ("paka", "servo_MG90S"): "horn on the spline", ("skrutka_paky", "servo_MG90S"): "horn screw in the spline",
           ("MR85_outer", "MR85_inner"): "same bearing", ("MR85_inner", "MR85_outer"): "same bearing",
           ("kabel_hlava", "kabel_krk"): "same wire group, joint on the axis",
           ("kabel_hlava", "cap_pin"): "wires inside the pin bore D3 (only twist)",
           ("privod_serva_hlava", "privod_serva_krk"): "same lead (flexing zone)",
           ("MR85_outer", "cap_pin"): "bearing on its pin"}
    minpair, per_angle, inter = {}, {}, {}
    for th in range(-40, 45, 5):
        row = {}
        for mn, m in MOV.items():
            mr = m.rotate(B.AX, th) if th else m
            for sn, st in STA.items():
                if (mn in ONLY_T) != (sn in ("golier_kotuc", "golier_prstenec", "trup")) and mn in ONLY_T:
                    continue
                if mn == "hlava_pri_pante" and sn == "trup":
                    continue
                if not bb_overlap(mr, st, 1.0):
                    continue
                d = mr.distance_to(st)
                if d < 0.2 and sn in FULL:                                 # OCC extrema can return a false 0 on clipped shapes
                    d = mr.distance_to(FULL[sn])
                key = f"{mn}-{sn}"
                if d < 1e-6:
                    v = ivol(mr, st)
                    if v > 1e-3 and (mn, sn) not in EXC:
                        inter[f"{key}@{th}"] = r3(v)
                if (mn, sn) not in EXC:
                    row[key] = r3(d)
                if key not in minpair or d < minpair[key][0]:
                    minpair[key] = (r3(d), th)
        per_angle[th] = [min(row.values()), min(row, key=row.get)] if row else None
        log("tilt", th, per_angle[th])
        R["E2_E3_tilt_sweep"] = dict(partial=per_angle)
        save()
    lim = {k: v for k, v in minpair.items() if tuple(k.split("-", 1)) not in EXC}
    exc = {k: dict(min=v[0], at_deg=v[1], why=EXC[tuple(k.split("-", 1))]) for k, v in minpair.items() if tuple(k.split("-", 1)) in EXC}
    mn_all = min(v[0] for v in lim.values())
    R["E2_E3_tilt_sweep"] = dict(
        angles=list(range(-40, 45, 5)), min_per_angle=per_angle, min_per_pair_mm_at_deg=lim,
        interference_mm3=ok("E2 sweep interference", not inter, inter),
        overall_min_clearance=ok("E3 clearance >= 0.25", mn_all >= 0.249, mn_all), design_exceptions=exc)
    save()
    # ---- rest pose (lift -20, tilt 0): moving (H + N) vs torso side
    dn = Location((0, 0, -B.LIFT))
    rest = {}
    for mn, m in dict(krk_predna_polovica=nf, krk_zadna_polovica=nb, usko_kryt=cap, usko_lozisko=lug,
                      hlava_obal_spodok=MOV["hlava_obal_spodok"]).items():
        mm = m.moved(dn)
        for cn, c in dict(golier_kotuc=disc, golier_prstenec=ring, trup=torso_top).items():
            if bb_overlap(mm, c, 1.0):
                rest[f"{mn}-{cn}"] = r3(mm.distance_to(c))
    R["E2_E3_rest_pose"] = dict(min_clearances=rest, overall=ok("E3 rest clearance >= 0.25", min(rest.values()) >= 0.249, min(rest.values())))
    log("rest", rest)
    # ---- hinge seams
    def seam(part, sx):
        ann = B.xcyl(9.9, sx * (B.LUG0 - 0.01), sx * (B.LUG0 + 0.02), 0, B.AXZ) - B.xcyl(8.6, sx * 17, sx * 19, 0, B.AXZ)
        face = part & ann
        return [r3(face.rotate(B.AX, th).distance_to(neck)) for th in (-40, 0, 40)]
    sm = dict(minus_x_cap_face_to_knuckle_end=seam(cap, -1), plus_x_lug_face_to_knuckle_end=seam(lug, 1),
              lug_barrel_to_saddle_radial=[r3((cap & (Pos(-20.4, 0, B.AXZ - 6) * Box(4.0, 30, 12))).rotate(B.AX, th).distance_to(neck))
                                          for th in (-40, 0, 40)],
              ptfe_ring_to_lip_tip=r3(ptfe.distance_to(neck)), lip_tip_to_cap_groove_bottom=r3(B.LIP[2] - B.GROOVE[2]),
              plug_radial_to_knuckle_bore=r3(B.BORE_R - B.PLUG[0]), plus_x_lip_tip_to_lug_groove_bottom=r3(B.GROOVE_P[2] - B.LIP_P[2]),
              sleeve_radial_to_counterbore=r3(B.CB_R - B.SLV[3]), mr85_outer_ring_to_counterbore_floor=r3(bo.distance_to(neck)),
              head_axial_float=dict(minus_x_stop="MR85 inner ring on its boss (0)", plus_x_stop="PTFE ring on the lip tip",
                                    float=r3(ptfe.distance_to(neck))))
    vals = sm["minus_x_cap_face_to_knuckle_end"] + sm["plus_x_lug_face_to_knuckle_end"]
    sm["seam_0p3_uniform"] = ok("E3 hinge seams 0.3", all(abs(v - 0.3) < 0.005 for v in vals), vals)
    ok("E3 head axial float <= 0.05", sm["head_axial_float"]["float"] <= 0.0501, sm["head_axial_float"]["float"])
    R["E3_hinge_seams"] = sm
    log("seams", sm)
    save()

# ---------------------------------------------------------------- L: lift 0..-20 vs collar (tilt 0)
if "L" in SEC:
    rows = {}
    for lf in (0, -2.5, -5, -7.5, -10, -12.5, -15, -17.5, -20):
        row = {}
        for mn, m in dict(krk_predna_polovica=nf, krk_zadna_polovica=nb, usko_kryt=cap, usko_lozisko=lug).items():
            mm = m.moved(Location((0, 0, lf)))
            for cn, c in dict(golier_kotuc=disc, golier_prstenec=ring).items():
                if bb_overlap(mm, c, 1.0):
                    row[f"{mn}-{cn}"] = r3(mm.distance_to(c))
        rows[lf] = [min(row.values()), min(row, key=row.get)] if row else None
        log("lift", lf, rows[lf])
    mn_ = min(v[0] for v in rows.values() if v)
    R["L_lift_vs_collar"] = dict(per_lift=rows, slot_clearance=ok("E3 collar slot clearance >= 0.25 over the lift", mn_ >= 0.249, mn_),
                                 collar=dict(disc_r=B.COLLAR[0], ring_r=[B.COLLAR[1], B.COLLAR[2]], torso_recess_r=B.COLLAR[3],
                                             slot=[B.BW + 0.5, B.BT + 0.5], slot_corner_r=B.BLADE_R + 0.25, slot_edge_r=0.6,
                                             disc_ring_seam=r3(disc.distance_to(ring)), ring_torso_seam=r3(B.COLLAR[3] - B.COLLAR[2])),
                                 note="the tilt-vs-lift firmware table depends on the head shape (W110 x H79) -> integration step")
    save()

# ---------------------------------------------------------------- E4 ray-cast walls of the printed black parts
if "E4" in SEC:
    def known(p, n, nm):
        x, y, z = p
        dz, r = z - B.AXZ, math.hypot(y, z - B.AXZ)
        if nm.startswith("krk"):
            if B.CB_X - 0.01 <= x <= B.BOSS[1] + 0.01 and r <= B.BOSS[0] + 0.05:
                return "MR85 inner-ring stop step (0.25 high ring r2.55..3.1 on the solid counterbore floor)"
            if abs(y) < B.VCH + 0.02:
                return "parting-line V chamfer 0.15 (edge of a solid half, not a wall)"
            if abs(abs(x) - B.KN) < 1.0 and 6.6 <= r <= 8.2:
                return "static lip ring r6.8..8.0 (1.2 radial, by design)"
        if nm == "usko_kryt":
            if x > B.CAP_SLOT_X1 - 0.01 and abs(abs(y) - B.RIB[1]) < 0.5 and abs(abs(dz) - B.RIB[2]) < 0.5:
                return "crush rib r0.35 in the arm slot (intended, crushed on assembly)"
            if x < B.CAP_HEAD_X1 + 0.05 and r <= 2.4:
                return "blind end wall 1.0 over the horn-screw head bore r2.3 (E2 C3: allowed down to 1.0)"
        return None

    rcr = {}
    for nm in ("krk_predna_polovica", "krk_zadna_polovica", "usko_kryt", "usko_lozisko", "golier_kotuc", "golier_prstenec"):
        Tm = B.tris(MINE[nm], 0.01, 0.1)
        Pp, Nn, th = rc.thickness(Tm, 15000)
        thin = np.nonzero(th < 1.19)[0]
        cls, unk = {}, []
        for i in thin:
            w = known(Pp[i], Nn[i], nm)
            if w:
                cls[w] = cls.get(w, 0) + 1
            else:
                unk.append(i)
        cl = {}
        for i in sorted(unk, key=lambda i: th[i]):
            key = tuple(np.round(Pp[i] / 1.5).astype(int))
            if key not in cl and len(cl) < 14:
                cl[key] = dict(t=r3(th[i]), at=[round(float(v), 2) for v in Pp[i]], n=[round(float(v), 2) for v in Nn[i]])
        fin = th[np.isfinite(th)]
        rcr[nm] = dict(samples=int(len(th)), min=r3(fin.min()), n_lt_1p19=int(len(thin)), listed_exceptions=cls,
                       n_unexplained=len(unk), unexplained_min=r3(min(th[unk])) if unk else None, unexplained_spots=list(cl.values()))
        ok(f"E4 {nm} walls >= 1.2 (listed exceptions only)", not unk, [rcr[nm]["unexplained_min"], len(unk)])
        log("E4", nm, {k: v for k, v in rcr[nm].items() if k != "unexplained_spots"})
        R["E4_raycast_walls"] = dict(method="tessellation tol 0.01, 15000 area-weighted samples, ray along -normal, wall = first hit "
                                            "with opposite normal (dot < -0.7), rays > 3 mm ignored (round-5 rule)", parts=rcr)
        save()

# ---------------------------------------------------------------- E5 servo envelope range vs the closed halves
if "E5" in SEC:
    box = Pos(-1.5, 0, 8.0) * Box(34.0, 20.6, 40.0)
    nk = neck & box
    def variant(dx=-B.XDAT, w=12.2, L=22.8, h=22.5, tur=6.0, lobe=(2.9, 5.6), nub=None, ny=None):
        s = B.servo(dx=dx, w=w, L=L, h=h, tur=tur, lobe=lobe, nub_x=nub)
        if ny:
            n0, n1 = nub or B.NUB[:2]
            s = s + B.rbox(n0 + dx, n1 + dx, -ny, ny, B.SZ0 + L - 0.3, B.SZ0 + L + B.NUB[3])
        return s
    X = B.XB
    V = {"nominal at the datum (gear face on the -X wall)": {},
         "nominal as modelled (dx 0)": dict(dx=0.0),
         "width 12.0": dict(w=12.0), "width 12.3": dict(w=12.3),
         "length 22.4": dict(L=22.4), "length 22.8": dict(L=22.8),
         "height 22.4": dict(h=22.4), "height 23.0": dict(h=23.0),
         "turret 5.4": dict(tur=5.4), "turret 6.2": dict(tur=6.2),
         "lobe centre 5.0 r 2.6": dict(lobe=(2.6, 5.0)), "lobe centre 5.0 r 3.1": dict(lobe=(3.1, 5.0)),
         "lobe centre 6.5 r 2.6": dict(lobe=(2.6, 6.5)), "lobe centre 6.5 r 3.1": dict(lobe=(3.1, 6.5)),
         "nub at XB-4.3..XB-2.3": dict(nub=(X - 4.3, X - 2.3), ny=2.2), "nub at XB-2.35..XB-0.35": dict(nub=(X - 2.35, X - 0.35), ny=2.2),
         "nub over the whole range XB-4.3..XB-0.35, |y| 2.2": dict(nub=(X - 4.3, X - 0.35), ny=2.2),
         "MAX stack: w12.3 L22.8 h23.0 turret 6.2 lobe 6.5/3.1 nub range": dict(w=12.3, L=22.8, h=23.0, tur=6.2, lobe=(3.1, 6.5),
                                                                              nub=(X - 4.3, X - 0.35), ny=2.2),
         "MIN stack: w12.0 L22.4 h22.4 turret 5.4 lobe 5.0/2.6": dict(w=12.0, L=22.4, h=22.4, tur=5.4, lobe=(2.6, 5.0))}
    rows, allfit = {}, True
    for nm, kw in V.items():
        s = variant(**kw)
        ov = ivol(s, nk)
        d = s.distance_to(nk) if ov < 1e-4 else 0.0
        h_ = kw.get("h", 22.5)
        gap = B.XB + B.XEND - (B.XC - B.XDAT + h_) if "dx" not in kw else B.XEND
        rows[nm] = dict(overlap_mm3=r3(ov), min_clear=r3(d), foam_pad_gap=r3(gap), foam_pad_compression_pct=round(100 * (1 - gap / B.PADX[4]), 1),
                        wires_room_x_beside_bottom_cover=r3(B.CHAM[1] - 0.15 - (B.XC - B.XDAT + h_)))
        allfit &= ov < 1e-4
        log("E5", nm, rows[nm])
    lob = B.keyhole_bore()
    R["E5_servo_range"] = dict(
        variants=rows, all_fit=ok("E5 servo envelope range fits", allfit, allfit),
        pocket=dict(x=[r3(B.XC - B.XDAT), r3(B.XB + B.XEND)], y_closed=r3(6.1 + B.GY - B.CLOSE), z=[r3(B.SZ0 - B.Z_FLOOR), r3(B.SZ1 + B.G)],
                    keyhole=dict(boss_r=r3(5.9 + B.G), lobe_relief_r=B.LOBE_REL[0], lobe_relief_centre_range=[0.0, B.LOBE_REL[1]],
                                 floor_x=r3(B.BOSS_FLOOR), radial_clear_to_lobe_r3p1=r3(B.LOBE_REL[0] - 3.1),
                                 end_wall_to_knuckle_face=r3(B.BOSS_FLOOR + B.KN)),
                    open_bore_minus_x=dict(r=B.BORE_R, x=[-B.KN, r3(B.BOSS_FLOOR)]),
                    lead_slot=dict(x=[r3(B.LEAD_KSLOT[0]), r3(B.LEAD_KSLOT[1])], half_y_design=B.LEAD_KSLOT[2],
                                   half_y_closed=r3(B.LEAD_KSLOT[2] - B.CLOSE))),
        shaft_height_note=dict(
            floor_to_axis=r3(B.AXZ - B.SZ0 + B.Z_FLOOR), turret_radial_clearance=B.G,
            accepted_far_end_to_spline_axis=[r3(16.9 - B.G), r3(16.9 + B.Z_FLOOR + B.G)],
            drawing_range_length_minus_near_end=[r3(22.4 - 5.9), r3(22.8 - 5.7)],
            text="the E5 length variants keep the spline ON the hinge axis with the far end on / above the floor; the "
                 "drawing allows far end -> spline axis 16.5..17.1: 16.5..16.9 hangs on the turret bore (<= 0.15 low, case "
                 "up to 0.25 above the floor), > 17.06 would need the far case end filed (assembly text)"))
    if 22.8 - 5.7 > 16.9 + B.Z_FLOOR + B.G:
        NOTE.append("E5: far case end -> spline axis above 17.06 (drawing max 17.1) does not fit the floor datum: file the far end 0.05 (montaz)")
    save()

# ---------------------------------------------------------------- E6 horn range
if "E6" in SEC:
    rows, good = {}, True
    for top in B.ARM_TOP:
        for dx in (-B.XDAT, 0.0, 0.15):
            h, sc = B.horn(top=top, dx=dx), B.horn_screw(top=top, dx=dx)
            ovc = cap & h
            lens = sorted(r3(s.bounding_box().size.X) for s in ovc.solids()) if ovc is not None and ovc.solids() else []
            rib_v = ivol(cap, h)
            sw = {}
            for th in (-40, -20, 0, 20, 40):
                ht, st = h.rotate(B.AX, th), sc.rotate(B.AX, th)
                sw[th] = dict(horn_vs_neck_mm3=r3(ivol(ht, neck)), horn_min_clear_neck=r3(ht.distance_to(neck)),
                              screw_min_clear_neck=r3(st.distance_to(neck)))
            xa = B.XC + dx - top
            row = dict(arm_x=[r3(xa), r3(xa + 1.6)], rib_overlap_mm3=r3(rib_v), rib_contact_lengths=lens,
                       screw_vs_cap_mm3=r3(ivol(sc, cap)), arm_top_to_slot_bottom=r3(xa - B.CAP_SLOT_X1),
                       screw_head_to_bore_bottom=r3(xa - 1.2 - B.CAP_HEAD_X1), arm_inner_face_inside_plug_by=r3(B.PLUG[1] - (xa + 1.6)),
                       arm_underside_to_turret_top_nominal=r3((B.XC + dx - B.TUR_H) - (xa + 1.6)), sweep=sw)
            c1 = min(v["horn_min_clear_neck"] for v in sw.values())
            row["min_clear_static_over_sweep"] = r3(c1)
            row["fits"] = bool(row["screw_vs_cap_mm3"] < 1e-4 and row["arm_top_to_slot_bottom"] >= 0 and
                               row["screw_head_to_bore_bottom"] >= -1e-9 and c1 >= 0.3 and len(lens) == 4 and
                               max(v["horn_vs_neck_mm3"] for v in sw.values()) < 1e-4)
            good &= row["fits"]
            rows[f"arm_top_{top}_dx{dx:+.2f}"] = row
            log("E6", top, dx, {k: v for k, v in row.items() if k != "sweep"})
    chord = 2 * math.sqrt(B.RIB[0] ** 2 - (B.RIB[0] - 0.1) ** 2)
    R["E6_horn_range"] = dict(rows=rows, all_fit=ok("E6 horn range 8.9..10.3 fits, >= 0.3 to the static neck", good, good),
                              cap=dict(slot_bottom_x=r3(B.CAP_SLOT_X1), head_bore_bottom_x=r3(B.CAP_HEAD_X1),
                                       blind_end_wall=r3(B.LUG1 + B.CAP_HEAD_X1), plug=dict(r=B.PLUG[0], tip_x=B.PLUG[1], half_height=B.PLUG[2]),
                                       rib=dict(r=B.RIB[0], full_x=[r3(B.RIB_X[1]), r3(B.RIB_X[2])], crushed_chord=r3(chord))),
                              note="dx = axial position of the servo: -0.05 = gear face on the datum wall, +0.15 = drifted off the datum")
    save()

# ---------------------------------------------------------------- E10 lead slot vs the static lead
if "E10" in SEC:
    x0, x1, hy, flare, zt, rr = B.LEAD_FSLOT
    zone = shell & (Pos((x0 + x1) / 2, 0, B.HZ + 4.5) * Box(x1 - x0 + 8, 44, 13))     # floor slot + the vault above it
    # straight, rigid, STATIC lead (worst case, does not flex) up to the height where the run turns to -X under the vault
    # (integration: was HZ+12 with the open slot; the vault over the slot is concentric with the hinge axis, inner r 19.8)
    rigid = B.zcyl(B.LEAD_R, B.AXZ + 7.9, B.HZ + B.LEAD_ZTURN, x=B.LEAD_X)
    rows = {}
    for th in range(-40, 45, 5):
        zr = zone.rotate(B.AX, th) if th else zone
        rows[th] = dict(stub=r3(zr.distance_to(stub)), rigid_straight_lead=r3(zr.distance_to(rigid)))
    m1, m2 = min(v["stub"] for v in rows.values()), min(v["rigid_straight_lead"] for v in rows.values())
    fz = B.head_floor_z(B.LEAD_X, 0.0)
    R["E10_lead_slot"] = dict(
        floor_slot=dict(x=[r3(x0), r3(x1)], flare_line_half_y_at_head_bottom=hy, flare_deg=flare, top_z=zt, corner_r=rr,
                        vertical_land_up_to_local_z=B.LEAD_LAND,
                        half_y_bottom_opening=r3(hy + B.LEAD_LAND * math.tan(math.radians(flare))),
                        half_y_at_local_z2p5=r3(hy + 2.5 * math.tan(math.radians(flare))), head_floor_z_at_lead=r3(fz)),
        knuckle_slot=dict(x=[r3(B.LEAD_KSLOT[0]), r3(B.LEAD_KSLOT[1])], half_y=B.LEAD_KSLOT[2], edge_r=B.LEAD_KSLOT[3]),
        lead=dict(model="tube r 1.3 (3 x D1.2 wires in a sleeve)", x=B.LEAD_X, stub_z=[r3(B.AXZ + 7.9), r3(B.AXZ + B.RK)],
                  rigid_test_lead_z=[r3(B.AXZ + 7.9), r3(B.HZ + B.LEAD_ZTURN)],
                  run_path_local=[[r3(x), r3(y), r3(z - B.HZ)] for x, y, z in B.lead_path()[0]], x_clear_in_slot=[r3(B.LEAD_X - B.LEAD_R - x0), r3(x1 - B.LEAD_X - B.LEAD_R)]),
        per_tilt=rows, min_stub=ok("E10 floor slot vs static stub >= 0.5", m1 >= 0.499, m1),
        min_rigid_lead=ok("E10 floor slot + vault vs a rigid straight lead >= 0.5", m2 >= 0.499, m2),
        vault=dict(inner_r_about_the_hinge_axis=B.HOOD_R[0], outer_r=B.HOOD_R[1], x=list(B.HOOD_X), lead_turn_local_z=B.LEAD_ZTURN,
                   lead_envelope_r=r3(B.HOOD_R[0] - B.HOOD_CL)),
        nub_extremes=dict(lead_centre_x_range=[r3(B.XB - 3.3), r3(B.XB - 1.35)],
                          flat_lead_1p2_wide_clear_x=[r3(B.XB - 3.3 - 0.6 - x0), r3(x1 - (B.XB - 1.35) - 0.6)],
                          round_sleeve_r1p3_clear_x=[r3(B.XB - 3.3 - 1.3 - x0), r3(x1 - (B.XB - 1.35) - 1.3)]))
    log("E10", m1, m2)
    save()

# ---------------------------------------------------------------- W: walls around the new voids + wire passages
if "W" in SEC:
    env = B.neck_env()
    big = Pos(0, 0, 20) * Box(160, 120, 160)
    x0, x1, hy, _ = B.LEAD_KSLOT
    excl = (Pos(0, 0, B.ZB - 49) * Box(200, 200, 101.0) + B.xcyl(8.5, 17.4, 18.6, 0, B.AXZ) + B.xcyl(8.5, -18.6, -17.4, 0, B.AXZ) +
            B.rbox(x0 - 0.6, x1 + 0.6, -hy - 0.6, hy + 0.6, B.AXZ + 8.5, B.AXZ + 12))      # bottom, hinge mouths, lead-slot mouth
    out_n = (big - env) - excl
    cv = B.closed_void_dict()
    OPEN = {k for k in cv if k.startswith("screw_cbore") or k.startswith("screw_clear")} | {"lead_slot"}   # open by design
    clipx = big - B.xcyl(10.6, 17.3, 18.7, 0, B.AXZ) - B.xcyl(10.6, -18.7, -17.3, 0, B.AXZ)
    to_out = {k: r3((v & clipx).distance_to(out_n)) for k, v in cv.items() if k not in OPEN}
    vv, merged, ks = {}, [], list(cv)
    for i, a in enumerate(ks):
        for b in ks[i + 1:]:
            if not bb_overlap(cv[a], cv[b], 4.0):
                continue
            d = cv[a].distance_to(cv[b])
            if d < 1e-6:
                merged.append(f"{a}+{b}")
            elif d < 4.0:
                vv[f"{a}-{b}"] = r3(d)
    kb, ls = B.keyhole_bore(), B.lead_slot()
    v0 = B.neck_void_dict()
    others = {k: v for k, v in v0.items() if k not in ("case_pocket", "lead_slot")}
    roof = B.rbox(B.XC - B.XDAT, B.XB + B.XEND, -6.15, 6.15, B.SZ1 + B.G - 1.5, B.SZ1 + B.G, 0.5, Axis.X)
    outk = (big - env) - B.rbox(x0 - 0.6, x1 + 0.6, -hy - 0.6, hy + 0.6, B.AXZ + 8.5, B.AXZ + 12)
    W = dict(
        neck_void_to_outside=to_out, neck_void_to_void_lt4=vv, merged_voids_by_design=merged,
        neck_min_wall=ok("W neck walls >= 1.2", min(list(vv.values()) + list(to_out.values())) >= 1.199,
                         min(list(vv.values()) + list(to_out.values()))),
        knuckle_lead_slot=dict(to_other_voids={k: r3(ls.distance_to(v)) for k, v in others.items() if ls.distance_to(v) < 8},
                               pocket_roof_to_knuckle_surface_beside_the_slot=r3(roof.distance_to(outk)),
                               roof_thickness_on_the_parting_plane=r3(B.AXZ + B.RK - (B.SZ1 + B.G)),
                               slot_to_pocket_plus_x_end=r3(B.XB + B.XEND - x1), slot_to_knuckle_plus_x_end=r3(B.KN - x1)),
        keyhole_bore=dict(to_other_voids={k: r3(kb.distance_to(v)) for k, v in others.items() if kb.distance_to(v) < 8},
                          to_outside=r3(kb.distance_to((big - env) - B.xcyl(8.5, -18.6, -17.4, 0, B.AXZ))),
                          end_wall_x=r3(B.BOSS_FLOOR + B.KN), lobe_relief_lowest_z=r3(B.AXZ - B.LOBE_REL[1] - B.LOBE_REL[0]),
                          bore_to_knuckle_surface_radial=r3(B.RK - B.BORE_R), bore_to_lip_ring_inner=r3(B.LIP[0] - B.BORE_R)))
    for nm, d in (("knuckle slot", W["knuckle_lead_slot"]["to_other_voids"]), ("keyhole bore", W["keyhole_bore"]["to_other_voids"])):
        bad = {k: v for k, v in d.items() if 1e-6 < v < 1.199}
        ok(f"W {nm} to other voids >= 1.2", not bad, bad)
    ok("W keyhole bore to outside >= 1.2", W["keyhole_bore"]["to_outside"] >= 1.199, W["keyhole_bore"]["to_outside"])
    ok("W pocket roof beside the slot >= 1.2", W["knuckle_lead_slot"]["pocket_roof_to_knuckle_surface_beside_the_slot"] >= 1.199,
       W["knuckle_lead_slot"]["pocket_roof_to_knuckle_surface_beside_the_slot"])
    # ---- lugs
    half_m = Pos(-B.LUG0 - 50.6, 0, 0) * Box(100, 100, 200)
    half_p = Pos(B.LUG0 + 50.6, 0, 0) * Box(100, 100, 200)
    env_cap, env_lug = B.lug_blank(-1), B.lug_blank(1)
    cap_v = (env_cap - cap) & half_m
    for g in B.groove_holes(-1, 1.3):
        cap_v = cap_v - g
    ch = B.lug_channel()
    lug_v = (B.xcyl(B.LCH_R, B.BRG_X1 - 0.01, B.LCH_Z0, 0, B.AXZ) + (ch & (Pos(0, 0, B.HZ - 50.6) * Box(200, 200, 100)))) & half_p
    gp = B.xcyl(B.GROOVE_P[1], B.LUG0, B.GROOVE_P[2], 0, B.AXZ) - B.xcyl(B.GROOVE_P[0], 17, 19, 0, B.AXZ)
    ten = B.tenon_box(1)
    zslab = Pos(0, 0, (B.HZ + B.TEN[4]) / 2 + 0.2) * Box(100, 100, B.TEN[4] - B.HZ - 0.6)
    ten_out = ((Pos(20.3, 0, B.HZ + 4) * Box(12, 30, 12)) - ten) & zslab
    gh = B.groove_holes(1)
    hw = B.LCH_W[0]
    Wl = dict(cap_voids_to_outer_surface=r3(cap_v.distance_to((big - env_cap) & half_m)),
              cap_blind_end_wall_over_head_bore=r3(B.LUG1 + B.CAP_HEAD_X1),
              lug_voids_to_outer_surface=r3(lug_v.distance_to((big - env_lug) & half_p)),
              lug_slot_to_lip_groove=r3(ch.distance_to(gp)),
              lug_slot_to_mr85_stop_shoulder=r3(ch.distance_to(B.xcyl(4.04, B.SLV[0], B.BRG_X1, 0, B.AXZ))),
              lug_slot_in_tenon_min_wall=r3((ch & zslab).distance_to(ten_out)),
              lug_slot_to_cross_screw_pilots=r3(min(ch.distance_to(g) for g in gh)),
              lip_groove_plus_x_to_barrel=r3(B.RK - B.GROOVE_P[1]), lip_groove_minus_x_to_barrel=r3(B.RK - B.GROOVE[1]),
              sleeve_wall=r3(B.SLV[3] - B.SLV[2]), plug_cheek_min_thickness=r3(math.sqrt(B.PLUG[0] ** 2 - B.PLUG[2] ** 2) - 2.5),
              lip_ring_radial=r3(B.LIP[1] - B.LIP[0]))
    ok("W cap walls >= 1.2 (blind end wall 1.0 allowed)", Wl["cap_voids_to_outer_surface"] >= 0.999, Wl["cap_voids_to_outer_surface"])
    ok("W lug walls >= 1.2", min(Wl["lug_voids_to_outer_surface"], Wl["lug_slot_to_lip_groove"], Wl["lug_slot_to_mr85_stop_shoulder"],
                                 Wl["lug_slot_in_tenon_min_wall"]) >= 1.199, [Wl["lug_voids_to_outer_surface"], Wl["lug_slot_to_lip_groove"],
                                                                              Wl["lug_slot_to_mr85_stop_shoulder"], Wl["lug_slot_in_tenon_min_wall"]])
    ok("W lug slot to pilots >= 1.0", Wl["lug_slot_to_cross_screw_pilots"] >= 0.999, Wl["lug_slot_to_cross_screw_pilots"])
    W["lugs"] = Wl
    # ---- wire passages for 4 x D0.85 (0.15 print shrink per printed wall)
    d, sh = 0.85, 0.15
    slot_x, slot_y = 2 * hw - 2 * sh, (B.LCH_W[2] - B.LCH_W[1] + 2 * hw) - 2 * sh
    pas = dict(wire_d=d, n=4, shrink_per_wall=sh,
               lug_slot=dict(section=[2 * hw, B.LCH_W[2] - B.LCH_W[1] + 2 * hw], after_shrink=[r3(slot_x), r3(slot_y)], arrangement="4 in a row",
                             clear_x=r3(slot_x - d), clear_y=r3(slot_y - 4 * d)),
               neck_chamber=dict(width_y=2 * B.CHAM[2], after_shrink=r3(2 * B.CHAM[2] - 2 * sh), clear_y_4_in_a_row=r3(2 * B.CHAM[2] - 2 * sh - 4 * d),
                                 neck_under_pin_width=2 * B.CHAM_N, neck_clear_2_abreast=r3(2 * B.CHAM_N - 2 * sh - 2 * d),
                                 depth_behind_pocket_wall=r3(B.CHAM[1] - (B.XB + B.XEND)),
                                 room_x_to_bottom_cover={f"case_h_{h}": r3(B.CHAM[1] - sh - (B.XC - B.XDAT + h)) for h in (22.4, 22.5, 22.7, 23.0)}),
               pin_end_slot=dict(width=B.PIN_SLOT[0], length=B.PIN_SLOT[1], steel="no shrink", clear_2_abreast=r3(B.PIN_SLOT[0] - 2 * d)),
               pin_bore=dict(d=3.0, bundle_2x2_circumscribed=r3((1 + math.sqrt(2)) * d), clear=r3(3.0 - (1 + math.sqrt(2)) * d)),
               lug_chamber=dict(r=B.LCH_R, x=[B.BRG_X1, B.LCH_Z0], rotating_bend_R=r3(B.LCH_X - B.BRG_X1)))
    cond = min(pas["lug_slot"]["clear_x"], pas["lug_slot"]["clear_y"], pas["neck_chamber"]["clear_y_4_in_a_row"],
               pas["pin_end_slot"]["clear_2_abreast"], pas["pin_bore"]["clear"], pas["neck_chamber"]["neck_clear_2_abreast"],
               pas["neck_chamber"]["room_x_to_bottom_cover"]["case_h_23.0"] - d) >= 0.299
    pas["all_ge_0p3"] = ok("W wire passages 4 x D0.85 with >= 0.3", cond, cond)
    W["wire_passages"] = pas
    R["W_walls_passages"] = W
    log("W", {k: v for k, v in W.items() if k in ("neck_void_to_outside", "neck_void_to_void_lt4", "lugs")})
    save()

# ---------------------------------------------------------------- A: assembly paths (overlap volumes along the insertion)
if "A" in SEC:
    def path(mov, sta, vec, steps, mesh=False):
        out = {}
        for s_ in steps:
            x = mov.moved(Location((vec[0] * s_, vec[1] * s_, vec[2] * s_))) & sta
            v = 0.0 if x is None or not x.solids() else (HC.mesh_volume(x) if mesh else sum(q.volume for q in x.solids()))
            out[str(s_)] = r3(v)
        return out
    asm = {"1_servo_dropped_into_the_front_half_along_-Y (vs front half)": path(servo, nf, (0, 1, 0), (6.5, 3.0, 1.0, 0.3, 0.0)),
           "2_horn_pushed_on_the_spline_from_-X (vs closed neck)": path(horn + hscr, neck, (-1, 0, 0), (4.0, 2.0, 1.0, 0.0)),
           "3_plus_lug_with_MR85_slid_-X_over_the_pin (vs neck + pin + inner ring)": path(lug + bo, neck + pin + bi, (1, 0, 0), (3.0, 2.0, 1.0, 0.5, 0.0)),
           "4_cap_slid_+X_over_the_horn_arms (vs neck + servo)": path(cap + ptfe, neck + servo, (-1, 0, 0), (3.0, 2.0, 1.0, 0.5, 0.0)),
           "4b_cap_vs_horn_during_the_slide (only the 4 crush ribs touch the arms)": path(cap, horn + hscr, (-1, 0, 0), (3.0, 2.0, 1.0, 0.5, 0.0)),
           "5_head_lowered_vertically_onto_both_tenons (vs lugs + neck + lead stub)": path(shell, cap + lug + neck + stub, (0, 0, 1), (12.0, 8.0, 4.0, 2.0, 1.0, 0.5, 0.0), True),
           "6_collar_disc_slid_down_over_the_neck_with_the_horn_mounted (neck at mid lift)": path(disc, (neck + B.horn(top=B.ARM_TOP[2]) + B.horn_screw(top=B.ARM_TOP[2])).moved(Location((0, 0, -10))), (0, 0, 1), (30.0, 20.0, 10.0, 0.0))}
    bad = {k: v for k, v in asm.items() if not k.startswith("4b") and max(v.values()) > 1e-3}
    asm["all_paths_free"] = ok("A assembly paths free", not bad, bad)
    R["A_assembly_paths"] = asm
    log("A", asm)
    save()

save()
log("done; FAILED:", FAIL, "NOTES:", NOTE)
