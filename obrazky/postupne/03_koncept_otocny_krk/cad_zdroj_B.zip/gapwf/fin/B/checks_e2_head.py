"""NOVA mini B, revision E2f - HEAD checks (shell, bezel, display, carrier, magnets, ear pods) -> checks_e2_head.json
run:  /opt/venv/cad/bin/python checks_e2_head.py [section ...]     (no argument = all sections)
INTEGRATED model: live head_common.py + the REAL floor interface of build.py (head_pads_and_cuts(): pads, tenon slots,
cross-screw holes; cross_screws()).  E2f: the servo lead goes DOWN into the torso -> no servo-lead floor slot, no vault,
no cable bridge in the head any more (section 9 = the closed floor between the pads instead of the bridge).  Written by the head engineer against a test harness
(B_headdev/harness.py, round-5 pads); the integration step only replaced the harness by build.py (class HN below).
Every number below is computed (booleans, OCC distances, ray casts)."""
import sys, json, time, math, os, warnings
warnings.filterwarnings("ignore")
sys.path.insert(0, "/tmp/claude-0/gapwf/fin/B")
import numpy as np
import rc, vis_zbuf
import build as B
import head_common as HC
from build123d import Pos, Box, Compound, Location, Axis, Solid, Vector


class HN:
    """what the head checks need from the neck / hinge side - now taken from the integrated builder"""
    HZ, ZS, SCR_X, PAD = B.HZ, B.ZS, B.SCR_X, B.PAD
    pads_and_cuts = staticmethod(B.head_pads_and_cuts)
    cross_screws = staticmethod(B.cross_screws)


OUT = "/tmp/claude-0/gapwf/fin/B/checks_e2_head.json"
SECT = set(sys.argv[1:])
t0 = time.time()
try:
    R = json.load(open(OUT)) if SECT else {}
except Exception:
    R = {}
R["units"] = "mm / mm3 / N; world coordinates, extended pose (head bottom z = 27), front -Y"
HZ = HN.HZ
ZC = HZ + HC.H / 2
mv = HC.mesh_volume


def want(k):
    return (not SECT) or (k in SECT)


def save():
    R["time_s"] = round(time.time() - t0, 1)
    json.dump(R, open(OUT, "w"), indent=1)


def r3(x):
    return None if x is None else round(float(x), 3)


def r4(x):
    return round(float(x), 4)


def log(*a):
    print(f"[{time.time() - t0:6.1f}]", *a, flush=True)


def ivol(a, b, mesh=False):
    x = a & b
    if x is None or not x.solids():
        return 0.0
    return round(float(mv(x) if mesh else sum(s.volume for s in x.solids())), 4)


def bbx(s):
    b = s.bounding_box()
    return [r3(b.min.X), r3(b.max.X), r3(b.min.Y), r3(b.max.Y), r3(b.min.Z), r3(b.max.Z)]


def ybox(y0, y1):
    return Pos(0, (y0 + y1) / 2, ZC) * Box(200, y1 - y0, 200)


def mv_move(s, dy):
    return s.moved(Location((0, dy, 0)))


def tris(s, tol=0.01, ang=0.08):
    return B.tris(s, tol, ang)


# ---------------------------------------------------------------- build
adds, cuts = HN.pads_and_cuts()
shell = HC.head_shell(HZ, cuts=cuts, adds=adds)
bezel, gasket = HC.bezel(HZ), HC.gasket(HZ)
dp, ca, mg = HC.display_parts(HZ), HC.carrier(HZ), HC.magnets(HZ)
ears, rings, ledb, eyes = HC.ears(HZ), HC.led_rings(HZ), HC.led_boards(HZ), HC.eyes(HZ)
xscr = HN.cross_screws()
pads = Compound(list(adds))
NAMED = dict(hlava_skrupina=shell, ram_displeja=bezel, pena_displeja=gasket, displej_glass=dp["glass"], displej_lcd=dp["lcd"],
             displej_pcb=dp["pcb"], displej_standoffs=dp["standoffs"], displej_header=dp["header"], displej_usbc=dp["usbc"],
             displej_small=dp["small"], drziak_displeja=ca["bars"], skrutky_carrier=ca["screws"], skrutky_inserts=ca["inserts"],
             magnety_bezel=mg["bezel"], magnety_shell=mg["shell"], usi=ears, led_kruzky=rings, led_dosky=ledb,
             oci_len_vizualizacia=eyes, skrutky_cross_ref=xscr)
LOFTY = {"hlava_skrupina", "ram_displeja"}
log("built", HC.SHELL_NOTES)
R["build_notes"] = dict(shell=HC.SHELL_NOTES, model="INTEGRATED: pads |x| %.1f..%.1f, tenon slots and cross-screw holes from "
                        "build.head_pads_and_cuts() (E2f: %d adds, no lead slot / vault / bridge); head module %s"
                        % (B.PAD[0], B.PAD[1], len(adds), HC.__file__))
FAIL = [f for f in R.get("failed", []) if f.split(" ")[0][1:] not in SECT] if SECT else []
R["failed"] = FAIL


def flag(name, cond, val=None):
    """collect failed criteria for the consolidated summary (checks.py)"""
    if not cond:
        FAIL.append(f"{name}: {val}")
    R["failed"] = FAIL
    return bool(cond)

# ---------------------------------------------------------------- 1. E1 validity, volumes, closed meshes
if want("1"):
    def closed(s, tol=0.01):
        bad = 0; nt = 0
        for sol in s.solids():
            T = tris(sol, tol, 0.1)
            V = np.round(T.reshape(-1, 3).astype(np.float64), 4)
            _, inv = np.unique(V, axis=0, return_inverse=True)
            F = inv.reshape(-1, 3)
            F = F[(F[:, 0] != F[:, 1]) & (F[:, 1] != F[:, 2]) & (F[:, 0] != F[:, 2])]
            E = np.sort(np.concatenate([F[:, [0, 1]], F[:, [1, 2]], F[:, [2, 0]]]), axis=1)
            _, cnt = np.unique(E, axis=0, return_counts=True)
            bad += int((cnt != 2).sum()); nt += len(F)
        return dict(triangles=nt, edges_not_shared_by_2=bad)
    e1 = {}
    for k, s in NAMED.items():
        e1[k] = dict(valid=bool(s.is_valid), solids=len(s.solids()), mesh_volume=round(mv(s), 1),
                     occ_volume=round(sum(x.volume for x in s.solids()), 1), bbox=bbx(s))
        if k in ("hlava_skrupina", "ram_displeja", "drziak_displeja", "usi", "led_kruzky"):
            e1[k]["stl_mesh"] = closed(s)
        log("E1", k, e1[k])
    e1["all_valid"] = all(v["valid"] for v in e1.values() if isinstance(v, dict))
    o, i = HC.head_outer(HZ), HC.inner_skin(HZ)
    e1["reference_volumes"] = dict(head_outer_mesh=round(mv(o), 1), head_outer_occ=round(o.volume, 1),
                                   cavity_mesh=round(mv(i), 1), cavity_occ=round(i.volume, 1),
                                   note="OCC GProp is off by up to 3 % on the periodic lofts -> mesh volumes are the reference")
    e1["mesh_volume_convergence_shell"] = dict(tol_0p02=round(mv(shell, 0.02), 1), tol_0p005=round(mv(shell, 0.005), 1))
    R["1_E1_validity_volumes"] = e1
    flag("H1 all head solids valid", e1["all_valid"], [k for k, v in e1.items() if isinstance(v, dict) and v.get("valid") is False])
    flag("H1 printed head meshes closed", all(v["stl_mesh"]["edges_not_shared_by_2"] == 0 for v in e1.values() if isinstance(v, dict) and "stl_mesh" in v),
         {k: v["stl_mesh"]["edges_not_shared_by_2"] for k, v in e1.items() if isinstance(v, dict) and "stl_mesh" in v})
    flag("H1 mesh volumes > 0", all(v["mesh_volume"] > 0 for v in e1.values() if isinstance(v, dict) and "mesh_volume" in v),
         {k: v["mesh_volume"] for k, v in e1.items() if isinstance(v, dict) and "mesh_volume" in v and v["mesh_volume"] <= 0})
    save()


def first_hit(solid, origin, direction, which="min"):
    pts = solid.find_intersection_points(Axis(origin, direction))
    o = Vector(*origin); d = Vector(*direction)
    ts = sorted((p - o).dot(d) for p, n in pts if (p - o).dot(d) > 1e-6)
    return ts[0] if ts else None


# ---------------------------------------------------------------- 2. bezel / shell step at 72 seam points
def radial(solid, y, th):
    c, s = math.cos(th), math.sin(th)
    pts = solid.find_intersection_points(Axis((90 * c, y, ZC + 90 * s), (-c, 0, -s)))
    return max(math.hypot(p.X, p.Z - ZC) for p, n in pts) if pts else None


if want("2"):
    rows = []
    for i in range(72):
        th = math.radians(5 * i + 2.5)
        rb = [radial(bezel, y, th) for y in (-26.6, -26.4, -26.2)]
        rs = [radial(shell, y, th) for y in (-25.8, -25.6, -25.4)]
        eb = rb[0] - 3 * rb[1] + 3 * rb[2]                    # quadratic extrapolation to the seam plane y=-26
        es = rs[2] - 3 * rs[1] + 3 * rs[0]
        a, b = HC.ab(HC.Y_SEAM)
        rows.append((5 * i + 2.5, eb - es, eb - HC.se_r(a, b, th), es - HC.se_r(a, b, th),
                     rb[2] - HC.se_r(*HC.ab(-26.2), th), rs[0] - HC.se_r(*HC.ab(-25.8), th)))
    A = np.array(rows)
    # V-seam: chamfer faces measured on the seam plane (ray just inside each part)
    vs = []
    for th_deg in (2.5, 47.5, 92.5, 182.5, 272.5):
        th = math.radians(th_deg)
        a, b = HC.ab(HC.Y_SEAM); r0 = HC.se_r(a, b, th)
        vs.append(dict(theta=th_deg, bezel_depth_at_seam=r4(r0 - radial(bezel, HC.Y_SEAM - 0.002, th)),
                       shell_depth_at_seam=r4(r0 - radial(shell, HC.Y_SEAM + 0.002, th)),
                       bezel_depth_0p12_before=r4(HC.se_r(*HC.ab(HC.Y_SEAM - 0.125), th) - radial(bezel, HC.Y_SEAM - 0.125, th)),
                       shell_depth_0p12_after=r4(HC.se_r(*HC.ab(HC.Y_SEAM + 0.125), th) - radial(shell, HC.Y_SEAM + 0.125, th))))
    R["2_seam_step_72pts"] = dict(
        method="72 polar rays (every 5 deg) in the planes y -26.6/-26.4/-26.2 (bezel) and -25.8/-25.6/-25.4 (shell), "
               "outermost hit radius, quadratic extrapolation of both exterior surfaces to the seam plane y=-26",
        step_bezel_minus_shell=dict(min=r4(A[:, 1].min()), max=r4(A[:, 1].max()), abs_max=r4(np.abs(A[:, 1]).max())),
        bezel_vs_analytic_at_seam=[r4(A[:, 2].min()), r4(A[:, 2].max())],
        shell_vs_analytic_at_seam=[r4(A[:, 3].min()), r4(A[:, 3].max())],
        bezel_surface_dev_at_y_m26p2=[r4(A[:, 4].min()), r4(A[:, 4].max())],
        shell_surface_dev_at_y_m25p8=[r4(A[:, 5].min()), r4(A[:, 5].max())],
        v_seam=vs, v_seam_nominal="chamfer 0.12 x 45 deg on both edges -> V 0.24 wide x 0.12 deep",
        passes=bool(np.abs(A[:, 1]).max() <= 0.02))
    # rabbet floor ledge all around (round-5 finding: ridge / slivers at the rabbet floor): +Y probes at 72 angles
    led, floor_y, inner_first = [], [], []
    for i in range(72):
        th = math.radians(5 * i + 2.5)
        c_, s_ = math.cos(th), math.sin(th)
        a, b = HC.ab(HC.Y_SEAM); r_out = HC.se_r(a - HC.RAB_SH, b - HC.RAB_SH, th)
        a, b = HC.ab(HC.Y_RAB); r_in = HC.se_r(a - HC.WALL, b - HC.WALL, th)
        led.append(r_out - r_in)
        rm = (r_out + r_in) / 2
        floor_y.append(first_hit(shell, (rm * c_, -30.0, ZC + rm * s_), (0, 1, 0)) - 30.0)
        h = first_hit(shell, ((r_in - 0.15) * c_, -30.0, ZC + (r_in - 0.15) * s_), (0, 1, 0))
        inner_first.append(99.0 if h is None else h - 30.0)
    R["2_seam_step_72pts"]["rabbet_floor_probe"] = dict(
        ledge_width_analytic=[r3(min(led)), r3(max(led))], floor_y_on_ledge_mid=[r4(min(floor_y)), r4(max(floor_y))],
        first_material_0p15_inside_the_inner_skin_y=[r3(min(inner_first)), r3(max(inner_first))],
        note="mid-ledge probes all hit the floor plane y=-25.0; 0.15 inside the inner skin nothing is hit before the magnet-boss "
             "front faces (y=-25.0, 6 places) / the cavity -> no ridge, no sliver")
    log("seam", R["2_seam_step_72pts"]["step_bezel_minus_shell"], vs[0], R["2_seam_step_72pts"]["rabbet_floor_probe"])
    flag("H2 bezel / shell step <= 0.02 at 72 seam points", R["2_seam_step_72pts"]["passes"], R["2_seam_step_72pts"]["step_bezel_minus_shell"])
    save()


# ---------------------------------------------------------------- 3. E7 display fit
def sd_rrect(px, pz, w, h, r):
    """signed distance to a rounded rectangle w x h, corner radius r (negative inside)"""
    qx, qz = abs(px) - (w / 2 - r), abs(pz) - (h / 2 - r)
    return math.hypot(max(qx, 0.0), max(qz, 0.0)) + min(max(qx, qz), 0.0) - r


if want("3"):
    e7 = {}
    yg = HC.Y_G0 + HC.GLASS_T / 2
    pw = [first_hit(bezel, (0, yg, ZC), d) for d in ((1, 0, 0), (-1, 0, 0), (0, 0, 1), (0, 0, -1))]
    yw = HC.Y_LIP - 0.3                                         # straight part of the window wall
    ww = [first_hit(bezel, (0, yw, ZC), d) for d in ((1, 0, 0), (-1, 0, 0), (0, 0, 1), (0, 0, -1))]
    gb = dp["glass"].bounding_box()
    e7["glass_bbox"] = bbx(dp["glass"])
    e7["pocket_half_size_measured_xz"] = [r3(pw[0]), r3(pw[1]), r3(pw[2]), r3(pw[3])]
    e7["glass_to_pocket_clearance_xz"] = [r3(pw[0] - gb.max.X), r3(pw[1] + gb.min.X), r3(pw[2] - (gb.max.Z - ZC)), r3(pw[3] + (gb.min.Z - ZC))]
    e7["glass_to_bezel_min_distance"] = r3(dp["glass"].distance_to(bezel))
    e7["window_half_size_measured_xz"] = [r3(ww[0]), r3(ww[1]), r3(ww[2]), r3(ww[3])]
    lip_front = first_hit(bezel, (HC.WIN_W / 2 + 0.7, -40, ZC), (0, 1, 0))
    pts = sorted(p.Y for p, n in bezel.find_intersection_points(Axis((HC.WIN_W / 2 + 0.7, -40, ZC), (0, 1, 0))))
    e7["lip_y_front_back_at_x45p7"] = [r3(pts[0]), r3(pts[1])]
    e7["lip_thickness"] = r3(pts[1] - pts[0])
    e7["glass_front_y"] = r3(gb.min.Y)
    e7["glass_recess_below_bezel_front"] = r3(gb.min.Y - pts[0])
    e7["gasket"] = dict(bbox=bbx(gasket), thickness=r3(gasket.bounding_box().max.Y - gasket.bounding_box().min.Y),
                        overlap_bezel=ivol(gasket, bezel, True), overlap_glass=ivol(gasket, dp["glass"]),
                        dist_bezel=r3(gasket.distance_to(bezel)), dist_glass=r3(gasket.distance_to(dp["glass"])),
                        inner_edge_outside_window_by=[r3(-gasket.bounding_box().min.X - HC.GASK_W - HC.WIN_W / 2 + 0.0),
                                                      r3(gasket.bounding_box().max.Z - ZC - HC.GASK_W - HC.WIN_H / 2)])
    # lip overlap all around: distance from the glass outline to the window outline (both rounded rectangles)
    ov = []
    w, h, r = HC.GLASS_W, HC.GLASS_H, HC.GLASS_R
    n = 720
    for i in range(n):
        t = 2 * math.pi * i / n
        # point on the glass outline along the polar ray (bisection on the signed distance)
        lo, hi = 0.0, 80.0
        for _ in range(50):
            m = (lo + hi) / 2
            if sd_rrect(m * math.cos(t), m * math.sin(t), w, h, r) < 0:
                lo = m
            else:
                hi = m
        ov.append(sd_rrect(lo * math.cos(t), lo * math.sin(t), 2 * ww[0], 2 * ww[2], HC.WIN_R))
    e7["lip_overlap_on_glass"] = dict(min=r3(min(ov)), max=r3(max(ov)), sides_x=r3(gb.max.X - ww[0]), sides_z=r3(gb.max.Z - ZC - ww[2]),
                                      spec="1.2 +- 0.05", passes=bool(min(ov) >= 1.15 and max(ov) <= 1.25))
    e7["window_clear_of_active_area"] = dict(x=r3(ww[0] - HC.AA_W / 2), z=r3(ww[2] - HC.AA_H / 2), spec=">= 8 / 4.5",
                                             passes=bool(ww[0] - HC.AA_W / 2 >= 8 and ww[2] - HC.AA_H / 2 >= 4.5))
    eb = eyes.bounding_box()
    e7["eyes"] = dict(bbox=bbx(eyes), inside_active_area=bool(abs(eb.min.X) <= HC.AA_W / 2 and eb.max.X <= HC.AA_W / 2 and
                                                           eb.max.Z - ZC <= HC.AA_H / 2 and ZC - eb.min.Z <= HC.AA_H / 2),
                      in_front_of_glass_by=r3(gb.min.Y - eb.max.Y), overlap_glass=ivol(eyes, dp["glass"]))
    # standoffs / screws / posts / inserts
    so = sorted([(round(s.center().X, 3), round(s.center().Z - ZC, 3)) for s in dp["standoffs"].solids()])
    scr = [(s.center().X, s.center().Z - ZC, s) for s in ca["screws"].solids()]
    ins = sorted([(round(s.center().X, 3), round(s.center().Z - ZC, 3)) for s in ca["inserts"].solids()])
    def axis_of(s):                                             # axis of a screw = bbox centre in x, z
        b = s.bounding_box(); return ((b.min.X + b.max.X) / 2, (b.min.Z + b.max.Z) / 2 - ZC)
    sa = [axis_of(s) for s in ca["screws"].solids()]
    dev_so = [min(math.hypot(x - ax, z - az) for ax, az in sa) for x, z in so]
    dev_in = [min(math.hypot(x - ax, z - az) for ax, az in sa) for x, z in ins]
    post = HC.post_positions(HZ)
    e7["standoffs"] = dict(centres_xz_rel=so, pattern=[r3(so[-1][0] - so[0][0]), r3(so[-1][1] - so[0][1])], spec="72.00 x 48.50",
                           screw_axis_offset_max=r4(max(dev_so)), end_plane_y=r3(dp["standoffs"].bounding_box().max.Y))
    e7["inserts"] = dict(centres_xz_rel=ins, screw_axis_offset_max=r4(max(dev_in)),
                         post_axes_world=[[r3(x), r3(z)] for x, z in post])
    e7["mounting_plane"] = dict(standoff_ends_y=r3(dp["standoffs"].bounding_box().max.Y), bezel_post_faces_y=r3(bezel.bounding_box().max.Y),
                                bar_front_face_y=r3(ca["bars"].bounding_box().min.Y), bar_back_face_y=r3(ca["bars"].bounding_box().max.Y),
                                pcb_back_y=r3(dp["pcb"].bounding_box().max.Y), header_top_y=r3(dp["header"].bounding_box().max.Y),
                                depth_behind_glass_front=dict(pcb_back=r3(dp["pcb"].bounding_box().max.Y - gb.min.Y),
                                                              standoff_ends=r3(dp["standoffs"].bounding_box().max.Y - gb.min.Y),
                                                              header_top=r3(dp["header"].bounding_box().max.Y - gb.min.Y)))
    e7["contacts_mm3"] = dict(bars_vs_standoffs=ivol(ca["bars"], dp["standoffs"]), bars_vs_bezel=ivol(ca["bars"], bezel, True),
                              screws_vs_bars=ivol(ca["screws"], ca["bars"]), screws_vs_standoffs=ivol(ca["screws"], dp["standoffs"]),
                              screws_vs_inserts=ivol(ca["screws"], ca["inserts"]), inserts_vs_bezel=ivol(ca["inserts"], bezel, True),
                              screws_vs_bezel=ivol(ca["screws"], bezel, True), screws_vs_pcb=ivol(ca["screws"], dp["pcb"]))
    e7["distances"] = dict(bars_to_standoffs=r3(ca["bars"].distance_to(dp["standoffs"])), bars_to_bezel_posts=r3(ca["bars"].distance_to(bezel)),
                           standoff_screw_tip_to_pcb=r3(min(s.distance_to(dp["pcb"]) for s in ca["screws"].solids())),
                           inserts_to_bezel=r3(ca["inserts"].distance_to(bezel)))
    # keep-out
    ko = dp["keepout"]
    others = dict(bars=ca["bars"], screws=ca["screws"], inserts=ca["inserts"], bezel=bezel, shell=shell, gasket=gasket,
                  mag_bezel=mg["bezel"], mag_shell=mg["shell"], cross_screws=xscr, led_boards=ledb, ears=ears)
    e7["keepout"] = dict(definition="PCB footprint 78.0 x 54.6 from the PCB back (7.50) to the standoff-end plane (11.50) minus the four "
                                    "5.5 x 5.5 corner zones (standoff + bar tab), plus the header zone (41.9 x 6.2) up to 12.50",
                         bbox=bbx(ko), volume=r3(ko.volume),
                         overlap_mm3={k: ivol(ko, v, k in ("bezel", "shell")) for k, v in others.items()},
                         min_distance={k: r3(ko.distance_to(v)) for k, v in others.items() if k in ("bars", "screws", "bezel", "shell", "mag_shell", "cross_screws")})
    e7["keepout"]["nothing_inside"] = bool(all(v == 0 for v in e7["keepout"]["overlap_mm3"].values()))
    real = dict(header=dp["header"], usbc=dp["usbc"], small=dp["small"], pcb=dp["pcb"], lcd=dp["lcd"], standoffs=dp["standoffs"])
    e7["bars_to_real_components_min_distance"] = {k: r3(ca["bars"].distance_to(v)) for k, v in real.items()}
    e7["bar_screws_to_real_components_min_distance"] = {k: r3(ca["screws"].distance_to(v)) for k, v in real.items() if k != "standoffs"}
    e7["display_inside_bezel_pocket"] = dict(lcd_to_bezel=r3(dp["lcd"].distance_to(bezel)), pcb_to_bezel=r3(dp["pcb"].distance_to(bezel)),
                                             display_overlap_bezel=round(sum(ivol(dp[k], bezel, True) for k in ("glass", "lcd", "pcb", "standoffs", "header", "usbc", "small")), 4))
    e7["display_to_shell_min_distance"] = {k: r3(dp[k].distance_to(shell)) for k in ("glass", "lcd", "pcb", "header", "usbc", "small")}
    e7["display_to_shell_magnets"] = r3(min(dp[k].distance_to(mg["shell"]) for k in ("lcd", "pcb")))
    e7["header_pins_world"] = {str(n): [r3(v) for v in HC.header_pin(n, HZ)] for n in (1, 2, 3, 4, 5, 6, 31, 32)}
    R["3_E7_display"] = e7
    log("E7", {k: v for k, v in e7.items() if k in ("glass_to_pocket_clearance_xz", "lip_overlap_on_glass", "window_clear_of_active_area", "mounting_plane")})
    log("E7 keepout", e7["keepout"]["overlap_mm3"], e7["keepout"]["min_distance"], e7["bars_to_real_components_min_distance"])
    flag("H3 glass to pocket 0.2", all(abs(v - 0.2) < 0.005 for v in e7["glass_to_pocket_clearance_xz"]), e7["glass_to_pocket_clearance_xz"])
    flag("H3 lip overlap 1.2 +- 0.05", e7["lip_overlap_on_glass"]["passes"], e7["lip_overlap_on_glass"])
    flag("H3 window clear of the active area >= 8 / 4.5", e7["window_clear_of_active_area"]["passes"], e7["window_clear_of_active_area"])
    flag("H3 standoff pattern 72.0 x 48.5, screws line up", e7["standoffs"]["pattern"] == [72.0, 48.5] and e7["standoffs"]["screw_axis_offset_max"] <= 0.01
         and e7["inserts"]["screw_axis_offset_max"] <= 0.01, [e7["standoffs"]["pattern"], e7["standoffs"]["screw_axis_offset_max"]])
    flag("H3 nothing inside the display keep-out", e7["keepout"]["nothing_inside"], e7["keepout"]["overlap_mm3"])
    flag("H3 mounting plane coplanar", abs(e7["mounting_plane"]["standoff_ends_y"] - e7["mounting_plane"]["bezel_post_faces_y"]) < 1e-3 and
         abs(e7["mounting_plane"]["standoff_ends_y"] - e7["mounting_plane"]["bar_front_face_y"]) < 1e-3, e7["mounting_plane"])
    flag("H3 display / carrier contacts without overlap", max(e7["contacts_mm3"].values()) < 1e-3 and e7["display_inside_bezel_pocket"]["display_overlap_bezel"] < 1e-3,
         e7["contacts_mm3"])
    save()


# ---------------------------------------------------------------- 4. E8 magnets
def magnet_force(d=4.0, t=2.0, gap=0.2, Br=1.17, nr=36, na=64):
    """axial pull (N) between two coaxial, axially magnetised discs (charge model, numeric)"""
    mu0 = 4e-7 * math.pi
    M = Br / mu0
    Rm = d / 2 * 1e-3
    rr = (np.arange(nr) + 0.5) / nr * Rm
    aa = (np.arange(na) + 0.5) / na * 2 * math.pi
    r, a = np.meshgrid(rr, aa, indexing="ij")
    x, y = (r * np.cos(a)).ravel(), (r * np.sin(a)).ravel()
    dA = (r * (Rm / nr) * (2 * math.pi / na)).ravel()
    dx = x[:, None] - x[None, :]; dy = y[:, None] - y[None, :]
    rho2 = dx * dx + dy * dy
    W2 = dA[:, None] * dA[None, :]
    F = 0.0
    for z, sgn in ((gap, -1), (gap + t, +1), (gap + t, +1), (gap + 2 * t, -1)):
        zz = z * 1e-3
        F += sgn * (W2 * zz / (rho2 + zz * zz) ** 1.5).sum()
    return -mu0 / (4 * math.pi) * M * M * F      # > 0 = attraction


if want("4"):
    e8 = {}
    mb = sorted([(round(s.center().X, 3), round(s.center().Z, 3), s) for s in mg["bezel"].solids()], key=lambda v: v[:2])
    ms = sorted([(round(s.center().X, 3), round(s.center().Z, 3), s) for s in mg["shell"].solids()], key=lambda v: v[:2])
    e8["axes_world_xz"] = [[x, z] for x, z, _ in mb]
    e8["pair_misalignment_max"] = r4(max(math.hypot(a[0] - b[0], a[1] - b[1]) for a, b in zip(mb, ms)))
    yb1 = max(s.bounding_box().max.Y for _, _, s in mb); ys0 = min(s.bounding_box().min.Y for _, _, s in ms)
    e8["bezel_magnet_y"] = [r3(mb[0][2].bounding_box().min.Y), r3(yb1)]
    e8["shell_magnet_y"] = [r3(ys0), r3(ms[0][2].bounding_box().max.Y)]
    e8["face_gap"] = r3(ys0 - yb1)
    # walls: pocket plugs (D4.2 x 2.1) vs everything that is not resin of the same part
    bz_plugs = [HC.ycyl(HC.MAG_HOLE / 2, HC.Y_BB - HC.MAG_DEPTH, HC.Y_BB, x, z) for x, z in HC.magnet_positions(HZ)]
    sh_plugs = [HC.ycyl(HC.MAG_HOLE / 2, HC.Y_RAB, HC.Y_RAB + HC.MAG_DEPTH, x, z) for x, z in HC.magnet_positions(HZ)]
    bez_filled = bezel
    for p in bz_plugs:
        bez_filled = bez_filled + p
    air_b = (ybox(-36.0, HC.Y_BB - 1e-3)) - bez_filled          # everything that is not bezel resin, in front of its back face
    sh_filled = shell
    for p in sh_plugs:
        sh_filled = sh_filled + p
    air_s = (Pos(0, (HC.Y_RAB + 1e-3 - 15.0) / 2, ZC) * Box(130, abs(-15.0 - HC.Y_RAB - 1e-3), 100)) - sh_filled   # air behind the rabbet floor
    e8["bezel_pocket_min_wall"] = [r3(p.distance_to(air_b)) for p in bz_plugs]
    e8["shell_pocket_min_wall"] = [r3(p.distance_to(air_s)) for p in sh_plugs]
    e8["bezel_pocket_floor_to_front_surfaces"] = "included above (air = everything outside the resin in front of the back face)"
    e8["magnet_vs_part_overlap_mm3"] = dict(bezel=ivol(mg["bezel"], bezel, True), shell=ivol(mg["shell"], shell, True),
                                           bezel_mag_vs_shell=ivol(mg["bezel"], shell, True), shell_mag_vs_bezel=ivol(mg["shell"], bezel, True))
    e8["magnet_radial_clearance_in_pocket"] = (HC.MAG_HOLE - HC.MAG_D) / 2
    g = ys0 - yb1
    f_nom, f_c0, f_worst = magnet_force(gap=g), magnet_force(gap=0.1), magnet_force(gap=g + 0.15)
    e8["hold_force_N"] = dict(model="charge model, N35 Br 1.17 T (lower limit), D4 x 2 discs", per_pair_at_gap=r3(f_nom), gap=r3(g),
                              total_6_pairs=r3(6 * f_nom), per_pair_at_0p1=r3(f_c0), total_at_gap_plus_0p15=r3(6 * f_worst),
                              spec=">= 12 N", passes=bool(6 * f_nom >= 12.0))
    vol_mod = mv(bezel) * 1.2e-3 + 6 * 0.19 + 2.2        # resin 1.2 g/cm3 + magnets + bars/screws  (g)
    e8["front_module_mass_estimate_g"] = dict(bezel=r3(mv(bezel) * 1.2e-3), display_board="~46 (Waveshare bare board, not measured here)",
                                              bars_screws_magnets=r3(mv(ca["bars"]) * 1.2e-3 + 8 * 0.12 + 6 * 0.19))
    e8["passes"] = bool(min(e8["bezel_pocket_min_wall"] + e8["shell_pocket_min_wall"]) >= 1.0 and e8["pair_misalignment_max"] <= 0.1)
    R["4_E8_magnets"] = e8
    log("E8", e8)
    flag("H4 magnet walls >= 1.0, pairs aligned <= 0.1", e8["passes"], [min(e8["bezel_pocket_min_wall"] + e8["shell_pocket_min_wall"]), e8["pair_misalignment_max"]])
    flag("H4 magnet hold >= 12 N", e8["hold_force_N"]["passes"], e8["hold_force_N"]["total_6_pairs"])
    flag("H4 magnets vs parts overlap 0", max(e8["magnet_vs_part_overlap_mm3"].values()) < 1e-3, e8["magnet_vs_part_overlap_mm3"])
    save()

# ---------------------------------------------------------------- 5. E4 walls (ray-cast rule of round 5)
if want("5"):
    w = {}
    jobs = dict(ram_displeja=(bezel, 0.003, 0.03, 40000), hlava_skrupina=(shell, 0.01, 0.08, 60000),
                drziak_displeja=(ca["bars"], 0.005, 0.05, 15000), usi=(ears, 0.005, 0.05, 15000), led_kruzky=(rings, 0.005, 0.05, 8000))
    for nm, (s, tol, ang, n) in jobs.items():
        T = tris(s, tol, ang)
        P, N, th = rc.thickness(T, n)
        d = rc.summary(P, N, th, top=14, cell=4.0)
        d["n_lt_1p19"] = int((th < 1.19).sum()); d["tessellation"] = [tol, ang]; d["triangles"] = int(len(T))
        w[nm] = d
        log("walls", nm, {k: v for k, v in d.items() if k != "thin_spots"})
    w["method"] = ("round-5 rule (rc.py): area-weighted random surface samples, ray along -normal, wall = first hit with an opposite "
                   "normal (dot < -0.7) within 3 mm")
    R["5_E4_walls"] = w
    flag("H5 head walls >= 1.2 (ray cast)", all(v["n_lt_1p19"] == 0 for v in w.values() if isinstance(v, dict)),
         {k: [v["min"], v["n_lt_1p19"]] for k, v in w.items() if isinstance(v, dict) and v["n_lt_1p19"]})
    save()

# ---------------------------------------------------------------- 6. interference + clearances inside the head
if want("6"):
    names = list(NAMED)
    ov, pairs = {}, 0
    for i in range(len(names)):
        for j in range(i + 1, len(names)):
            a, b = NAMED[names[i]], NAMED[names[j]]
            A, Bb = a.bounding_box(), b.bounding_box()
            if any(tuple(A.min)[k] > tuple(Bb.max)[k] + 0.01 or tuple(Bb.min)[k] > tuple(A.max)[k] + 0.01 for k in range(3)):
                continue
            v = ivol(a, b, bool({names[i], names[j]} & LOFTY)); pairs += 1
            if v > 1e-4:
                ov[f"{names[i]} x {names[j]}"] = v
    pv = ivol(pads, bezel, True) + sum(ivol(pads, NAMED[k]) for k in ("drziak_displeja", "skrutky_carrier", "displej_pcb", "displej_header"))
    cl = dict(
        spigot_to_rabbet_radial=r3((bezel & ybox(HC.Y_SEAM + 0.05, HC.Y_BB)).distance_to(shell & ybox(HC.Y_SEAM + 0.05, HC.Y_RAB - 0.05))),
        bezel_back_face_to_rabbet_floor=r3(HC.Y_RAB - HC.Y_BB),
        flange_to_rim_contact=r3((bezel & ybox(-27.0, HC.Y_SEAM)).distance_to(shell)),
        posts_to_shell=r3((bezel & ybox(HC.Y_BB + 0.2, -10)).distance_to(shell)),
        bars_to_shell=r3(ca["bars"].distance_to(shell)),
        bar_screws_to_shell=r3(ca["screws"].distance_to(shell)),
        bar_screws_to_cross_screws=r3(ca["screws"].distance_to(xscr)),
        bars_to_shell_magnets=r3(ca["bars"].distance_to(mg["shell"])),
        display_pcb_lcd_to_shell=r3(min(dp[k].distance_to(shell) for k in ("lcd", "pcb"))),
        header_top_to_pad_front_face_y=r3(-HN.PAD[2] - dp["header"].bounding_box().max.Y),
        led_boards_to_shell=r3(ledb.distance_to(shell)), led_boards_to_ears=r3(ledb.distance_to(ears)),
        ears_to_display=r3(min(ears.distance_to(dp[k]) for k in ("lcd", "pcb"))))
    R["6_interference_clearance"] = dict(pairs_tested=pairs, overlaps_above_0p0001_mm3=ov, zero_interference=bool(not ov),
                                         pads_vs_front_module_mm3=round(pv, 4), clearances=cl)
    log("interference", ov, cl)
    flag("H6 zero interference inside the head", not ov and pv < 1e-3, ov)
    save()

# ---------------------------------------------------------------- 7. front module passes the shell opening
if want("7"):
    rear = [bezel & ybox(-27.5, 0.0)] + [dp[k] for k in ("lcd", "pcb", "standoffs", "header", "usbc", "small")] + \
           [ca["bars"], ca["screws"], ca["inserts"], mg["bezel"]]
    rear_s = [s for r_ in rear for s in r_.solids()]
    obst = shell & ybox(-27.0, -10.0)
    steps = [0.1, 0.25, 0.5, 0.75, 1.0, 1.5, 2.0, 2.5, 3.0, 3.5, 4.0, 4.5, 5.0, 5.5, 6.0, 6.5, 7.0, 8.0, 9.0, 10.0, 11.0, 12.0]
    worst, rows = 0.0, {}
    for dy in steps:
        v = 0.0
        for s in rear_s:
            b = s.bounding_box()
            if b.max.Y - dy < -26.2:                            # already completely in front of the shell rim
                continue
            v += ivol(mv_move(s, -dy), obst, True) + ivol(mv_move(s, -dy), mg["shell"])
        rows[str(dy)] = round(v, 4); worst = max(worst, v)
        log("sweep", dy, round(v, 4))
    # lateral clearance of everything behind the bezel back face to the shell (assembled) and during the pull
    rear_in = [s for s in rear_s if s.bounding_box().max.Y > HC.Y_BB + 0.2]
    posts_bars = Compound([bezel & ybox(HC.Y_BB + 0.2, 0.0)] + list(ca["bars"].solids()) + list(ca["screws"].solids()))
    cl = {}
    for dy in (0.0, 2.0, 3.5, 5.0, 6.5, 8.0):
        cl[str(dy)] = r3(min(mv_move(posts_bars, -dy).distance_to(obst), mv_move(posts_bars, -dy).distance_to(mg["shell"]),
                             min(mv_move(dp[k], -dy).distance_to(obst) for k in ("lcd", "pcb"))))
    R["7_module_through_opening"] = dict(
        method="every solid of the front module that reaches behind y=-27.5 (bezel rear with spigot + posts, LCD, PCB, standoffs, header, "
               "USB-C, components, bars, screws, inserts, bezel magnets) is translated along -Y in 22 steps (0.1..12 mm) and intersected "
               "with the shell (y -27..-10, incl. magnet bosses and pads) and the shell magnets",
        overlap_mm3_per_step=rows, worst_overlap_mm3=round(worst, 4), passes=bool(worst < 1e-3),
        min_clearance_posts_bars_display_to_shell_during_pull=cl,
        rearmost_module_point_y=r3(max(s.bounding_box().max.Y for s in rear_s)), free_after_pull_mm=r3(max(s.bounding_box().max.Y for s in rear_s) + 26.0))
    log("module sweep", worst, cl)
    flag("H7 front module passes the shell opening", worst < 1e-3, worst)
    save()

# ---------------------------------------------------------------- 8. service tool path to the 4 cross screws
if want("8"):
    tp = {}
    yh = -HN.PAD[2] - 1.3                                       # top of the ISO 7380-1 head (k 1.3)
    tools = {f"x{sx * x:+.1f}": HC.ycyl(2.0, -70.0, yh, sx * x, HN.ZS) for sx in (-1, 1) for x in HN.SCR_X}
    for k, t in tools.items():
        tp[k] = dict(overlap_shell_mm3=ivol(t, shell, True), overlap_shell_magnets=ivol(t, mg["shell"]),
                     min_distance_shell=r3(t.distance_to(shell)), min_distance_shell_magnets=r3(t.distance_to(mg["shell"])),
                     overlap_other_cross_screws=round(ivol(t, xscr) , 4))
    hex_ = {f"x{sx * x:+.1f}": HC.ycyl(0.75, -70.0, yh + 0.9, sx * x, HN.ZS) for sx in (-1, 1) for x in HN.SCR_X}
    R["8_tool_path_cross_screws"] = dict(
        tool="D4 shank along Y from the front opening (bezel module removed) to the head top y=%.1f, axis z=%.1f, x = +-18.3 / +-22.3" % (yh, HN.ZS),
        per_screw=tp, passes=bool(all(v["overlap_shell_mm3"] == 0 and v["overlap_shell_magnets"] == 0 for v in tp.values())),
        note="overlap_other_cross_screws = the D4 shank over the neighbouring head (axes 4.0 apart, dk 3.8): the shank stops at the head "
             "top plane, value must be 0",
        opening_bottom_edge_clearance=r3(min(v["min_distance_shell"] for v in tp.values())))
    log("tool", tp)
    flag("H8 D4 tool path free", R["8_tool_path_cross_screws"]["passes"], {k: v["overlap_shell_mm3"] for k, v in tp.items()})
    save()

# ---------------------------------------------------------------- 9. E2f: closed head floor (no servo lead in the head)
if want("9"):
    # the servo lead no longer enters the head: no floor slot, no vault, no cable bridge.  Vertical rays from below on a
    # 0.5 grid between the pads must all hit the floor (exterior below local z 3) and pass through solid floor
    Tf = tris(shell & (Pos(0, 0, HZ + 2.5) * Box(32, 44, 11)), 0.01, 0.08).astype(np.float64)
    G_ = [(x, y) for x in np.arange(-13.5, 13.51, 0.5) for y in np.arange(-16.0, 16.01, 0.5)]
    O = np.array([[x, y, HZ - 3.0] for x, y in G_]); Dv = np.tile([0.0, 0.0, 1.0], (len(O), 1))
    t1 = np.concatenate([rc.ray_hits(O[i:i + 64], Dv[i:i + 64], Tf)[0] for i in range(0, len(O), 64)])
    O2 = O + Dv * (np.where(np.isfinite(t1), t1, 0.0)[:, None] + 1e-3)
    t2 = np.concatenate([rc.ray_hits(O2[i:i + 64], Dv[i:i + 64], Tf)[0] for i in range(0, len(O), 64)])
    z1 = O[:, 2] + t1
    miss = int((~np.isfinite(t1)).sum() + (z1 > HZ + 3.0).sum())
    fth = t2[np.isfinite(t1) & np.isfinite(t2)]
    R["9_floor_closed"] = dict(
        adds=len(adds), adds_expected="2 pads (E2f: no vault)", rays=len(O), grid="x -13.5..13.5, y -16..16, step 0.5 (between the pads)",
        rays_not_hitting_the_floor=miss, floor_exterior_local_z=[r3(z1[np.isfinite(t1)].min() - HZ), r3(z1[np.isfinite(t1)].max() - HZ)],
        floor_thickness_along_z=[r3(fth.min()), r3(fth.max())] if len(fth) else None,
        passes=bool(miss == 0 and len(fth) == len(O) and len(adds) == 2))
    log("floor", R["9_floor_closed"])
    flag("H9 head floor closed between the pads (E2f: no lead slot / vault / bridge)", R["9_floor_closed"]["passes"],
         [miss, len(adds)])
    save()

# ---------------------------------------------------------------- 10. ear pods
if want("10"):
    e = {}
    pod = [s for s in ears.solids() if s.center().X > 0][0]
    ring = [s for s in rings.solids() if s.center().X > 0][0]
    xa = pod.bounding_box().max.X
    e["pod_bbox"] = bbx(pod); e["ring_bbox"] = bbx(ring)
    e["apex_proud_of_side_x55"] = r3(xa - HC.W / 2)
    e["cylinder_dome_edge_proud"] = r3(HC.EAR_X1 - HC.W / 2)
    # ring front face vs the dome sphere: sample ring vertices in the front zone
    V = np.array([[p.X, p.Y, p.Z] for p in ring.tessellate(0.002, 0.02)[0]])
    c = np.array([HC._dome_xc(), HC.EAR_Y, ZC])
    rad = np.hypot(V[:, 1] - HC.EAR_Y, V[:, 2] - ZC)
    m = (rad > HC.RING_R0 + HC.SEAM_CH + 0.01) & (rad < HC.RING_R1 - HC.SEAM_CH - 0.01) & (V[:, 0] > HC._groove_floor_x() + 1.0)
    dev = np.linalg.norm(V[m] - c, axis=1) - HC.DOME_R
    Vp = np.array([[p.X, p.Y, p.Z] for p in pod.tessellate(0.002, 0.02)[0]])
    radp = np.hypot(Vp[:, 1] - HC.EAR_Y, Vp[:, 2] - ZC)
    mp = (radp < HC.RING_R0 - HC.GROOVE_CL - HC.SEAM_CH - 0.01) & (Vp[:, 0] > HC._groove_floor_x() + 1.0)
    devp = np.linalg.norm(Vp[mp] - c, axis=1) - HC.DOME_R
    e["ring_front_face_vs_dome_sphere"] = dict(n=int(m.sum()), min=r4(dev.min()), max=r4(dev.max()), spec="0 +- 0.05, never proud")
    e["pod_centre_disc_vs_dome_sphere"] = dict(n=int(mp.sum()), min=r4(devp.min()), max=r4(devp.max()))
    e["ring_vs_pod_overlap_mm3"] = ivol(ring, pod); e["ring_to_pod_min_distance"] = r3(ring.distance_to(pod))
    e["ring_radial_seam"] = HC.GROOVE_CL
    e["pod_vs_shell_overlap_mm3"] = ivol(pod, shell, True)
    clipbox = Pos(HC.EAR_X0 + 0.3 + 10, HC.EAR_Y, ZC) * Box(20, 60, 60)
    e["pod_to_shell_radial_seam"] = r3((pod & clipbox).distance_to(shell))
    e["pod_seated_on_lip_distance"] = r3(pod.distance_to(shell))
    # shell hole edge round: surface normal continuity is by OCC fillet; report the fillet radius used and where the hole wall starts
    e["shell_hole_edge_fillet_R"] = HC.SHELL_NOTES.get("ear_hole_fillet")
    hole_r = first_hit(shell, (HC.W / 2 - 1.5, HC.EAR_Y, ZC), (0, 0, 1))
    e["shell_hole_radius_at_x53p5"] = r3(hole_r)
    side = [first_hit(shell, (80.0, HC.EAR_Y + dy_, ZC + 13.15 + dr), (-1, 0, 0)) for dy_, dr in ((0.0, 0.05), (0.0, 0.4), (0.0, 0.9), (0.0, 2.0))]
    e["shell_surface_x_just_above_hole_edge(dr=0.05,0.4,0.9,2.0)"] = [r3(80.0 - s_) for s_ in side]
    e["pod_straight_cylinder_ends_at_x"] = r3(HC._dome_xc() + math.sqrt((HC.DOME_R - HC.POD_FIL) ** 2 - (HC.EAR_R - HC.POD_FIL) ** 2))
    e["led_board_vs_all_mm3"] = dict(shell=ivol(ledb, shell, True), ears=ivol(ledb, ears))
    R["10_ear_pods"] = e
    log("ears", e)
    flag("H10 ear ring flush with the dome (0 +- 0.05)", abs(e["ring_front_face_vs_dome_sphere"]["min"]) <= 0.05 and abs(e["ring_front_face_vs_dome_sphere"]["max"]) <= 0.05,
         e["ring_front_face_vs_dome_sphere"])
    flag("H10 ear pods: no overlap, seam 0.15", e["ring_vs_pod_overlap_mm3"] < 1e-3 and e["pod_vs_shell_overlap_mm3"] < 1e-3 and
         abs(e["pod_to_shell_radial_seam"] - 0.15) < 0.01, [e["ring_vs_pod_overlap_mm3"], e["pod_vs_shell_overlap_mm3"], e["pod_to_shell_radial_seam"]])
    flag("H10 shell ear-hole edge round R0.8", e["shell_hole_edge_fillet_R"] == 0.8, e["shell_hole_edge_fillet_R"])
    save()

# ---------------------------------------------------------------- 11. what is visible through the window
if want("11"):
    groups = [("shell", shell), ("bezel", bezel), ("glass", dp["glass"]), ("gasket", gasket), ("eyes", eyes),
              ("display_rest", Compound([dp[k] for k in ("lcd", "pcb", "standoffs", "header", "usbc", "small")])),
              ("bars", ca["bars"]), ("fasteners", Compound([ca["screws"], ca["inserts"], xscr])), ("magnets", Compound([mg["bezel"], mg["shell"]])),
              ("ears", ears), ("rings", rings), ("led_boards", ledb)]
    Ts, ids = [], []
    for i, (nm, s) in enumerate(groups):
        t_ = tris(s, 0.02, 0.15)
        Ts.append(t_); ids.append(np.full(len(t_), i))
    T, ids = np.concatenate(Ts).astype(np.float64), np.concatenate(ids)
    names = [g[0] for g in groups]
    allowed = {"bezel", "glass", "gasket", "eyes"}
    box_ = (-HC.WIN_W / 2, HC.WIN_W / 2, HC.YF, HC.YF, ZC - HC.WIN_H / 2, ZC + HC.WIN_H / 2)
    px = 0.2
    res, bad = {}, 0
    for az in (-70, -50, -30, -15, 0, 15, 30, 50, 70):
        for el in (-50, -25, 0, 25, 50):
            img = vis_zbuf.zbuffer(T, ids, az, el, box_, px)
            # keep only the pixels whose ray really passes through the window opening (rounded rectangle at y=-33)
            u, d, v = vis_zbuf.basis(az, el)
            c = np.array([[x, y, z] for x in box_[:2] for y in box_[2:4] for z in box_[4:]])
            U0, V0 = (c @ u).min(), (c @ v).min()
            ny, nx = img.shape
            UU, VV = np.meshgrid(U0 + (np.arange(nx) + 0.5) * px, V0 + (np.arange(ny) + 0.5) * px)
            tt = (HC.YF - UU * u[1] - VV * v[1]) / d[1]
            X = UU * u[0] + VV * v[0] + tt * d[0]
            Z = UU * u[2] + VV * v[2] + tt * d[2] - ZC
            qx, qz = np.abs(X) - (HC.WIN_W / 2 - HC.WIN_R), np.abs(Z) - (HC.WIN_H / 2 - HC.WIN_R)
            sd = np.hypot(np.maximum(qx, 0), np.maximum(qz, 0)) + np.minimum(np.maximum(qx, qz), 0) - HC.WIN_R
            mask = sd < 0
            cnt = {names[i]: round(float(((img == i) & mask).sum()) * px * px, 1) for i in np.unique(img[mask]) if i >= 0}
            cnt["window_px_area"] = round(float(mask.sum()) * px * px, 1)
            nb = sum(val for k, val in cnt.items() if k not in allowed and k != "window_px_area")
            bad = max(bad, nb)
            res[f"az{az}_el{el}"] = cnt
    R["11_visible_through_window"] = dict(
        method="orthographic z-buffer (0.2 mm/px) from 45 directions (az +-70, el +-50); only the pixels whose ray passes through "
               "the window opening (90 x 58.6 R4.8 at y=-33) are counted; area (mm2) of the first-hit part per view",
        allowed=sorted(allowed), views=res, worst_area_of_other_parts_mm2=round(bad, 2), passes=bool(bad == 0))
    log("visibility worst", bad, res["az0_el0"], res["az70_el50"])
    flag("H11 nothing but bezel / glass / gasket / eyes visible through the window", bad == 0, bad)
    save()

# ---------------------------------------------------------------- 12. design numbers
if want("12"):
    R["12_design_numbers"] = dict(
        exterior=dict(W=HC.W, H=HC.H, D=HC.D - HC.BACK_CUT, N=HC.N, front_round="9 deep x 7.5 inset, equal in x and z",
                      flat_front_semi_axes=[r3(v) for v in HC.ab(HC.YF)], section_at_seam=[r3(v) for v in HC.ab(HC.Y_SEAM)],
                      back_flat_semi_axes=[r3(v) for v in HC.ab(HC.YB - HC.BACK_CUT)]),
        stack_y_local=dict(bezel_front=HC.YF, lip_back=HC.Y_LIP, glass_front=HC.Y_G0, glass_back=HC.Y_G0 + HC.GLASS_T,
                           pcb_back=HC.Y_PCB, mounting_plane=HC.Y_MP, header_top=HC.Y_HDR, bar_back=HC.Y_MP + HC.BAR_T,
                           bar_screw_head_top=HC.Y_MP + HC.BAR_T + HC.SCR_K, seam=HC.Y_SEAM, bezel_back_face=HC.Y_BB, rabbet_floor=HC.Y_RAB),
        bezel=dict(window=[HC.WIN_W, HC.WIN_H, HC.WIN_R], window_edge_R=HC.WIN_FIL, lip=HC.LIP_T, pocket=[HC.POCK_W, HC.POCK_H, HC.POCK_R],
                   posts=dict(x=HC.POST_X, z_rel=HC.POST_Z, d=HC.POST_D, insert_hole=[HC.INS_D, HC.INS_L])),
        carrier=dict(bar_thickness=HC.BAR_T, beam_z_rel=[HC.BAR_Z0, HC.BAR_Z1], beam_half_length=HC.BAR_XE,
                     screws="4 x M2x5 (standoffs) + 4 x M2x6 (inserts), ISO 7380-1 dk 3.8 k 1.3"),
        magnets=dict(size=[HC.MAG_D, HC.MAG_T], pocket=[HC.MAG_HOLE, HC.MAG_DEPTH], positions_local_xz=[[x, z] for x, z, _, _ in HC._mag_pts()]),
        ears=dict(centre=[HC.EAR_Y, HC.H / 2], pod_r=HC.EAR_R, inner_face_x=HC.EAR_X0, apex_x=r3(HC._dome_xc() + HC.DOME_R),
                  hole_r=HC.EAR_R + HC.EAR_CL, groove_floor_x=r3(HC._groove_floor_x()), ring=[HC.RING_R0, HC.RING_R1]),
        servo_lead="E2f: none in the head (servo wired in the torso)")
    save()
log("done")
save()
