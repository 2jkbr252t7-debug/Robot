"""NOVA mini B, revision E2f - INTEGRATION checks on the integrated model (build.py + live head_common)
-> checks_e2_integr.json.   run: /opt/venv/cad/bin/python checks_e2_integr.py [section ...]   (no argument = all)
E2f (user option 1): the servo lead goes DOWN into the torso (modified MG90S, 3 x AWG30 in a groove of the front neck
half, registry kabel[2], group N) - no servo cable in the head any more: no floor slot, no vault, no cable bridge,
no foam plug in the knuckle.  Their checks were removed; E9 has NO lead exception any more.
Sections:
  REG  registry against E2_spec D (names, groups, solid counts, validity, volumes)
  X    interfaces neither engineer could see: pads / tenons on the new floor, head wires vs everything in the head,
       D4 tool path to the 4 cross screws, magnet bosses / carrier bars / posts vs pads, tenons and cables, head
       exterior vs collar / torso at rest and over the tilt sweep
  T    tilt allowed vs lift (firmware table) for the new head W110 x H79
  V    E9 visibility ray-cast (orthographic z-buffer): whole robot 30 views x 4 poses + hinge window 0.05 mm/px
  S    exported STL files: names = registry, every part mesh closed
  R5   round-5 checks that are still valid (containment, servo hold, neck clamp, pin grip, collar ring, fits)
Every number is computed (booleans, OCC distances, ray casts)."""
import sys, json, time, math, os, glob, warnings
warnings.filterwarnings("ignore")
sys.path.insert(0, "/tmp/claude-0/gapwf/fin/B")
import numpy as np
import build as B
import head_common as HC
import rc
import vis_zbuf as VZ
from build123d import Pos, Box, Compound, Location, Axis, GeomType, fillet

t0 = time.time()
OUT = "/tmp/claude-0/gapwf/fin/B/checks_e2_integr.json"
ALL = ["REG", "X", "T", "V", "S", "R5"]
SEC = set(sys.argv[1:]) or set(ALL)
try:
    R = json.load(open(OUT)) if sys.argv[1:] else {}
except Exception:
    R = {}
R.update(units="mm / mm3", pose="extended (HZ 27, axis z 16.5) unless stated; rest = lift -20; neck halves CLOSED",
         model="INTEGRATED: build.py + /tmp/claude-0/gapwf/fin/common/head_common.py")
def _sec_of(name):
    t = name.split(" ")[0]
    return "X" if t.startswith("X") else "V" if t == "E9" else t


FAIL = [f for f in R.get("summary", {}).get("failed", []) if _sec_of(f) not in SEC] if sys.argv[1:] else []
HZ, AXZ = B.HZ, B.AXZ
ZC = HZ + HC.H / 2
mv = HC.mesh_volume


def r3(x):
    return None if x is None else round(float(x), 3)


def log(*a):
    print(f"[{time.time() - t0:6.1f}]", *a, flush=True)


def save():
    R["summary"] = dict(failed=FAIL, time_s=round(time.time() - t0, 1))
    json.dump(R, open(OUT, "w"), indent=1, ensure_ascii=False)


def ok(name, cond, val):
    if not cond:
        FAIL.append(f"{name}: {val}")
    return dict(value=val, passed=bool(cond))


def ivol(a, b, mesh=False):
    x = a & b
    if x is None or not x.solids():
        return 0.0
    return round(float(mv(x) if mesh else sum(s.volume for s in x.solids())), 4)


def bb_overlap(a, b, m=0.05):
    A, Bb = a.bounding_box(), b.bounding_box()
    a0, a1, b0, b1 = [tuple(v) for v in (A.min, A.max, Bb.min, Bb.max)]
    return all(a0[i] - m <= b1[i] and b0[i] - m <= a1[i] for i in range(3))


def bx(x0, x1, y0, y1, z0, z1):
    return Pos((x0 + x1) / 2, (y0 + y1) / 2, (z0 + z1) / 2) * Box(abs(x1 - x0), abs(y1 - y0), abs(z1 - z0))


def one(x):
    return x.solids()[0] if len(x.solids()) == 1 else x


def path_len(pts, R_):
    """length of a polyline whose corners are filleted with radius R_"""
    P_ = [np.array(p, float) for p in pts]
    L = sum(np.linalg.norm(P_[i + 1] - P_[i]) for i in range(len(P_) - 1))
    for i in range(1, len(P_) - 1):
        u, v = P_[i - 1] - P_[i], P_[i + 1] - P_[i]
        th = math.acos(np.clip(u @ v / np.linalg.norm(u) / np.linalg.norm(v), -1, 1))     # interior angle
        L -= 2 * R_ / math.tan(th / 2) - R_ * (math.pi - th)
    return float(L)


P = B.build_all()
log("built")
LOFTY = {"hlava_skrupina", "ram_displeja"}
shell, bezel = P["hlava_skrupina"][0][0], P["ram_displeja"][0][0]
DPN = ("glass", "lcd", "pcb", "standoffs", "header", "usbc", "small")
dp = {k: P["displej"][i][0] for i, k in enumerate(DPN)}
gasket, bars = P["pena_displeja"][0][0], P["drziak_displeja"][0][0]
mag_b, mag_s = [s for s, g in P["magnety"]]
ears, rings, ledb, eyes = P["usi"][0][0], P["led_kruzky"][0][0], P["led_dosky"][0][0], P["oci_len_vizualizacia"][0][0]
nf, nb = P["krk_predna_polovica"][0][0], P["krk_zadna_polovica"][0][0]
cap, lug, horn, ptfe = P["usko_kryt"][0][0], P["usko_lozisko"][0][0], P["paka"][0][0], P["klzny_kruzok"][0][0]
servo, foam = P["servo_MG90S"][0][0], P["pena_serva"][0][0]                     # E2f: no knuckle-slot plug
bo, bi = [s for s, g in P["loziska_MR85"]]
pin, dowels = [s for s, g in P["capy"]]
nscr, hscr, xscr, cscr, cins = [s for s, g in P["skrutky"]]
cab_n, cab_h, swire = [s for s, g in P["kabel"]]                                 # E2f: servo wires = kabel[2] (N)
disc, ring = P["golier_kotuc"][0][0], P["golier_prstenec"][0][0]
neck = nf + nb
keepout = HC.display_parts(HZ)["keepout"]

# ============================================================================================================== REG
EXPECT = dict(hlava_skrupina="H", ram_displeja="H", displej="HHHHHHH", pena_displeja="H", drziak_displeja="H", magnety="HH",
              usi="H", led_kruzky="H", led_dosky="H", oci_len_vizualizacia="H", usko_kryt="H", usko_lozisko="H", paka="H",
              klzny_kruzok="H", krk_predna_polovica="N", krk_zadna_polovica="N", servo_MG90S="N", pena_serva="N", capy="NN",
              skrutky="NHHHH", kabel="NHN", loziska_MR85="HN", golier_kotuc="T", golier_prstenec="T")
PRINTED = dict(hlava_skrupina=1, ram_displeja=1, drziak_displeja=2, usi=2, led_kruzky=2, krk_predna_polovica=1,
               krk_zadna_polovica=1, usko_kryt=1, usko_lozisko=1, golier_kotuc=1, golier_prstenec=1)
ITEMS = dict(displej=list(DPN), magnety=["bezel side (6)", "shell side (6)"], capy=["hollow pin", "2 dowels"],
             pena_serva=["2 Y strips + 2 X pads in the servo pocket"],
             skrutky=["neck: 4 screws + 4 inserts", "horn screw", "4 cross screws M2x8", "carrier: 4 x M2x5 + 4 x M2x6",
                      "carrier: 4 inserts"], kabel=["head wires, static part", "head wires, rotating part + loop",
                                                   "servo wires (3 x AWG30) down into the torso"],
             loziska_MR85=["outer ring", "inner ring"])
if "REG" in SEC:
    reg, bad = {}, []
    for k, lst in P.items():
        rows = []
        for i, (s, g) in enumerate(lst):
            vm, vo = mv(s), sum(x.volume for x in s.solids())
            rows.append(dict(item=ITEMS.get(k, [k])[i] if i < len(ITEMS.get(k, [k])) else str(i), group=g, solids=len(s.solids()),
                             valid=bool(s.is_valid), mesh_volume=r3(vm), occ_volume=r3(vo)))
            if not s.is_valid or vm <= 0:
                bad.append(f"{k}#{i} invalid or volume <= 0")
            if k not in LOFTY and vo > 1 and abs(vm - vo) / vo > 0.01:
                bad.append(f"{k}#{i} mesh / OCC volume differ: {r3(vm)} / {r3(vo)}")
        reg[k] = rows
    names_ok = set(P) == set(EXPECT)
    groups = {k: "".join(g for s, g in lst) for k, lst in P.items()}
    grp_bad = {k: [groups.get(k), EXPECT[k]] for k in EXPECT if groups.get(k) != EXPECT[k]}
    prn = {k: sum(len(s.solids()) for s, g in P[k]) for k in PRINTED}
    o, i_ = HC.head_outer(HZ), HC.inner_skin(HZ)
    R["REG_registry"] = dict(
        parts=reg,
        names=ok("REG names = E2_spec D", names_ok, dict(missing=sorted(set(EXPECT) - set(P)), extra=sorted(set(P) - set(EXPECT)))),
        groups=ok("REG groups", not grp_bad, grp_bad),
        removed_names_absent=ok("REG removed names (sklo)", "sklo" not in P, [k for k in ("sklo",) if k in P]),
        e2f_servo_wires=ok("REG E2f: kabel = head wires N / H + servo wires N, pena_serva 1 item",
                           groups.get("kabel") == "NHN" and len(P["pena_serva"]) == 1, [groups.get("kabel"), len(P["pena_serva"])]),
        all_valid=ok("REG validity / volumes", not bad, bad),
        printed_parts_solid_count=ok("REG printed parts solid count", prn == PRINTED, prn),
        klzny_kruzok_group="H (bonded in the cap groove)",
        reference_volumes=dict(head_outer_mesh=round(mv(o), 1), head_outer_occ=round(o.volume, 1), cavity_mesh=round(mv(i_), 1),
                               cavity_occ=round(i_.volume, 1),
                               note="OCC GProp is off by up to 3 % on the periodic lofts -> mesh volumes are the reference"),
        head_module=HC.__file__, shell_notes=HC.SHELL_NOTES)
    log("REG", {k: [(r["group"], r["solids"]) for r in v] for k, v in reg.items()}, "bad:", bad, grp_bad)
    save()

# ================================================================================================================ X
if "X" in SEC:
    X = {}
    adds, cuts = B.head_pads_and_cuts()
    pads = {-1: adds[0], 1: adds[1]}
    X["e2f_adds"] = ok("X E2f: head adds = 2 pads only (no vault)", len(adds) == 2, len(adds))
    padc = Compound([pads[sx] - B.tenon_box(sx, 0.1, HZ - 1.5, B.TEN[4] + 0.5) for sx in (-1, 1)])   # pads with the tenon slots
    bosses = Compound([HC._w(b_, HZ) for b_ in HC._mag_bosses_l()])
    # ---------------------------------------------------------------- X1 pads + tenons on the new floor
    x1 = {}
    for sx, nm, part in ((-1, "usko_kryt", cap), (1, "usko_lozisko", lug)):
        ten = B.tenon_box(sx)
        slot = B.tenon_box(sx, 0.1, HZ - 1.5, B.TEN[4] + 0.5)
        env = B.lug_blank(sx)
        slab = bx(-40, 40, -20, 20, HZ - 0.40, HZ - 0.30)
        unc = (slot & slab) - env
        unc_a = sum(s.volume for s in unc.solids()) / 0.1 if unc is not None and unc.solids() else 0.0
        holes = B.groove_holes(sx) + [B.ycyl(1.1, -B.PAD[2] - 0.6, -B.TEN[2] + 1.1, sx * B.SCR_X[0], B.ZS),
                                      B.ycyl(1.1, -B.PAD[2] - 0.6, -(B.TEN[2] - B.TEN_R[1]), sx * B.SCR_X[1], B.ZS)]
        outside = bx(sx * 5, sx * 40, -30, 30, HZ - 6, HZ + 20) - HC.head_outer(HZ)
        pv = mv(pads[sx])
        pb = pads[sx].bounding_box()
        x1[nm] = dict(
            part_vs_shell_mm3=ivol(part, shell, True), part_to_shell_min_distance=r3(part.distance_to(shell)),
            tenon_to_floor_slot_wall=r3(ten.distance_to(shell)),
            web_top_to_head_floor=r3((env - B.tenon_box(sx, 0.05, HZ - 3, HZ + 10)).distance_to(HC.head_outer(HZ))),
            floor_slot_mouth_not_covered_by_web_mm2=r3(unc_a),
            floor_slot_mouth_note="0.1 strips along |y| 8.0..8.1 only (black tenon behind a black web)",
            pad_bbox=[r3(pb.min.X), r3(pb.max.X), r3(pb.min.Y), r3(pb.max.Y), r3(pb.min.Z), r3(pb.max.Z)],
            pad_volume_mm3=r3(pv), pad_inside_head_exterior_mm3_outside=r3(max(0.0, pv - ivol(pads[sx], HC.head_outer(HZ), True))),
            cross_screw_holes_to_exterior=r3(min(h.distance_to(outside) for h in holes)),
            pad_to_magnet_bosses=r3(pads[sx].distance_to(bosses)), pad_to_bezel=r3(pads[sx].distance_to(bezel)),
            pad_to_bars=r3(pads[sx].distance_to(bars)), pad_to_display_header=r3(pads[sx].distance_to(dp["header"])),
            pad_vs_front_module_mm3=round(ivol(pads[sx], bezel, True) + ivol(pads[sx], bars) + ivol(pads[sx], cscr) +
                                          sum(ivol(pads[sx], dp[k]) for k in DPN), 4))
        ok(f"X1 {nm} vs shell overlap 0", x1[nm]["part_vs_shell_mm3"] < 1e-3, x1[nm]["part_vs_shell_mm3"])
        ok(f"X1 {nm} tenon in slot 0.1", abs(x1[nm]["tenon_to_floor_slot_wall"] - 0.1) < 0.005, x1[nm]["tenon_to_floor_slot_wall"])
        ok(f"X1 {nm} cross-screw holes never reach the exterior (>= 1.2)", x1[nm]["cross_screw_holes_to_exterior"] >= 1.2,
           x1[nm]["cross_screw_holes_to_exterior"])
        ok(f"X1 {nm} pad vs front module 0", x1[nm]["pad_vs_front_module_mm3"] < 1e-3, x1[nm]["pad_vs_front_module_mm3"])
    Tm = B.tris(shell, 0.01, 0.08)
    Pp, Nn, th = rc.thickness(Tm, 20000, region=(-32, 32, -19, 19, HZ - 1.5, HZ + 12))
    x1["shell_hinge_zone_raycast"] = rc.summary(Pp, Nn, th, top=10)
    x1["shell_hinge_zone_raycast"]["n_lt_1p19"] = int((th < 1.19).sum())
    x1["shell_hinge_zone_raycast"]["region"] = "|x| <= 32, |y| <= 19, z HZ-1.5..HZ+12 (pads, tenon slots, screw holes; E2f: closed floor), 20000 samples"
    ok("X1 shell walls in the hinge zone >= 1.2 (ray cast)", x1["shell_hinge_zone_raycast"]["n_lt_1p19"] == 0,
       [x1["shell_hinge_zone_raycast"]["min"], x1["shell_hinge_zone_raycast"]["n_lt_1p19"]])
    # E2f: the head floor between the pads is closed (no servo-lead slot): every vertical ray from below hits the floor
    Tf = B.tris(shell & bx(-16, 16, -22, 22, HZ - 3, HZ + 8), 0.01, 0.08).astype(np.float64)
    G_ = [(x, y) for x in np.arange(-13.5, 13.51, 0.5) for y in np.arange(-16.0, 16.01, 0.5)]
    O = np.array([[x, y, HZ - 3.0] for x, y in G_]); Dv = np.tile([0.0, 0.0, 1.0], (len(O), 1))
    t1 = np.concatenate([rc.ray_hits(O[i:i + 64], Dv[i:i + 64], Tf)[0] for i in range(0, len(O), 64)])
    O2 = O + Dv * (np.where(np.isfinite(t1), t1, 0.0)[:, None] + 1e-3)
    t2 = np.concatenate([rc.ray_hits(O2[i:i + 64], Dv[i:i + 64], Tf)[0] for i in range(0, len(O), 64)])
    z1 = O[:, 2] + t1
    miss = int((~np.isfinite(t1)).sum() + (z1 > HZ + 3.0).sum())
    fth = t2[np.isfinite(t1) & np.isfinite(t2)]
    x1["head_floor_closed_between_pads"] = dict(
        rays=len(O), grid="x -13.5..13.5, y -16..16, step 0.5, from z HZ-3 upward", rays_not_hitting_the_floor=miss,
        floor_exterior_z_local=[r3(z1[np.isfinite(t1)].min() - HZ), r3(z1[np.isfinite(t1)].max() - HZ)],
        floor_thickness_along_z=[r3(fth.min()), r3(fth.max())] if len(fth) else None,
        closed=ok("X1 E2f head floor closed between the pads (no servo-lead slot)", miss == 0 and len(fth) == len(O), miss))
    X["X1_pads_tenons_floor"] = x1
    log("X1", {k: v for k, v in x1.items() if k != "shell_hinge_zone_raycast"}, x1["shell_hinge_zone_raycast"]["min"],
        x1["shell_hinge_zone_raycast"]["n_lt_1p19"])
    R["X_interfaces"] = X
    save()
    # ---------------------------------------------------------------- X2 cables in the head (E2f: only the head wires)
    wires_in_head = one(cab_h & bx(-60, 60, -40, 40, HZ + 8.6, HZ + 80))
    tgt = dict(bezel=bezel, bars=bars, carrier_screws=cscr, carrier_inserts=cins, glass=dp["glass"], lcd=dp["lcd"], pcb=dp["pcb"],
               standoffs=dp["standoffs"], header=dp["header"], usbc=dp["usbc"], small=dp["small"], magnets_shell=mag_s,
               magnets_bezel=mag_b, cross_screws=xscr, led_boards=ledb, ears=ears, usko_kryt=cap, usko_lozisko=lug,
               pads=padc, magnet_bosses=bosses)
    x2 = {}
    cp = B.cable_paths()
    L_w = path_len(cp[2][0], cp[2][1])
    w0, w1 = np.array(cp[2][0][0]), np.array(cp[2][0][-1])
    wpull = math.sqrt(max(0.0, L_w ** 2 - (w1[0] - w0[0]) ** 2 - (w1[2] - w0[2]) ** 2)) - abs(w1[1] - w0[1])
    wt = dict(tgt); wt.pop("usko_lozisko")
    x2["head_wires"] = dict(overlap_mm3={k: ivol(cab_h, v, k == "bezel") for k, v in tgt.items()},
                            overlap_shell_mm3=ivol(cab_h, shell, True), overlap_keepout_mm3=ivol(cab_h, keepout),
                            min_distance_inside_head={k: r3(wires_in_head.distance_to(v)) for k, v in wt.items()},
                            inside_head_to_shell=r3(wires_in_head.distance_to(shell)),
                            path_local_from_tenon_top=[[r3(x), r3(y), r3(z - HZ)] for x, y, z in cp[2][0]], tube_r=B.WIRE_R,
                            free_length_tenon_top_to_plug=r3(L_w), front_module_pull_out_before_taut=r3(wpull),
                            ends_at="header pin %d (5V)" % B.WIRE_PIN)
    sw_in_head = {f"tilt{th}": r3(ivol(swire.rotate(B.AX, -th) if th else swire, HC.head_outer(HZ))) for th in (-40, 0, 40)}
    x2["servo_wires_never_in_the_head"] = dict(
        overlap_with_head_exterior_mm3=sw_in_head,
        passed=ok("X2 E2f servo wires never inside the head", max(sw_in_head.values()) < 1e-4, sw_in_head),
        note="E2f: the servo is connected IN THE TORSO; the display header carries only the 4 head wires")
    plug_zone = bx(-HC.HDR_L / 2, HC.HDR_L / 2, HC.Y_HDR, B.WIRE_PLUG_Y, ZC + HC.HDR_Z - HC.HDR_W / 2, ZC + HC.HDR_Z + HC.HDR_W / 2)
    pz = dict(shell=shell, bezel=bezel, bars=bars, carrier_screws=cscr, cross_screws=xscr, usko_kryt=cap, usko_lozisko=lug,
              led_boards=ledb, magnets_shell=mag_s)
    x2["plug_zone_behind_header"] = dict(
        box="header footprint 40.9 x 5.2 from the header top y=-18.5 back to y=%.1f (Dupont housings 14 long)" % B.WIRE_PLUG_Y,
        overlap_mm3={k: ivol(plug_zone, v, k in ("shell", "bezel")) for k, v in pz.items()},
        min_distance={k: r3(plug_zone.distance_to(v)) for k, v in pz.items()})
    contacts = {"header"}                                              # the head-wire model ENDS on the header top (plug)
    wmin = min(v for k, v in x2["head_wires"]["min_distance_inside_head"].items() if k not in contacts)
    ok("X2 head wires overlaps 0", max(v for k, v in x2["head_wires"]["overlap_mm3"].items()) < 1e-3 and
       x2["head_wires"]["overlap_shell_mm3"] < 1e-3 and x2["head_wires"]["overlap_keepout_mm3"] < 1e-3,
       [x2["head_wires"]["overlap_mm3"], x2["head_wires"]["overlap_shell_mm3"]])
    ok("X2 head wires clear >= 0.5 inside the head", min(wmin, x2["head_wires"]["inside_head_to_shell"]) >= 0.499,
       [wmin, x2["head_wires"]["inside_head_to_shell"]])
    ok("X2 plug zone free", max(x2["plug_zone_behind_header"]["overlap_mm3"].values()) < 1e-3, x2["plug_zone_behind_header"]["overlap_mm3"])
    ok("X2 front module pull-out >= 40 before a wire is taut", wpull >= 40.0, r3(wpull))
    X["X2_cables_in_head"] = x2
    log("X2 wires", x2["head_wires"]["min_distance_inside_head"], x2["head_wires"]["inside_head_to_shell"], r3(L_w), r3(wpull), sw_in_head)
    log("X2 plug", x2["plug_zone_behind_header"])
    save()
    # ---------------------------------------------------------------- X3 D4 tool path, front module removed
    yh = -B.PAD[2] - B.SCR_HEAD[1]
    x3 = {}
    for sx in (-1, 1):
        for x in B.SCR_X:
            t = HC.ycyl(2.0, -70.0, yh, sx * x, B.ZS)
            oth = Compound([s for s in xscr.solids() if abs(s.center().X - sx * x) > 0.5])
            x3[f"x{sx * x:+.1f}"] = dict(
                overlap_shell_mm3=ivol(t, shell, True), overlap_shell_magnets_mm3=ivol(t, mag_s), overlap_lugs_mm3=round(ivol(t, cap) + ivol(t, lug), 4),
                overlap_cables_mm3=ivol(t, cab_h), overlap_other_cross_screws_mm3=ivol(t, oth),
                min_distance=dict(shell=r3(t.distance_to(shell)), shell_magnets=r3(t.distance_to(mag_s)), magnet_bosses=r3(t.distance_to(bosses)),
                                  head_wires=r3(t.distance_to(cab_h)), led_boards=r3(t.distance_to(ledb)),
                                  other_cross_screw_heads=r3(t.distance_to(oth))))
    tool_ok = all(v["overlap_shell_mm3"] == 0 and v["overlap_shell_magnets_mm3"] == 0 and v["overlap_lugs_mm3"] == 0 and
                  v["overlap_cables_mm3"] == 0 and v["overlap_other_cross_screws_mm3"] == 0 for v in x3.values())
    X["X3_tool_path_cross_screws"] = dict(
        tool="D4 shank along Y from the front opening (front module removed, wires unplugged) to the screw-head top y=%.1f, axis z=%.1f" % (yh, B.ZS),
        per_screw=x3, free=ok("X3 D4 tool path free", tool_ok, tool_ok),
        min_clearance=r3(min(min(v["min_distance"].values()) for v in x3.values())),
        note="neighbouring heads are 4.0 apart (dk 3.8): the D4 shank touches nothing only because it stops at the head top; use a "
             "1.3 hex bit with a shank <= D4")
    log("X3", {k: v["min_distance"] for k, v in x3.items()}, tool_ok)
    save()
    # ---------------------------------------------------------------- X4 bosses / bars / posts vs pads, tenons, cables
    stuff = dict(pads=padc, usko_kryt=cap, usko_lozisko=lug, cross_screws=xscr, head_wires=wires_in_head)
    x4 = dict(magnet_bosses={k: r3(bosses.distance_to(v)) for k, v in stuff.items()},
              carrier_bars={k: r3(bars.distance_to(v)) for k, v in stuff.items()},
              carrier_screws={k: r3(cscr.distance_to(v)) for k, v in stuff.items()},
              bezel_posts_rear={k: r3((bezel & bx(-60, 60, HC.Y_BB + 0.2, 0, HZ - 5, HZ + 90)).distance_to(v)) for k, v in stuff.items()},
              note="E2f: no cable bridge and no lead vault in the head any more")
    vals = [v for k in ("magnet_bosses", "carrier_bars", "carrier_screws", "bezel_posts_rear") for v in x4[k].values()]
    x4["min_all"] = ok("X4 bosses / bars / posts clear of pads, tenons, cables (>= 0.5)", min(vals) >= 0.499, r3(min(vals)))
    X["X4_bosses_bars_posts"] = x4
    log("X4", x4)
    save()
    # ---------------------------------------------------------------- X5 head exterior vs collar / torso / lugs
    torso = B.torso()
    torso_top = torso & (Pos(0, 0, 0.175) * Box(200, 200, 8.15))
    head_bot = HC.head_outer(HZ) & (Pos(0, 0, HZ + 10) * Box(200, 200, 20))
    rest = {cn: r3(head_bot.moved(Location((0, 0, -B.LIFT))).distance_to(c)) for cn, c in
            dict(golier_kotuc=disc, golier_prstenec=ring, trup=torso_top).items()}
    sw = {}
    for th in range(-40, 45, 5):
        hb = head_bot.rotate(B.AX, th) if th else head_bot
        sw[th] = {cn: r3(hb.distance_to(c)) for cn, c in dict(golier_kotuc=disc, golier_prstenec=ring, trup=torso_top).items()}
        log("X5 tilt", th, sw[th])
    hb_box = HC.head_outer(HZ).bounding_box()
    X["X5_head_vs_collar_torso"] = dict(
        head_exterior_bbox=[r3(hb_box.min.X), r3(hb_box.max.X), r3(hb_box.min.Y), r3(hb_box.max.Y), r3(hb_box.min.Z), r3(hb_box.max.Z)],
        rest_pose_lift_m20=rest, rest_min=ok("X5 head vs collar / torso at rest >= 0.25", min(rest.values()) >= 0.249, min(rest.values())),
        extended_tilt_sweep=sw,
        sweep_min=ok("X5 head vs collar / torso over the sweep >= 0.25", min(min(v.values()) for v in sw.values()) >= 0.249,
                     min(min(v.values()) for v in sw.values())),
        head_floor_z_over_the_lugs={f"x{x}_y{y}": r3(B.head_floor_z(x, y)) for x in (17.8, 20.3, 22.5) for y in (0.0, 8.0)},
        lowest_floor_allowed_over_the_barrels=26.9,
        note="shell vs neck halves / servo wires over the sweep: see the neck section (hlava_pri_pante, E10); lugs turn with the head")
    ok("X5 head floor above the lug barrels (>= 26.9)", min(X["X5_head_vs_collar_torso"]["head_floor_z_over_the_lugs"].values()) >= 26.9,
       X["X5_head_vs_collar_torso"]["head_floor_z_over_the_lugs"])
    log("X5", rest, X["X5_head_vs_collar_torso"]["sweep_min"])
    R["X_interfaces"] = X
    save()

# ================================================================================================================ T
if "T" in SEC:
    torso = B.torso()
    torso_top = torso & (Pos(0, 0, 0.175) * Box(200, 200, 8.15))
    head4 = HC.head_outer(HZ) & (Pos(0, 0, HZ + 10) * Box(200, 200, 20))
    LM = dict(head=head4, cap=cap, lug_plus=lug)
    LIFTS = [0, -1, -2, -3, -4, -5, -7.5, -10, -12.5, -15, -17.5, -20]
    TILTS = [40, 35, 30, 25, 20, 15, 10, 5, 2.5]

    # cheap certain-fail test on mesh vertices (OCC distances between interpenetrating lofts take minutes): a vertex
    # over the FLAT top of the collar disc (r <= 26, outside the slot rectangle + 0.7) lower than 0.2 above it
    VT = {mn: np.unique(B.tris(m, 0.05, 0.3).reshape(-1, 3), axis=0).astype(np.float64) for mn, m in LM.items()}

    def quick_fail(lf, th):
        for V in VT.values():
            W = B.tf(V, lf, th)
            m = (np.hypot(W[:, 0], W[:, 1]) <= 26.0) & ((np.abs(W[:, 0]) > B.BW / 2 + 0.95) | (np.abs(W[:, 1]) > B.BT / 2 + 0.95)) & (W[:, 2] < B.TOP + 0.2)
            if m.any():
                return True
        return False

    def clear(lf, th):
        if quick_fail(lf, th):
            return 0.0
        dmin = 99.0
        for mn, m in LM.items():
            mm = (m.rotate(B.AX, th) if th else m)
            mm = mm.moved(Location((0, 0, lf))) if lf else mm
            for c in (disc, ring, torso_top):
                if bb_overlap(mm, c, 1.0):
                    dmin = min(dmin, mm.distance_to(c))
        return dmin
    table = {(int(float(k)) if float(k) == int(float(k)) else float(k)): v
             for k, v in R.get("T_tilt_vs_lift", {}).get("partial", {}).items()}       # resumable (same geometry)
    for lf in LIFTS:
        if lf in table:
            log("T max tilt at lift", lf, table[lf], "(kept from the interrupted run)")
            continue
        row = {}
        for sg, key in ((1, "nod_down_+"), (-1, "nod_up_-")):
            best = 0.0
            for th in TILTS:
                if clear(lf, sg * th) >= 0.249:
                    best = th
                    break
            row[key] = best
        table[lf] = row
        log("T max tilt at lift", lf, row)
        R["T_tilt_vs_lift"] = dict(partial=table)
        save()
    tb = sorted(((float(k), v) for k, v in table.items()), reverse=True)

    def rule(lf, key):
        cand = [v[key] for k, v in tb if k <= lf + 1e-9]
        return cand[0] if cand else 0.0
    ver = {}
    for lf in [-0.5, -1.5, -2.5, -3.5, -4.5, -6.25, -8.75, -11.25, -13.75, -16.25, -18.75]:
        row = {}
        for sg, key in ((1, "nod_down_+"), (-1, "nod_up_-")):
            th = rule(lf, key)
            row[key] = dict(tilt=th, min_clear=r3(clear(lf, sg * th)))
        ver[lf] = row
        log("T rule check", lf, row)
    rmin = min(v[k]["min_clear"] for v in ver.values() for k in v)
    full0 = table[0]
    R["T_tilt_vs_lift"] = dict(
        max_tilt_deg_keeping_0p25_vs_collar_and_torso=table,
        full_range_at_full_extension=ok("T +-40 deg at full extension", full0["nod_down_+"] == 40 and full0["nod_up_-"] == 40, full0),
        rule="SIMPLE RULE (assembly text): tilt only when the neck is fully extended (lift 0); before retracting return to 0 deg. "
             "OPTIONAL table: between two listed lifts use the value of the MORE RETRACTED one (no interpolation)",
        rule_check_between_points=ver, rule_min_clear=ok("T table rule keeps >= 0.25 between the points", rmin >= 0.249, rmin),
        clearance_at_rest_tilt0=r3(clear(-B.LIFT, 0)),
        method="OCC minimum distance of the head exterior (bottom 20 mm), usko_kryt and usko_lozisko to golier_kotuc, golier_prstenec "
               "and the torso top; a mesh-vertex pre-test rejects poses that are certainly closer than 0.2 to the flat collar top")
    save()

# ================================================================================================================ V
if "V" in SEC:
    torso = B.torso()
    EXT = {"hlava_skrupina", "ram_displeja", "usi", "led_kruzky", "usko_kryt", "usko_lozisko", "krk_predna_polovica",
           "krk_zadna_polovica", "golier_kotuc", "golier_prstenec", "trup", "displej#glass", "pena_displeja", "oci_len_vizualizacia"}
    LEAD = set()                                     # E2f: NO lead exception any more - every internal part counts
    labels, TT = [], []

    def add(lab, s, g, tol=0.02, ang=0.2):
        if lab not in labels:
            labels.append(lab)
        TT.append((B.tris(s, tol, ang).astype(np.float64), g, labels.index(lab)))
    for k, lst in P.items():
        for i, (s, g) in enumerate(lst):
            lab = k
            if k == "displej":
                lab = "displej#glass" if i == 0 else "displej#board"
            elif k == "kabel":
                lab = ("kabel#head_wires_static", "kabel#head_wires", "kabel#servo_wires")[i]
            elif k == "skrutky":
                lab = ("skrutky#neck", "skrutky#horn", "skrutky#cross", "skrutky#carrier", "skrutky#carrier_inserts")[i]
            add(lab, s, g)
    add("trup", torso, "T", 0.03, 0.2)
    INTERNAL = [l for l in labels if l not in EXT and l not in LEAD]
    ntri = int(sum(len(t) for t, g, i in TT))
    VIEWS = [(az, el) for az in (-90, -60, -40, -20, 0, 20, 40, 60, 90, 180) for el in (-20, 0, 35)]
    POSES = (("rest", -B.LIFT, 0), ("extended_tilt0", 0, 0), ("extended_tilt+40", 0, 40), ("extended_tilt-40", 0, -40))
    glob_res, worst_int, worst_lead = {}, 0.0, 0.0
    px = 0.25
    for lab, lift, tilt in POSES:
        T = np.concatenate([t if g == "T" else B.tf(t, lift, tilt if g == "H" else 0.0) for t, g, i in TT])
        I = np.concatenate([np.full(len(t), i) for t, g, i in TT])
        box = (-62, 62, -45, 45, 2.0, HZ + 82 + lift + (0 if not tilt else 12))
        per = {}
        for az, el in VIEWS:
            img = VZ.zbuffer_fast(T, I, az, el, box, px)
            cnt = {labels[i]: round(float((img == i).sum()) * px * px, 2) for i in np.unique(img) if i >= 0 and labels[i] not in EXT}
            if cnt:
                per[f"az{az}_el{el}"] = cnt
            worst_int = max(worst_int, sum(v for k, v in cnt.items() if k in INTERNAL))
            worst_lead = max(worst_lead, sum(v for k, v in cnt.items() if k in LEAD))
        glob_res[lab] = dict(views_with_non_exterior_parts_mm2=per)
        log("V global", lab, per)
        R["V_E9_visibility"] = dict(partial=glob_res)
        save()
    # hinge window, 0.05 mm/px (round-5 method)
    VIEWS2 = [(az, el) for az in (0, 180) for el in (-30, -15, 0, 15, 30, 45, 60)] + \
             [(az, el) for az in (-30, -15, 15, 30, 150, 165, 195, 210) for el in (0, 20)] + \
             [(az, el) for az in (-60, 60, 120, 240) for el in (-20, 0)]
    fine, worst_int2, worst_lead2 = {}, 0.0, 0.0
    for lab, lift, tilt in POSES:
        T = np.concatenate([t if g == "T" else B.tf(t, lift, tilt if g == "H" else 0.0) for t, g, i in TT])
        I = np.concatenate([np.full(len(t), i) for t, g, i in TT])
        box = (-25, 25, -14, 14, AXZ - 12 + lift, AXZ + 12 + lift)
        per = {}
        for az, el in VIEWS2:
            img = VZ.zbuffer_fast(T, I, az, el, box, 0.05)
            cnt = {labels[i]: round(float((img == i).sum()) * 0.0025, 3) for i in np.unique(img) if i >= 0 and labels[i] not in EXT}
            if cnt:
                per[f"az{az}_el{el}"] = cnt
            worst_int2 = max(worst_int2, sum(v for k, v in cnt.items() if k in INTERNAL))
            worst_lead2 = max(worst_lead2, sum(v for k, v in cnt.items() if k in LEAD))
        fine[lab] = dict(views_with_non_exterior_parts_mm2=per)
        log("V hinge", lab, per)
    R["V_E9_visibility"] = dict(
        method="orthographic z-buffer of ALL registry parts + torso (first hit per pixel). (a) whole robot: 0.25 mm/px, 30 views "
               "(az -90,-60,-40,-20,0,20,40,60,90,180 x el -20 (from below), 0 (eye height), 35 (3/4 above)); (b) hinge window "
               "|x| <= 25, |y| <= 14, axis +-12: 0.05 mm/px, 38 views (round-5 set + az +-60 / 120 / 240).  Poses: rest, extended 0, +40, -40",
        exterior_parts=sorted(EXT), internal_parts=INTERNAL, lead_exceptions="none (E2f)", triangles=ntri,
        whole_robot=glob_res, hinge_window=fine,
        worst_internal_area_mm2=ok("E9 no internal part visible", max(worst_int, worst_int2) == 0, dict(whole_robot=worst_int, hinge_window=worst_int2)),
        servo_wires_visible_area_mm2=dict(whole_robot_worst_view=max((v.get("kabel#servo_wires", 0.0) for p_ in glob_res.values()
                                                                      for v in p_["views_with_non_exterior_parts_mm2"].values()), default=0.0),
                                          hinge_window_worst_view=max((v.get("kabel#servo_wires", 0.0) for p_ in fine.values()
                                                                       for v in p_["views_with_non_exterior_parts_mm2"].values()), default=0.0),
                                          note="E2f: the servo wires are an ordinary internal part (no exception); they leave the neck "
                                               "through its bottom inside the torso"),
        display_note="the display glass (displej#glass) is the face = exterior; LCD / PCB / header are behind it (displej#board)")
    save()

# ================================================================================================================ S
if "S" in SEC:
    def open_edges(path):
        T = B.read_stl(path).astype(np.float64)
        q = np.round(T.reshape(-1, 3) / 1e-4).astype(np.int64)
        _, idx = np.unique(q, axis=0, return_inverse=True); idx = idx.reshape(-1, 3)
        e = np.sort(np.concatenate([idx[:, [0, 1]], idx[:, [1, 2]], idx[:, [2, 0]]]), axis=1)
        e = e[e[:, 0] != e[:, 1]]
        _, c = np.unique(e, axis=0, return_counts=True)
        return int((c != 2).sum()), int(len(T))
    files = sorted(glob.glob(f"{B.D}/stl/*.stl"))
    have = {os.path.basename(p)[:-4] for p in files}
    want = set(EXPECT) | {"trup", "CELOK_vysunute", "CELOK_naklon40", "CELOK_pokoj"}
    oe = {}
    for p in files:
        n, nt = open_edges(p)
        oe[os.path.basename(p)] = dict(triangles=nt, open_edges=n, mtime=time.strftime("%H:%M:%S", time.localtime(os.path.getmtime(p))))
    bad = {k: v["open_edges"] for k, v in oe.items() if not k.startswith("CELOK") and v["open_edges"]}
    R["S_stl"] = dict(dir=f"{B.D}/stl", files=oe,
                      names=ok("S STL names = registry + trup + CELOK_*", have == want, dict(missing=sorted(want - have), stale=sorted(have - want))),
                      per_part_closed=ok("S every part STL closed (edges shared by 2)", not bad, bad),
                      note="per-part STL = REST pose (neck + head 20 mm down); CELOK_* = concatenation of the closed part meshes "
                           "(extended / tilt 40 / rest); weld tolerance 1e-4")
    log("S", {k: v["open_edges"] for k, v in oe.items()}, sorted(want - have), sorted(have - want))
    save()

# =============================================================================================================== R5
if "R5" in SEC:
    r5 = {}
    env_neck, env_cap, env_lug = B.neck_env(), B.lug_blank(-1), B.lug_blank(1)
    ENV = env_neck + env_cap + env_lug
    head_out = HC.head_outer(HZ)
    above_zb = Pos(0, 0, B.ZB + 100) * Box(300, 300, 200)
    gap = B.xcyl(6.7, -B.LUG0, -B.KN, 0, AXZ) + B.xcyl(6.6, B.KN, B.LUG0, 0, AXZ)
    cont = {}
    for n, p in dict(servo=servo, foam=foam, pin=pin, brg_inner=bi, brg_outer=bo, dowels=dowels, neck_screws=nscr, horn=horn,
                     horn_screw=hscr, ptfe_ring=ptfe, cable_neck=cab_n & above_zb, servo_wires=swire & above_zb).items():
        out = p - ENV
        v = sum(s.volume for s in out.solids()) if out is not None and out.solids() else 0.0
        vg = ivol(out, gap) if v > 1e-4 else 0.0
        cont[n] = dict(outside_mm3=r3(v), of_which_inside_the_0p3_hinge_seams=r3(vg))
    inside_head = bx(-80, 80, -60, 60, HZ + 0.6, HZ + 120)
    for n, p in dict(lcd=dp["lcd"], pcb=dp["pcb"], standoffs=dp["standoffs"], header=dp["header"], usbc=dp["usbc"], small=dp["small"],
                     glass=dp["glass"], gasket=gasket, bars=bars, carrier_screws=cscr, carrier_inserts=cins, magnets_bezel=mag_b,
                     magnets_shell=mag_s, led_boards=ledb, cross_screws=xscr, head_wires_in_head=cab_h & inside_head).items():
        out = p - head_out
        cont[n] = dict(outside_head_mm3=r3(mv(out)) if out is not None and out.solids() else 0.0)
    cbad = {k: v for k, v in cont.items() if isinstance(v, dict) and (v.get("outside_head_mm3", 0) > 1e-3 or
            (v.get("outside_mm3", 0) - v.get("of_which_inside_the_0p3_hinge_seams", 0)) > 1e-3)}
    r5["containment"] = dict(parts=cont, all_inside=ok("R5 containment", not cbad, cbad),
                             note="neck-side parts vs the neck + lug envelopes (voids ignored); head-side parts vs the head exterior loft")
    log("R5 containment", cont)
    # ---- servo hold (Y foam strips, floor datum, rocking)
    rk, free = {}, None
    for a in (0.05, 0.1, 0.15, 0.2, 0.25, 0.3, 0.4):
        rk[a] = max(ivol(servo.rotate(B.AX, a), neck), ivol(servo.rotate(B.AX, -a), neck))
        if free is None and rk[a] > 1e-3:
            free = a
    floor_closed = 6.1 + B.GY + B.FOAM[0] - B.CLOSE
    spread = {}
    for w in (12.0, 12.05, 12.1, 12.14, 12.15, 12.2, 12.3):
        c = B.rbox(B.XC, B.XB, -w / 2, w / 2, B.SZ0, B.SZ1, 0.5, Axis.X)
        shim = 0.1 if w < 12.15 else 0.0
        g_ = floor_closed - w / 2 - shim
        spread[str(w)] = dict(hard_wall_overlap_mm3=ivol(c, neck), kapton_shim=shim, foam_gap=r3(g_),
                              foam_compression_pct=round(100 * (B.FOAM[1] - g_) / B.FOAM[1], 1))
    fz = [B.FOAM[5], B.FOAM[6]]
    fa = (B.FOAM[4] - B.FOAM[3] - 0.4) * (fz[1] - fz[0] - 0.4)
    r5["servo_hold"] = dict(
        pocket_y_closed=r3(6.1 + B.GY - B.CLOSE), servo_vs_closed_halves_mm3=ivol(servo, neck), servo_min_clear=r3(servo.distance_to(neck)),
        foam_y=dict(recess_depth=B.FOAM[0], free_t=B.FOAM[1], strip_area_mm2_per_side=r3(fa), foam_vs_halves_mm3=ivol(foam, neck),
                    foam_vs_servo_mm3=ivol(foam, servo), rule="case width < 12.15 -> one layer of 0.1 Kapton under each strip"),
        case_width_spread=spread, servo_overlap_after_rocking_deg=rk, hard_stop_rock_deg=free,
        z=dict(floor_gap_modelled=B.Z_FLOOR, roof_gap=B.G, overlap_after_dz={str(dz): ivol(servo.moved(Location((0, 0, dz))), neck)
                                                                            for dz in (-0.02, 0.0, 0.14, 0.16)}),
        horn_rib_preload_overlap_mm3=ivol(horn, cap))
    ok("R5 servo free in the closed pocket", r5["servo_hold"]["servo_vs_closed_halves_mm3"] < 1e-3, r5["servo_hold"]["servo_vs_closed_halves_mm3"])
    log("R5 servo hold", r5["servo_hold"])
    # ---- neck clamp, fits, pin grip, collar ring
    sp = B.OBL_SP()
    cross = {f"M2x12 ({x}, {z})": z for x, z in B.NSCR}
    cross[f"M2x12 oblique x={B.OBL[0]}"] = r3(B.OBL[1] + sp * math.sin(math.radians(B.OBL[2])))
    cvd = B.closed_void_dict()
    mouth = cvd[f"screw_cbore_{len(B.NSCR)}"] & (Pos(0, -B.BT / 2 - 0.25, 0) * Box(100, 0.5, 100))
    sc = list(nscr.solids())[:4]
    face = -B.BT / 2
    r5["neck_clamp"] = dict(
        screws_z_at_the_parting_plane=cross, dowel_positions_xz=B.DOWELS,
        oblique_screw=dict(rise_deg=B.OBL[2], face_mouth_z=[r3(mouth.bounding_box().min.Z), r3(mouth.bounding_box().max.Z)],
                           hidden_below_z=B.TOP - 1.0, length=B.OBL_LEN),
        head_inset_below_front_face={f"x{s.center().X:.1f}": r3(s.bounding_box().min.Y - face) for s in sc},
        screws_vs_front_mm3=ivol(nscr, nf), screws_vs_back_mm3=ivol(nscr, nb),
        dowels=dict(front_hole_d=2 * B.DOWEL_R[0], back_hole_d=2 * B.DOWEL_R[1], vs_front_mm3=ivol(dowels, nf), vs_back_mm3=ivol(dowels, nb)),
        halves=dict(front_y=[r3(nf.bounding_box().min.Y), r3(nf.bounding_box().max.Y)], back_y=[r3(nb.bounding_box().min.Y), r3(nb.bounding_box().max.Y)],
                    gap=r3(nf.distance_to(nb)), overlap_mm3=ivol(nf, nb)),
        pin_vs_front_mm3=ivol(pin, nf), pin_vs_back_mm3=ivol(pin, nb), pin_seat_interference_mm3=ivol(pin, neck))
    ok("R5 neck screw mouths hidden in the torso when extended", r5["neck_clamp"]["oblique_screw"]["face_mouth_z"][1] <= B.TOP - 1.0,
       r5["neck_clamp"]["oblique_screw"]["face_mouth_z"])
    ok("R5 neck halves closed, no overlap", r5["neck_clamp"]["halves"]["overlap_mm3"] < 1e-3 and r5["neck_clamp"]["halves"]["gap"] < 1e-3,
       r5["neck_clamp"]["halves"])
    cov = {}
    xs = [round(B.PIN_X0 - 0.2 + 0.2 * i, 2) for i in range(int((18.6 - B.PIN_X0 + 0.2) / 0.2))]
    for x0 in xs:
        band = B.xcyl(B.SEAT_R + 0.1, x0, x0 + 0.2, 0, AXZ) - B.xcyl(B.SEAT_R, x0 - 1, x0 + 1, 0, AXZ)
        cov[x0] = r3(ivol(band, neck) / band.volume)
    grip = [x for x in xs if cov[x] >= 0.85 and B.PIN_X0 - 0.01 <= x <= B.PIN_X1]
    r5["pin_grip"] = dict(pin_od=2 * B.PIN_R, pin_x=[B.PIN_X0, B.PIN_X1], seat_d_closed=2 * B.SEAT_R, coverage_by_x_0p2_slices=cov,
                          grip_len_cov_ge_0p85=r3(0.2 * len(grip)), grip_x=[min(grip), r3(max(grip) + 0.2)] if grip else None,
                          L_over_D=r3(0.2 * len(grip) / (2 * B.PIN_R)), radial_glue_gap=r3(B.SEAT_R - B.PIN_R),
                          pin_lowered_into_front_half_minus_Y={str(s_): ivol(pin.moved(Location((0, s_, 0))), nf) for s_ in (3.0, 1.0, 0.0)})
    seat = [x for x in xs if cov[x] >= 0.80 and B.PIN_X0 - 0.01 <= x <= B.PIN_X1]
    r5["pin_grip"].update(seat_len_cov_ge_0p80=r3(0.2 * len(seat)), seat_L_over_D=r3(0.2 * len(seat) / (2 * B.PIN_R)),
                          round5=dict(grip_len_cov_ge_0p85=3.2, pin_x=[12.8, 18.5]),
                          note="E2 C1 made the pocket 0.75 longer -> pin 13.4..18.5, glued seat 13.4..16.0 = 2.6 (round 5: 3.2); "
                               "coverage 0.847 over the first 1.0 (D-flat + the 2.5 wide wire neck), 0.885..1.0 over the last 1.6")
    ok("R5 pin seat length (coverage >= 0.8) >= 2.5", r5["pin_grip"]["seat_len_cov_ge_0p80"] >= 2.499, r5["pin_grip"]["seat_len_cov_ge_0p80"])
    torso = B.torso()
    ann = B.zcyl(B.COLLAR[2], -2.1, -2.0) - B.zcyl(B.COLLAR[1], -2.2, -1.9)
    rb = ring.bounding_box()
    r5["collar_ring"] = dict(ring_z=[r3(rb.min.Z), r3(rb.max.Z)], ring_r=[B.COLLAR[1], B.COLLAR[2]],
                             torso_support_under_ring_fraction=r3(ivol(ann, torso) / ann.volume), ring_vs_torso_mm3=ivol(ring, torso),
                             disc_vs_torso_mm3=ivol(disc, torso), ring_to_disc_gap=r3(ring.distance_to(disc)),
                             ring_to_torso_recess_radial=r3(B.COLLAR[3] - B.COLLAR[2]),
                             disc_z=[r3(disc.bounding_box().min.Z), r3(disc.bounding_box().max.Z)],
                             ring_top_flush_with_disc_top=bool(abs(rb.max.Z - disc.bounding_box().max.Z) < 1e-6),
                             torso_rim_round_R=B.TORSO_RIM["r"])
    ok("R5 collar vs torso overlap 0", r5["collar_ring"]["ring_vs_torso_mm3"] < 1e-3 and r5["collar_ring"]["disc_vs_torso_mm3"] < 1e-3,
       [r5["collar_ring"]["ring_vs_torso_mm3"], r5["collar_ring"]["disc_vs_torso_mm3"]])
    r5["lug_sleeve"] = dict(bore_d=r3(2 * B.SLV[2]), mr85_od=8.0, radial_epoxy_gap=r3(B.SLV[2] - 4.0), wall=r3(B.SLV[3] - B.SLV[2]),
                            radial_clear_to_counterbore=r3(B.CB_R - B.SLV[3]), bearing_vs_lug_mm3=ivol(bo, lug))
    # ---- neck surface openings (nothing may open on the visible faces above the collar)
    def env_inset(d):
        body = B.rbox(-B.BW / 2 + d, B.BW / 2 - d, -B.BT / 2 + d, B.BT / 2 - d, B.ZB + d, AXZ, max(B.CORNER_R - d, 0.0), Axis.Z)
        for sx in (-1, 1):
            x0, x1 = sorted((sx * (B.KN + 0.25 - d), sx * (B.BW / 2 + 1.0)))
            body = body - (Pos((x0 + x1) / 2, 0, AXZ + (B.RK + 1.0) / 2) * Box(x1 - x0, B.BT + 2, B.RK + 1.0) +
                           B.xcyl(B.RK + 0.5 + d, x0, x1, 0, AXZ))
        return body + B.xcyl(B.RK - d, -B.KN + d, B.KN - d, 0, AXZ)
    skin = env_neck - env_inset(0.4)
    pier, zmax_fb = [], -99.0
    for vn, v in B.neck_void_dict().items():
        xx = v & skin
        if xx is None or not xx.solids():
            continue
        for x in xx.solids():
            if x.volume < 1e-3:
                continue
            bb = x.bounding_box()
            where = ("front" if bb.min.Y < -B.BT / 2 + 0.5 else "back" if bb.max.Y > B.BT / 2 - 0.5 else
                     "bottom" if bb.min.Z < B.ZB + 0.5 else "knuckle top" if bb.max.Z > AXZ + B.RK - 0.5 else
                     "knuckle end face (inside the 0.3 hinge seam, behind the lip ring)")
            pier.append(dict(void=vn, where=where, x=[r3(bb.min.X), r3(bb.max.X)], z=[r3(bb.min.Z), r3(bb.max.Z)]))
            if where in ("front", "back"):
                zmax_fb = max(zmax_fb, bb.max.Z)
    r5["neck_surface_openings"] = dict(openings=pier, front_back_openings_max_z_extended=r3(zmax_fb), collar_top_z=B.TOP,
                                       hidden_in_torso_when_extended=ok("R5 neck front/back openings below the collar when extended",
                                                                        zmax_fb < B.TOP - 1.0, r3(zmax_fb)))
    log("R5 neck", r5["neck_clamp"], r5["pin_grip"]["grip_len_cov_ge_0p85"], r5["collar_ring"], r5["neck_surface_openings"])
    R["R5_still_valid"] = r5
    save()

save()
log("done; FAILED:", FAIL)
