"""NOVA mini - variant B (tilt MG90S in the neck top, shaft on the hinge axis), revision E2 - INTEGRATED model
(neck / hinge / servo pocket of this file + the live E2 head module /tmp/claude-0/gapwf/fin/common/head_common.py).
Imports the original builder c_hn4 (constants / helpers); overrides the neck, servo, horn, lugs, collar, cables.
World mm, Z up, front -Y, robot right -X.  Extended pose: head bottom HZ = 27, hinge axis AXZ = 16.5.  Rest = -20 mm.
The round-5 state is frozen in r5/ (build.py, checks, montaz).  What is still valid from rounds 1-5:
* real MG90S on the hinge axis, horn arms keyed in the -X lug CAP between 4 crush ribs 0.1 (zero backlash), tenons
  4 x 16 + 4 x M2x8 cross screws into the head pads, glue-in M2 inserts.
* +X hinge: MR85 x16.0..18.5 in a black lug SLEEVE running in a knuckle counterbore r5.9; hollow pin D4.99 / 3 (h6, slip
  fit in the MR85, epoxied in the front-half seat r2.55 with a D-flat), both bore ends chamfered; the head wires enter
  the pin from below through an open end slot, bend R1.5 inside the pin bore, twist on the axis and bend R2.0 inside the
  rotating lug chamber.
* servo pocket Y +-6.20 modelled = +-6.15 closed (0.05 / side) + PORON foam 0.5 in a 0.3 recess on each large face;
  pocket FLOOR = Z datum (0.01 modelled), roof 0.15.
* neck halves are built / exported CLOSED (front +0.05 Y, back -0.05 Y); 3 x M2x12 straight + 1 oblique screw, inserts
  on a step + pilot; dowels D2 (epoxied in the BACK half D2.0, slip D2.02 in the FRONT half).
* collar disc + ring 6 tall (z -2..4) on the recess floor; cable STL meshed watertight; screws modelled at the
  standard maximum head size.
Revision E2 - NECK / HINGE side (E2_spec A2, A3, C1-C4; E1 4, 5, 6):
* MG90S model: keyhole turret (boss r5.9 + lobe r2.9 at 5.6, both 6.0 high), lead nub on the end face NEAREST the
  shaft (pocket top) next to the bottom cover, no mounting tabs.
* pocket: gear face = X datum on the -X wall, +X end 0.75 longer with 2 foam pads 1.0 (pena_serva) beside the wire
  chamber; keyhole bore (boss r6.05 + lobe relief r3.3 to centre distance 6.5) to the common floor x -16.2; the -X
  knuckle end is an OPEN bore r6.65 (no thin end wall): horn arms + the cap PLUG (2 cheeks r6.3) run inside it, so
  the arms are held over their full thickness for arm top 8.9..10.3 and nothing static is within 0.3 of them.
* servo lead goes UP: slot through the knuckle top on the parting plane (x 8.0..12.5, |y| <= 2.4) + flared slot in
  the head floor (head_pads_and_cuts); lead stub in group N, lead run in group H.
* hinge: seam 0.3 (LUG0 17.8), static lip ring on BOTH knuckle ends (the +X one hides the sleeve), PTFE thrust ring
  klzny_kruzok 13.0 x 16.4 x 0.25 on the cap groove bottom against the -X lip tip (axial float 0.05), counterbore
  floor x 15.75 (0.25 to the MR85 outer ring), pin 13.4..18.5 (behind the longer pocket), head-wire passage = slot
  1.6 x 4.0 in the +X lug / tenon, chamber 4.0 wide with a funnel to a 2.5 neck under the pin slot 2.2 x 2.2.
* exterior: blade corners R3, rolling-ball R3 saddles (offset construction), parting-line V 0.3 x 0.15, lugs = barrel
  R10 + web +-8.25 with a concave R4 blend and R3 end-face rounds (R3 instead of R2: the barrel must pass the collar
  slot corner R3.25), tenon / slot outer corners R2.9 / R3.0, collar slot R3.25 with R0.6 edge, seams 0.25 / 0.1.
* fasteners: head cross screws ISO 7380-1 M2x8 modelled dk 3.8 x k 1.3; 4th neck screw = oblique M2x12 lowered to
  cross the parting plane at z 2.9 (keyhole relief above it), insert seat 0.9..3.9 behind the parting plane.
Revision E2 - INTEGRATION (head W110 x H79 N5 with bezel / bare display / carrier bars / magnets from head_common):
* build_all() returns the E2 registry (E2_spec D): head parts come from HC.head_parts(HZ, cuts, adds) with the pads /
  tenon slots / cross-screw holes / lead slot of head_pads_and_cuts(); drziak_displeja (2 bars) is a real part and is
  part of CELOK_*.  export() deletes every old STL before writing.
* lead floor slot: the 40 deg flare starts 3.0 above the head bottom, below it the end walls are vertical at
  |y| 13.72 (the plain flare left a 38 deg feather edge where the back end wall met the rising floor of the new head).
* E9: vault over the lead floor slot (lead_hood(), part of the shell, concentric with the hinge axis, r 19.8 / 21.1,
  x -6..14) - through the open slot the display board, bars, an LED board and cross-screw heads were visible from
  below / behind; black foam plug in the knuckle lead slot (lead_plug(), 2nd item of pena_serva) - the servo end face
  was visible there from 3/4 above at +-40 deg.
* servo lead run inside the head (group H): floor slot -> up to local z 7.5 under the vault -> along -X, climbing to
  local z 10.4 -> level over the -X pad (0.6 above it) onto the cable-bridge deck (x -37.5..-30.5, tie point 44 mm
  from the lead exit) -> service loop back along +X at y +7 -> into the display header at pin 4 (G; 5V = pin 2
  beside it, signal = one GPIO further along).
* head wires (4 x D0.85): tenon top -> service loop to the back (y +19) -> into the header at pin 2 (5V).  Both runs
  leave >= 40 mm of pull-out travel for the magnetic front module before a wire gets taut (checks, section X2).
"""
import sys, math, json, importlib.util, functools
sys.path.insert(0, "/home/user/Robot"); sys.path.insert(0, "/tmp/claude-0/pan16"); sys.path.insert(0, "/tmp/claude-0/gapwf/fin/common")   # live E2 head module
from build123d import (Pos, Rot, Box, Cylinder, Sphere, Axis, Location, Solid, Compound, Face, Polyline, extrude, fillet,
                       export_stl)
import head_common as HC


def _load(name, path):
    s = importlib.util.spec_from_file_location(name, path); m = importlib.util.module_from_spec(s); s.loader.exec_module(m)
    return m


_prev = sys.modules.get("build")                                       # c_hn4 does `import build` (= c_hn3)
sys.modules["build"] = _load("c_hn3_build", "/tmp/claude-0/gapwf/c_hn3/build.py")
B4 = _load("c_hn4_build", "/tmp/claude-0/gapwf/c_hn4/build.py")      # original builder (imports c_hn3)
if _prev is not None:
    sys.modules["build"] = _prev
else:
    del sys.modules["build"]
HC.setup()                                                             # c_hn3 import re-patched softhead - re-assert
D = "/tmp/claude-0/gapwf/fin/B"
HZ, BW, BT, RK, AXZ, KN, LUG1, ZB = B4.HZ, B4.BW, B4.BT, B4.RK, B4.AXZ, B4.KN, B4.LUG1, B4.ZB
LUG0 = 17.8                       # E2: hinge seam 0.3 (KN 17.5 -> lug inner face 17.8; c_hn3 had 18.0)
xcyl, zcyl, ycyl = HC.xcyl, B4.zcyl, HC.ycyl
LIFT = 20.0
# =====================================================================================================================
# E2 INTERFACE - everything the HEAD side / the integration step needs from the neck + hinge side (world mm, extended
# pose HZ = 27; "local z" = z - HZ).  head_pads_and_cuts() turns these into pads (adds) and cuts for HC.head_shell().
#   TEN        tenon |x| 18.3..22.3, |y| <= 8.0, z HZ-0.5..HZ+8.5; vertical corners R1.0 (inner) / R2.9 (outer, under the
#              R3 web round).  Floor slot = tenon + 0.1 per side (|x| 18.2..22.4, |y| <= 8.1, corners R1.1 / R3.0).
#   PAD        head pad |x| 14.0..27.5, |y| <= 11.0, z HZ-1.0..HZ+8.5 (clipped to the head exterior by HC.clip_inside);
#              front face y = -11.0 is the cross-screw head seat.  (R5 pads started at |x| 11: moved for the lead slot.)
#   SCR_X, ZS  cross-screw axes |x| 18.3 / 22.3, z = HZ+5.5, along +Y from y = -11 (ISO 7380-1 M2x8, dk 3.8 x k 1.3:
#              head occupies y -12.3..-11.0, r 1.9); pilot r0.8 to y -2.0; clearance r1.1 from y -11.6 to -6.9.
#   LEAD_FSLOT servo-lead slot through the head floor: x 8.0..12.5 (= XB-4.6..XB-0.1); end walls vertical at
#              |y| = 13.72 up to local z 3.0 (LEAD_LAND), then FLARED 40 deg (parallel to the lead at full tilt:
#              |y| <= 11.2 + (z-HZ)*tan40), cut up to HZ+7.0 (the back floor rises), corner edges R2.2.  Keep pads /
#              ribs / bridges out of x 7.5..13.0, |y| <= max(14.2, 11.7 + 0.84 * local z), local z <= 7.
#   LEAD_X/R   servo lead (3 wires in a black sleeve, modelled as a tube r 1.3) leaves the knuckle at x 10.25, y 0,
#              z AXZ+10 = 26.5 (static stub, group N) and continues in group H from (10.25, 0, HZ).
#   LEAD_RUN   head-local polyline of the lead run inside the head (integration): slot -> local z 7.5 under the vault
#              -> along -X, climbing to local z 10.4 -> over the -X pad onto the bridge deck (HC.BRIDGE, deck top local
#              z 9.1) -> loop back at y +7, local z of the even header row -> header pin 4 (HC.header_pin).
#              Tie-down = the bridge, 38.5 from the slot.
#   HOOD       vault over the lead slot (lead_hood): cylindrical shell about the hinge axis, inner r 19.8 / outer 21.1,
#              x -6.0..14.0 (end wall 12.5..14.0 against the +X pad, open mouth at -6), top at local z 10.6; keep
#              everything else out of r <= 21.6 about the axis for x -6.5..14.
#   WEB        lug/web footprint under the floor: |x| 17.8..22.5, |y| <= 8.25 (outer corners R3), web top = head bottom
#              - 0.1 (cut with HC.head_outer(HZ-0.1), so it follows any floor shape).  Barrel R10 about the hinge axis
#              (z AXZ = 16.5) -> lowest head-floor point allowed over |x| <= 22.5, |y| <= 10: z >= 26.9.
#   HEAD_WIRE  head wires (4 x D0.85, modelled as one tube r 0.6) leave the +X tenon top at x 20.3, y 0..2.4,
#              z HZ+8.5 (slot 1.6 x 4.0, y -0.8..3.2).
#   No apron pegs / peg holes any more.  Group of klzny_kruzok: H (bonded in the cap groove).
# =====================================================================================================================
TEN = (18.3, 22.3, 8.0, HZ - 0.5, HZ + 8.5)   # tenon |x| range, half y, z range
TEN_R = (1.0, 2.9)                # E2: tenon corner radii inner / outer (outer follows the R3 web->end-face round)
ZS = HZ + 5.5                     # cross-screw axis height (groove holes)
SCR_X = (18.3, 22.3)              # cross-screw axes |x| (tenon inner / outer face)
SCR_HEAD = (1.9, 1.3)             # E2: ISO 7380-1 M2 button head r (dk 3.8) / k 1.3
PAD = (14.0, 27.5, 11.0)          # E2: head pad |x| range (was 11.0..27.5), half y (front face y=-11 = screw head seat)
# ---- servo (shaft along -X on the hinge axis); x positions from the horn stack: arm top 9.6 above the case top
XC = -9.9                         # case top face (gear side); case bottom = XC + 22.5 = 12.6
XB = XC + 22.5
G = 0.15                          # servo pocket clearance: boss radial / roof
GY = 0.10                         # R3: pocket +-6.20 modelled -> +-6.15 closed = 0.05/side clearance (no clamp)
XDAT = 0.05                       # E2: -X pocket wall = gear-face DATUM, modelled 0.05 behind the nominal case top
XEND = 0.75                       # E2: +X pocket end 0.75 longer than the 22.5 case (foam pad 1.0 free on that wall)
FOAM = (0.30, 0.50, 0.35, -8.4, 11.1, 0.6, 8.6)   # R3: recess depth, foam t free / compressed, recess x0,x1,z0,z1
PADX = (2.4, 5.8, AXZ - 14.0, AXZ - 2.0, 1.0)     # E2: 2 foam pads on the +X wall: |y| range, z range, free thickness
SZ0, SZ1 = AXZ - 16.9, AXZ + 5.9  # case z range (shaft 5.9 from the top end)
Z_FLOOR = 0.01                    # R5: pocket floor = Z datum (case far end rests on it; 0.01 = numerical gap)
TUR_H = 6.0                       # E2: turret (boss + lobe) height above the case top, nominal (range 5.4..6.2)
LOBE = (2.9, 5.6)                 # E2: keyhole lobe r, centre distance from the spline axis (toward the case centre, -Z)
LOBE_REL = (3.3, 6.5)             # E2: lobe relief r (3.1 + 0.2), max centre distance (stadium from the axis -> 5.0..6.5)
BOSS_FLOOR = XC - 6.3             # R5: common floor of the keyhole bore (0.3 above the nominal turret, end wall 1.3)
BORE_R = 6.65                     # E2: open bore through the -X knuckle end (x -17.5..-16.2): horn arms + cap plug
                                  # (6.65 as a void = 6.60 at the parting sides once the halves are closed: 0.30 to the plug)
NUB = (XB - 3.35, XB - 1.35, 2.0, 2.0)  # E2: lead strain-relief nub on the pocket-TOP end face: x0, x1, half y, height
                                  # (centre of the accepted range XB-4.3..XB-0.35 = centre of the lead slots)
LEAD_X, LEAD_R = XB - 2.35, 1.3   # E2: servo lead centre x / tube r (3 x D1.2 wires in a sleeve)
LEAD_KSLOT = (XB - 4.6, XB - 0.1, 2.4, 0.5)   # E2: knuckle-top slot x0, x1, half y, vertical edge R
LEAD_FSLOT = (XB - 4.6, XB - 0.1, 11.2, 40.0, HZ + 7.0, 2.2)   # floor slot x0, x1, flare-line half y at HZ, flare deg, top z, R
LEAD_LAND = 3.0                   # integration: vertical land of the slot end walls above the head bottom (no feather edge)
LEAD_ZRUN = 10.4                  # integration: head-local z of the level lead run (pad top 8.5 + 0.6 + LEAD_R)
LEAD_ZTURN = 7.5                  # integration: head-local z where the lead turns to -X inside the vault over the slot
LEAD_RISE = (-7.0, -13.0)         # integration: head-local x range where the run climbs from LEAD_ZTURN to LEAD_ZRUN (after the mouth)
HOOD_CL, HOOD_T = 0.5, 1.3        # integration: vault clearance above the lead envelope / wall thickness
HOOD_R = (HZ - AXZ + LEAD_ZTURN + LEAD_R + HOOD_CL, HZ - AXZ + LEAD_ZTURN + LEAD_R + HOOD_CL + HOOD_T)   # 19.8 / 21.1 about the hinge axis
HOOD_X = (-6.0, XB - 0.1, 14.0)   # integration: vault mouth x (open, toward the bridge), inner end (= slot edge), end wall to the pad face
PLUG_Z = (AXZ + 8.4, AXZ + 9.7)   # integration: black foam plug in the knuckle lead slot (0.5 above the nub, below the R10 surface)
LEAD_TURN = (-41.0, 7.0)          # integration: head-local x of the turn behind the bridge, y of the return run
LEAD_PIN, WIRE_PIN = 4, 2         # integration: header pins where the modelled servo lead / head-wire group end
WIRE_LOOP = (12.5, 19.0)          # integration: head-wire service loop: head-local z of the low leg, y of the U-turn
WIRE_PLUG_Y = -4.5                # integration: rear end of a Dupont housing (14 long) plugged into the header (top y -18.5)
# ---- +X hinge side
BRG_X0, BRG_X1 = 16.0, 18.5       # MR85 5x8x2.5
SLV = (16.5, LUG0, 4.04, 5.54)    # lug sleeve x0, x1 (lug inner face), bore r (D8.08 = 0.04 epoxy gap), outer r
CB_X, CB_R = 15.75, 5.9           # E2: knuckle counterbore floor (0.25 to the MR85 outer ring, was 0.20) / radius
BOSS = (3.1, 16.0)                # inner-ring stop boss r / end x (stands 0.25 on the counterbore floor)
PIN_X0, PIN_X1 = 13.4, 18.5       # E2: hollow pin 4.99/3 starts BEHIND the longer pocket (glued 13.4..16.0)
PIN_R, SEAT_R, SEAT_X0 = 2.495, 2.55, 13.3   # pin OD 4.99 h6; seat r2.55 about the axis WHEN CLOSED (epoxy gap)
PIN_FLAT, SEAT_FLAT = 15.0, 14.9  # D-flat end x on the pin / in the seat (pin flat 1.6 > seat flat -> -X stop)
PIN_SLOT = (2.2, 2.2)             # E2: open end slot (-Z side) width y (2 x D0.85 abreast + 0.5), length x
CHAM = (12.0, CB_X - 1.2, 2.0, AXZ - 1.9)   # E2: head-wire chamber x0, x1, half-width y (4 x D0.85 in a row), top z
CHAM_N = 1.25                     # E2: half-width of the chamber neck under the pin slot (2 x D0.85 abreast)
WB = (13.8, 1.5)                  # static wire bend: vertical leg x, bend radius (centre 15.3, AXZ-1.5)
WIRE_R = 0.6                      # E2: modelled head-wire group (4 x D0.85: flat row in the slots, 2 x 2 in the pin)
LCH_X = 20.5                      # wire slot centre x in the +X lug -> rotating bend R = 20.5-18.5 = 2.0
LCH_X2 = 20.3                     # slot centre x inside the tenon (walls 1.2/1.2); tilted 20.5 -> 20.3 between LCH_ZJ
LCH_ZJ = (AXZ + 8.6, HZ - 0.5)    # E2: z range of the tilted transition: above the lip groove (r 8.4), ends at the tenon base
LCH_W = (0.8, 0.0, 2.4)           # E2: slot half-width x, centre-line y range (slot 1.6 x 4.0, y -0.8..3.2)
LCH_Z0 = 21.3                     # lug chamber end x (outer wall 1.2)
LCH_R = 3.3                       # E2: lug chamber r (was 3.2): 0.3 to the static MR85 inner ring, shoulder r3.3..4.04
LIP = (6.8, 8.0, -18.2)           # -X knuckle lip ring r0, r1, tip x (E2: with the 0.3 seam)
GROOVE = (6.3, 8.4, -18.5)        # cap groove r0 (= plug r), r1, bottom x (PTFE ring 0.25 on the bottom)
PTFE = (6.5, 8.2, 0.25)           # E2: klzny_kruzok r0, r1, thickness (runs on the lip tip: 0.05 axial float)
LIP_P = (6.8, 8.0, 18.1)          # E2: +X knuckle lip ring (hides the sleeve), tip x
GROOVE_P = (6.4, 8.4, 18.4)       # E2: groove in the +X lug face
PLUG = (6.3, -16.9, 4.6)          # E2: cap plug into the knuckle bore: r, tip x, half height |dz| (2 cheeks)
RIB = (0.35, 2.75, 3.5)           # crush rib r, centre |y|, centre |dz|  (protrudes 0.1 into the 5.0 slot)
ARM_TOP = (8.9, 9.6, 10.3)        # E2: horn arm top above the case top: min / nominal / max accepted without rework
CAP_SLOT_X1 = XC - ARM_TOP[2] - XDAT - 0.25   # E2: arm slot bottom (-20.5): 0.25 behind the highest arm top
CAP_HEAD_X1 = -LUG1 + 1.0         # E2: horn-screw head bore bottom (-21.5): blind cap end wall 1.0
RIB_X = (PLUG[1] - 0.01, PLUG[1] - 0.2, CAP_SLOT_X1 + 0.3)   # rib lead-in start / full radius from / to
LUG_ER, LUG_BR = 3.0, 4.0         # E2: lug end-face round R (blade corner R3, collar slot R3.25) / web-barrel blend R
WEB_Y = 8.25                      # web half width.  INTEGRATION (E9): 0.25 wider than the tenon (8.0) so the web also covers the
                                  # 0.1 clearance strip of the floor slot (|y| 8.0..8.1): a cross-screw shank and the display board
                                  # were visible through that slit (0.02 mm2); the 0.25 shoulder lies in the 0.1 gap under the floor
# ---- neck exterior
BLADE_R = 3.0                     # E2: vertical blade corners + rolling-ball saddle fillet
# ---- neck fasteners
NSCR = [(-15.0, ZB + 6.0), (5.0, ZB + 6.0), (17.8, -2.5)]       # M2x12 along +Y (R3: 3rd = new, +X side)
OBL = (-14.2, -2.4, 28.0)         # E2: 4th screw OBLIQUE (x, z at the front face, rise deg), lowered 2.7: crosses the
                                  # parting plane at z 2.9; insert hole 1.25 from the keyhole lobe relief (bottom z 6.7)
DOWELS = [(-5.0, ZB + 3.5), (19.0, 3.0)]                         # D2 steel (R3: 1st moved down)
DOWEL_R = (1.01, 1.0)             # R5: hole r FRONT half (D2.02 slip) / BACK half (D2.0, reamed, dowel EPOXIED)
CLOSE = 0.05                      # R4: each half is moved this much toward y=0 (parting gap 0.1 closed) in halves()
VCH = 0.15                        # E2: parting-line V: chamfer 0.15 x 45 on both halves


def rbox(x0, x1, y0, y1, z0, z1, r=0.0, axis=Axis.Z):
    b = Pos((x0 + x1) / 2, (y0 + y1) / 2, (z0 + z1) / 2) * Box(x1 - x0, y1 - y0, z1 - z0)
    return fillet(b.edges().filter_by(axis), r) if r > 0 else b


def prism_x(pts, x0, x1):
    """extrude a closed (y, z) polygon from x0 to x1"""
    w = Polyline(*[(x0, y, z) for y, z in pts], close=True)
    return extrude(Face(w), amount=x1 - x0, dir=(1, 0, 0))


def servo(dx=0.0, w=12.2, L=22.8, h=22.5, tur=TUR_H, lobe=LOBE, nub_x=None, boss_r=5.9):
    """MG90S (E2, per the user's drawing + photos): case h 22.5 (X: bottom cover XB -> gear face XC) x w 12.2 (Y) x
    L 22.8 (Z, far end on the pocket floor), R0.5 long edges; KEYHOLE turret = boss r5.9 on the spline axis + lobe r2.9
    at 5.6 toward the case centre (-Z), both tur = 6.0 high (turret top 28.5 above the bottom cover); spline D4.8 x 3.0
    with the M2 hole (top 31.5); lead strain-relief nub 2 x 4 x 2 on the END FACE NEAREST THE SHAFT (pocket top,
    z = AXZ+5.9), next to the bottom cover; BOTH mounting tabs cut off flush.  Parameters = envelope variants (E5)."""
    xt = XC + dx
    xb = xt + h
    case = rbox(xt, xb, -w / 2, w / 2, SZ0, SZ0 + L, 0.5, Axis.X)
    r, d = lobe
    tur_ = (xcyl(boss_r, xt - tur, xt + 0.01, 0, AXZ) + xcyl(r, xt - tur, xt + 0.01, 0, AXZ - d) +
            rbox(xt - tur, xt + 0.01, -r, r, AXZ - d, AXZ))
    spl = xcyl(2.4, xt - tur - 3.0, xt - tur + 0.01, 0, AXZ) - xcyl(0.8, xt - tur - 3.1, xt - tur, 0, AXZ)
    n0, n1, ny, nh = NUB
    if nub_x is not None:
        n0, n1 = nub_x
    nub = rbox(n0 + dx, n1 + dx, -ny, ny, SZ0 + L - 0.3, SZ0 + L + nh)
    return case + tur_ + spl + nub


def servo_pocket():
    """E2 pocket: X datum = gear face on the -X wall (XC-0.05), +X end XB+0.75 (2 foam pads 1.0 on that wall push the
    case to the datum: case height 22.4..23.0); Y +-6.2 with the R3 foam strips; Z floor = datum, roof +0.15.
    Keyhole bore to the common floor BOSS_FLOOR: boss r6.05 + lobe relief stadium r3.3 from the axis to centre distance
    6.5 (covers lobe centre 5.0..6.5, r <= 3.1 with 0.2).  -X knuckle end: OPEN bore r6.65 (no end wall inside it:
    the horn arms + the cap plug run there, nothing static within 0.3 of the arms for arm top 8.9..10.3).
    No tab slot, no bump relief, no lead channel."""
    case = rbox(XC - XDAT, XB + XEND, -6.1 - GY, 6.1 + GY, SZ0 - Z_FLOOR, SZ1 + G, 0.5, Axis.X)
    return case + keyhole_bore() + xcyl(BORE_R, -KN - 0.5, BOSS_FLOOR + 0.01, 0, AXZ) + foam_recess()


def keyhole_bore():
    r, d1 = LOBE_REL
    return (xcyl(5.9 + G, BOSS_FLOOR, XC, 0, AXZ) + xcyl(r, BOSS_FLOOR, XC, 0, AXZ - d1) +
            rbox(BOSS_FLOOR, XC, -r, r, AXZ - d1, AXZ))


def head_chamber():
    """E2: head-wire chamber beside the servo bottom cover: x 12.0..14.55, |y| <= 2.0 (4 x D0.85 in a row) from the neck
    bottom up to AXZ-4.6, then a funnel to the 2.5 wide neck (|y| <= 1.25) that opens into the pin seat under the
    pin's end slot (the full width would leave 0.1-0.3 flaps under the seat r2.55)"""
    w, n, zt = CHAM[2], CHAM_N, CHAM[3]
    pts = [(-w, ZB - 1.0), (w, ZB - 1.0), (w, AXZ - 4.6), (n, AXZ - 2.8), (n, zt), (-n, zt), (-n, AXZ - 2.8), (-w, AXZ - 4.6)]
    return prism_x(pts, CHAM[0], CHAM[1])


def lead_slot():
    """E2 C2: slot through the knuckle top above the pocket roof on the parting plane (x XB-4.6..XB-0.1, |y| <= 2.4,
    vertical edges R0.5): the lead nub + lead drop in when the halves close"""
    x0, x1, hy, r = LEAD_KSLOT
    return rbox(x0, x1, -hy, hy, SZ1 - 0.5, AXZ + RK + 1.0, r, Axis.Z)


def foam_recess():
    """R3: 0.3 deep recess for the foam strip on each large (Y) pocket face, low on the case (far from the shaft)"""
    d, _, _, x0, x1, z0, z1 = FOAM
    w = 6.1 + GY
    return rbox(x0, x1, -w - d, -w + 0.01, z0, z1, 0.5, Axis.Y) + rbox(x0, x1, w - 0.01, w + d, z0, z1, 0.5, Axis.Y)


def foam():
    """pena_serva: R3 2 x closed-cell PU foam strip (PORON 0.5, self-adhesive) on the Y faces, drawn COMPRESSED (0.35)
    + E2 2 x pad 3.4 x 12 x 1.0 (free) on the +X pocket wall beside the wire chamber, drawn compressed to the nominal
    gap 0.75 (case 22.4 -> 0.90 incl. the datum gap, 23.0 -> 0.30)"""
    _, _, tc, x0, x1, z0, z1 = FOAM
    y0, y1, pz0, pz1, _ = PADX
    return Compound([rbox(x0 + 0.2, x1 - 0.2, -6.1 - tc, -6.1, z0 + 0.2, z1 - 0.2, 0.3, Axis.Y),
                     rbox(x0 + 0.2, x1 - 0.2, 6.1, 6.1 + tc, z0 + 0.2, z1 - 0.2, 0.3, Axis.Y),
                     rbox(XB, XB + XEND, y0, y1, pz0, pz1, 0.3, Axis.X),
                     rbox(XB, XB + XEND, -y1, -y0, pz0, pz1, 0.3, Axis.X)])


def horn(top=ARM_TOP[1], hub_h=3.3, dx=0.0):
    """stock MG90S 2-arm horn trimmed to 12 mm tip-to-tip: hub OD7 x hub_h, arms 5 wide x 1.6 thick (flush with the
    hub top) along Z at rest; spline bore + D2 screw hole.  top = arm top above the case top (8.9 / 9.6 / 10.3)"""
    xa = XC + dx - top
    hub = xcyl(3.5, xa, xa + hub_h, 0, AXZ)
    arms = Pos(xa + 0.8, 0, AXZ) * Box(1.6, 5.0, 7.0) + xcyl(2.5, xa, xa + 1.6, 0, AXZ + 3.5) + \
        xcyl(2.5, xa, xa + 1.6, 0, AXZ - 3.5)
    return hub + arms - xcyl(2.4, xa + 0.6, xa + hub_h + 0.1, 0, AXZ) - xcyl(1.0, xa - 0.1, xa + 0.7, 0, AXZ)


def horn_screw(top=ARM_TOP[1], dx=0.0):
    xa = XC + dx - top
    return xcyl(1.9, xa - 1.2, xa, 0, AXZ) + xcyl(0.8, xa, xa + 3.6, 0, AXZ)


def neck_void_dict():
    """named voids of the neck (used by halves() and by the wall checks)"""
    v = dict(case_pocket=servo_pocket(),
             lead_slot=lead_slot(),                                            # E2: servo lead UP into the head
             head_chamber=head_chamber(),
             pin_seat=pin_seat(),
             counterbore=xcyl(CB_R, CB_X, KN + 0.5, 0, AXZ) - xcyl(BOSS[0], CB_X - 0.1, BOSS[1], 0, AXZ))
    for i, (x, z) in enumerate(NSCR):
        v[f"screw_cbore_{i}"] = ycyl(2.1, -BT / 2 - 1, -BT / 2 + 2.0, x, z)
        v[f"screw_clear_{i}"] = ycyl(1.2, -BT / 2, 0.1, x, z)
        v[f"insert_hole_{i}"] = ycyl(1.7, -0.1, 3.6, x, z) + ycyl(1.2, 3.5, 5.0, x, z)   # R3: insert bottoms at 3.6, pilot
    i, sp = len(NSCR), OBL_SP()
    v[f"screw_cbore_{i}"] = ocyl(2.1, -1.5, OBL_HEAD[1])
    # R4: the oblique holes now end/start EXACTLY on the parting plane (clipped by y=0) - their tilted end discs used to
    # leave 0.05-0.5 resin wedges at the parting face of both halves
    v[f"screw_clear_{i}"] = ocyl(1.2, OBL_HEAD[1] - 0.01, sp + 1.0) & _side_box(-1)
    i0, i1 = OBL_INS                                  # E2: insert seat ends at sp + 4.0 (was 5.3), pilot to OBL_PIL
    v[f"insert_hole_{i}"] = (ocyl(1.7, sp - 1.0, sp + i1 + 0.1) & _side_box(1)) + ocyl(1.2, sp + i1, sp + OBL_PIL)
    for i, (x, z) in enumerate(DOWELS):
        v[f"dowel_hole_{i}"] = ycyl(DOWEL_R[0], -3.2, 0.0, x, z) + ycyl(DOWEL_R[1], 0.0, 3.2, x, z)   # R4 slip | press
    return v


OBL_HEAD = (1.4, 3.0)              # R5: ISO 7045 pan head top (k 1.6) / bearing face along the oblique axis (0.4 deeper)
OBL_LEN = 12.0                     # E2: the oblique screw is an M2x12 too (4 equal neck screws)
OBL_INS = (0.9, 3.9)               # E2: insert position behind the parting plane along the axis (full cylindrical seat)
OBL_PIL = 4.6                      # E2: pilot / screw-tip clearance end (screw tip at sp + 3.67)


def OBL_SP():
    """axial distance from the front-face point to the parting plane y=0"""
    return (BT / 2) / math.cos(math.radians(OBL[2]))


def ocyl(r, s0, s1):
    """cylinder on the oblique screw axis (from the front-face point (x, -BT/2, z), direction (0, cos a, sin a))"""
    x, z, a = OBL
    return Location((x, -BT / 2, z)) * Rot(a - 90, 0, 0) * Pos(0, 0, (s0 + s1) / 2) * Cylinder(r, s1 - s0)


def neck_voids():
    return list(neck_void_dict().values())


def lip(sx=-1):
    """static lip ring on a knuckle end (r6.8..8.0): -X runs in the cap groove (hides the horn, carries the PTFE thrust
    ring); E2: the same on +X in a groove of usko_lozisko (hides the sleeve through the 0.3 seam)"""
    r0, r1, xt = LIP if sx < 0 else LIP_P
    xa, xb = sorted((xt, sx * (KN - 0.1)))
    return xcyl(r1, xa, xb, 0, AXZ) - xcyl(r0, xa - 1, xb + 1, 0, AXZ)


def _shoulder(sx):
    """E2 (E1 5.1/5.2): blade end beside the knuckle (|x| 17.5..22.5) as a ROLLING-BALL R3 body: the sharp solid
    (45 x 20 blade minus the R10.5 saddle) eroded by 3 (box |x|<=19.5, |y|<=7 minus cylinder R13.5) and offset back by
    +3 with arc joins -> vertical corners R3, saddle R10.5 concentric for |y| <= 5.44, convex R3 fillets to the
    y=+-10 faces (tangent at z AXZ-11.54) and to the end face x=+-22.5, all G1 (no planar land, no feather edge)."""
    from build123d import offset
    R = BLADE_R
    x_in, x_out = 8.0, BW / 2 - R
    E = Pos(sx * (x_in + x_out) / 2, 0, (ZB - 10 + AXZ) / 2) * Box(x_out - x_in, BT - 2 * R, AXZ - (ZB - 10))
    E = E - xcyl(RK + 0.5 + R, sx * 2, sx * 30, 0, AXZ)
    S = offset(E, amount=R)
    xa, xb = sorted((sx * KN, sx * 40))
    return S & (Pos((xa + xb) / 2, 0, ZB + 50) * Box(xb - xa, 60, 100))


@functools.lru_cache(None)
def _env_core():
    """neck exterior without the lip rings: middle block + knuckle R10 (|x| <= 17.5, flat end faces) + 2 rolling-ball
    shoulders; hidden bottom edge chamfer 0.5"""
    from build123d import chamfer
    mid = Pos(0, 0, (ZB + AXZ) / 2) * Box(2 * KN, BT, AXZ - ZB) + xcyl(RK, -KN, KN, 0, AXZ)
    env = (mid + _shoulder(1) + _shoulder(-1)).solids()[0].clean()
    try:
        eb = [e for e in env.edges() if abs(e.bounding_box().min.Z - ZB) < 1e-6 and abs(e.bounding_box().max.Z - ZB) < 1e-6]
        c = chamfer(eb, 0.5)
        if c.is_valid and len(c.solids()) == 1 and 0 < env.volume - c.volume < 40:
            env = c.solids()[0]
    except Exception as ex:
        print("neck bottom chamfer skipped", ex, flush=True)
    return env


def neck_env():
    """outer envelope of the neck (no holes, no parting V): 45 x 20 blade with R3 corners, rolling-ball R3 saddles
    under the lugs, knuckle R10 |x| <= 17.5, + the two static lip rings (inside the 0.3 hinge seams)"""
    return _env_core() + lip(-1) + lip(1)


def _env_half(sy):
    """one half of the exterior with the parting-line V (E1 5.3): chamfer VCH x 45 deg along the exterior outline of
    the parting face (not on the hidden bottom edge and not on the knuckle end faces inside the hinge seams)"""
    from build123d import chamfer, GeomType
    h = (_env_core() & _side_box(sy)).solids()[0]
    pf = max([f for f in h.faces() if f.geom_type == GeomType.PLANE and abs(f.center().Y) < 1e-6
              and abs(f.normal_at().Y) > 0.99], key=lambda f: f.area)
    def skip(e):
        bb = e.bounding_box()
        return (bb.max.Z - ZB < 0.6) or (abs(abs(bb.min.X) - KN) < 1e-6 and abs(abs(bb.max.X) - KN) < 1e-6)
    for sel in (lambda e: not skip(e), lambda e: bb_z(e) > ZB + 0.6):
        try:
            c = chamfer([e for e in pf.outer_wire().edges() if sel(e)], VCH)
            if c.is_valid and len(c.solids()) == 1 and 0 < h.volume - c.volume < 5:
                h = c.solids()[0]
                break
        except Exception as ex:
            print("parting V retry", sy, repr(ex)[:80], flush=True)
    return h + (lip(-1) & _side_box(sy)) + (lip(1) & _side_box(sy))


def bb_z(e):
    return e.bounding_box().max.Z


def pin_seat():
    """R3: union of the two half-seats (r2.55 centred 0.05 outward = r2.55 about the axis once the halves close);
    D-flat at z=+2.25 from SEAT_X0 to SEAT_FLAT (pin flat at +2.2 -> 0.05 epoxy gap); open to the pocket at -X"""
    flat = Pos((SEAT_X0 + SEAT_FLAT) / 2 - 0.05, 0, AXZ + 2.25 + 2) * Box(SEAT_FLAT - SEAT_X0 + 0.1, 8, 4)
    return (xcyl(SEAT_R, SEAT_X0, BOSS[1] + 0.1, -0.05, AXZ) + xcyl(SEAT_R, SEAT_X0, BOSS[1] + 0.1, 0.05, AXZ)) - flat


def _side_box(sy):
    return Pos(0, sy * 50, 0) * Box(200, 100, 400)


def closed_voids(sy):
    """R4: the voids of ONE half as they sit when the neck is CLOSED: every void was designed for halves cut 0.05 short
    of y=0 that move 0.05 toward each other on assembly, so for the front half (sy=-1) the voids are moved +0.05 Y and
    for the back half (sy=+1) -0.05 Y.  The outer envelope is NOT moved -> closed neck exactly 45 x 20, knuckle R10."""
    return {k: v.moved(Location((0, -sy * CLOSE, 0))) for k, v in neck_void_dict().items()}


def closed_void_dict():
    """R4: closed-state voids of the whole neck (front-half part + back-half part of every void)"""
    f, b = closed_voids(-1), closed_voids(1)
    out = {}
    for k in f:
        parts = [p for p in (f[k] & _side_box(-1), b[k] & _side_box(1)) if p is not None and p.solids()]
        out[k] = parts[0] if len(parts) == 1 else parts[0] + parts[1]
    return out


def halves():
    """R4: neck halves in the CLOSED (assembled) position: front y -10..0, back y 0..10, touching on y=0; internal
    voids in their closed-state positions (pocket +-6.15, pin seat r2.55 about the axis, insert step y 3.55 ...).
    E2: exterior from _env_half() (R3 blade corners, rolling-ball saddles, parting V 0.3 x 0.15)."""
    out = []
    for sy in (-1, 1):
        h = _env_half(sy)
        for c in closed_voids(sy).values():
            h = h - c
        h = h & _side_box(sy)
        out.append(h.solids()[0] if len(h.solids()) == 1 else h)
    return out[0], out[1]


def xcone(r0, r1, x0, x1, y=0.0, z=0.0):
    """truncated cone along X: radius r0 at x0 -> r1 at x1"""
    from build123d import Cone
    c = Cone(r0, r1, abs(x1 - x0), align=None).rotate(Axis.Y, 90 if x1 > x0 else -90)
    return c.moved(Location((x0, y, z)))


def pin():
    """hollow pin 4.99/3 (ground steel tube, h6) 12.8..18.5: D-flat 0.3 (z=+2.2) 1.6 long at the -X end, open end slot
    1.8 x 2.5 on the -Z side at the -X end (wires enter from below), both bore ends chamfered 0.5 x 45"""
    p = xcyl(PIN_R, PIN_X0, PIN_X1, 0, AXZ) - xcyl(1.5, PIN_X0 - 1, PIN_X1 + 1, 0, AXZ)
    p = p - Pos((PIN_X0 + PIN_FLAT) / 2 - 0.1, 0, AXZ + 2.2 + 2) * Box(PIN_FLAT - PIN_X0 + 0.2, 8, 4)
    w, d = PIN_SLOT
    p = p - Pos(PIN_X0 + d / 2 - 0.1, 0, AXZ - 2.0) * Box(d + 0.2, w, 2.0)
    p = p - xcone(2.0, 1.4, PIN_X1 + 0.001, PIN_X1 - 0.6, 0, AXZ) - xcone(2.0, 1.4, PIN_X0 - 0.001, PIN_X0 + 0.6, 0, AXZ)
    return p.solids()[0] if len(p.solids()) == 1 else p


def bearing():
    """MR85 as 2 rings (outer turns with the lug, inner static on the pin)"""
    outer = xcyl(4.0, BRG_X0, BRG_X1, 0, AXZ) - xcyl(3.55, BRG_X0 - 1, BRG_X1 + 1, 0, AXZ)
    inner = xcyl(3.0, BRG_X0, BRG_X1, 0, AXZ) - xcyl(2.5, BRG_X0 - 1, BRG_X1 + 1, 0, AXZ)
    return outer, inner


def neck_fasteners():
    """3 x M2x12 pan (head in a D4.2x2 counterbore of the front half) into glue-in knurled inserts M2 (OD3.2 x 3, hole
    D3.4 x 4) in the back half; 2 x D2x6 steel dowels"""
    scr, ins = [], []                     # R4: screws ride with the closed FRONT half (+0.05), inserts with the BACK (-0.05)
    for x, z in NSCR:
        scr.append(ycyl(2.0, -BT / 2 + 0.4, -BT / 2 + 2.0, x, z) + ycyl(0.8, -BT / 2 + 2.0, 4.0, x, z))   # R5: ISO 7045
        ins.append(ycyl(1.6, 0.6, 3.6, x, z) - ycyl(1.0, 0, 4, x, z))                  # R3: on the hole step
    sp, h0, h1 = OBL_SP(), OBL_HEAD[0], OBL_HEAD[1]
    scr.append(ocyl(2.0, h0, h1) + ocyl(0.8, h1, h1 + OBL_LEN))                       # E2: ISO 7045 M2x12 (k 1.6)
    ins.append(ocyl(1.6, sp + OBL_INS[0], sp + OBL_INS[1]) - ocyl(1.0, sp, sp + OBL_INS[1] + 0.2))   # on the hole step
    out = [s.moved(Location((0, CLOSE, 0))) for s in scr] + [s.moved(Location((0, -CLOSE, 0))) for s in ins]
    dw = [ycyl(1.0, -3.0, 3.0, x, z) for x, z in DOWELS]
    return Compound(out), Compound(dw)


def _lug_prism(x0, x1):
    """E1 4.2: y-z profile of a lug = barrel R10 about the hinge axis + web |y| <= 8.25 (WEB_Y) up to HZ+1.5, concave blend
    R LUG_BR tangent to both (G1), extruded from x0 to x1"""
    from build123d import ThreePointArc, Line, Wire
    Rb, w, rb = RK, WEB_Y, LUG_BR
    zc = math.sqrt((Rb + rb) ** 2 - (w + rb) ** 2)              # blend centre (|y| = w + rb, z = zc) from the axis
    ty, tz = (w + rb) * Rb / (Rb + rb), zc * Rb / (Rb + rb)      # tangent point on the barrel
    am = (math.atan2(tz - zc, ty - (w + rb)) - math.pi) / 2      # mid angle of the blend arc (seen from its centre)
    my, mz = (w + rb) + rb * math.cos(am), zc + rb * math.sin(am)
    zt = HZ + 1.5 - AXZ
    P = lambda y, z: (x0, y, AXZ + z)
    ed = [ThreePointArc(P(-ty, tz), P(0, -Rb), P(ty, tz)), ThreePointArc(P(ty, tz), P(my, mz), P(w, zc)),
          Line(P(w, zc), P(w, zt)), Line(P(w, zt), P(-w, zt)), Line(P(-w, zt), P(-w, zc)),
          ThreePointArc(P(-w, zc), P(-my, mz), P(-ty, tz))]
    return extrude(Face(Wire(ed)), amount=x1 - x0, dir=(1, 0, 0))


def tenon_box(sx, grow=0.0, z0=None, z1=None):
    """tenon 4 x 16 (grow = 0) / head floor slot (grow = 0.1): vertical corners R1.0 on the inner side, R2.9 on the
    outer side (inside the R3 web round, so the slot mouth is covered by the web)"""
    t0, t1, ty = TEN[:3]
    z0, z1 = (TEN[3] if z0 is None else z0), (TEN[4] if z1 is None else z1)
    xa, xb = sorted((sx * (t0 - grow), sx * (t1 + grow)))
    b = Pos((xa + xb) / 2, 0, (z0 + z1) / 2) * Box(xb - xa, 2 * (ty + grow), z1 - z0)
    b = fillet([e for e in b.edges().filter_by(Axis.Z) if abs(e.center().X) > (t0 + t1) / 2], TEN_R[1] + grow)
    return fillet([e for e in b.edges().filter_by(Axis.Z) if abs(abs(e.center().X) - (t0 - grow)) < 1e-6], TEN_R[0] + grow)


def lug_blank(sx):
    """E2 lug exterior (E1 4): barrel R10 + web +-8.25 with the concave blend, outer end face x = +-22.5 flat with a
    rolling R3 round all around (barrel->face and web->face; R3 = blade corner, so the barrel passes the collar slot
    R3.25 with 0.25), top = head bottom - 0.1, + tenon into the head floor slot.  No aprons."""
    x0, x1 = sorted((sx * LUG0, sx * LUG1))
    base = _lug_prism(x0, x1)
    lug = None
    for r in (LUG_ER, 2.5, 2.0):
        try:
            fo = [f for f in base.faces() if abs(f.center().X - sx * LUG1) < 1e-3 and abs(abs(f.normal_at().X) - 1) < 1e-6][0]
            l = fillet([e for e in fo.edges() if e.center().Z < HZ + 1.4], r)
            if l.is_valid and len(l.solids()) == 1:
                lug = l
                if r != LUG_ER:
                    print("lug end round fallback R", r, flush=True)
                break
        except Exception as ex:
            print("lug end round R", r, "failed", repr(ex)[:80], flush=True)
    lug = (base if lug is None else lug) - HC.head_outer(HZ - 0.1)
    return lug + tenon_box(sx)


def groove_holes(sx, r=0.8):
    return [ycyl(r, -TEN[2] - 0.1, -2.0, sx * x, ZS) for x in SCR_X]


def rib(y, z):
    """R5: crush rib along -X: lead-in cone from r(flush)=RIB_r-0.1 at the slot mouth to RIB_r, then full radius"""
    r, _, _ = RIB
    x0, x1, x2 = RIB_X
    return xcone(r - 0.1, r, x0 + 0.01, x1, y, z) + xcyl(r, x2, x1 + 0.01, y, z)


def cap():
    """-X lug CAP (usko_kryt), E2: + PLUG (2 cheeks r6.3, |dz| <= 4.6) reaching into the open knuckle bore to
    x -16.9, so the arm slot 5.0 x 12.4 (4 crush ribs 0.1 over x -17.1..-20.2) holds the horn arms over their full
    thickness for arm top 8.9..10.3 above the case top; slot bottom x -20.5, hub clearance r3.9, screw-head bore r2.3
    to x -21.5 (blind end wall 1.0); groove r6.3..8.4 to x -18.5 for the static lip ring + the PTFE thrust ring"""
    pr, px, pz = PLUG
    c = lug_blank(-1) + (xcyl(pr, px, -LUG0 - 0.5, 0, AXZ) & (Pos(-18, 0, AXZ) * Box(6, 20, 2 * pz)))
    xs0, xs1 = px + 0.01, CAP_SLOT_X1
    slot = Pos((xs0 + xs1) / 2, 0, AXZ) * Box(abs(xs1 - xs0), 5.0, 7.4) + \
        xcyl(2.5, xs0, xs1, 0, AXZ + 3.7) + xcyl(2.5, xs0, xs1, 0, AXZ - 3.7)
    rr, ry, rz = RIB
    for sy in (-1, 1):
        for sz in (-1, 1):
            slot = slot - rib(sy * ry, AXZ + sz * rz)
    g0, g1, gx = GROOVE
    groove = xcyl(g1, -LUG0 + 0.01, gx, 0, AXZ) - xcyl(g0, -LUG0 + 1, gx - 1, 0, AXZ)
    c = c - slot - groove - cap_slot_trim() - xcyl(3.9, xs0, xs1, 0, AXZ) - xcyl(2.3, xs1 + 0.01, CAP_HEAD_X1, 0, AXZ)
    for g in groove_holes(-1):
        c = c - g
    return c.solids()[0] if len(c.solids()) == 1 else c


def cap_slot_trim():
    """inside the groove depth + plug (x -18.5..-16.9) everything within r 6.3 beyond |dz| 4.6 is removed: the slot
    ends (r 6.2) would leave 0.1 slivers against the groove inner wall / plug surface -> 2 clean cheeks >= 1.8 thick"""
    pr, px, pz = PLUG
    x0, x1 = GROOVE[2], px + 0.01
    boxes = rbox(x0, x1, -7, 7, AXZ + pz, AXZ + 7.0) + rbox(x0, x1, -7, 7, AXZ - 7.0, AXZ - pz)
    return xcyl(pr + 0.005, x0, x1, 0, AXZ) & boxes


def ptfe_ring():
    """klzny_kruzok (group H): PTFE washer 13.0 x 16.4 x 0.25 bonded on the bottom of the cap groove; it runs on the
    tip of the static -X lip ring (0.05 gap) = +X thrust stop of the head (-X stop: MR85 inner ring on its boss)"""
    r0, r1, t = PTFE
    return xcyl(r1, GROOVE[2], GROOVE[2] + t, 0, AXZ) - xcyl(r0, GROOVE[2] - 1, GROOVE[2] + 1, 0, AXZ)


def _slot_xy(xc, z0, z1):
    hw, y0, y1 = LCH_W
    return rbox(xc - hw, xc + hw, y0 - hw, y1 + hw, z0, z1, hw - 0.01, Axis.Z)


def lug_channel():
    """E2: head-wire SLOT 1.6 (x) x 4.0 (y -0.8..3.2) in the +X lug for 4 x D0.85 wires in a row (1.3 x 3.7 left after
    0.15 print shrink per wall): centre x 20.5 from the chamber to AXZ+8.6, lofted to x 20.3 at the tenon base, x 20.3
    through the tenon (walls 1.2 / 1.2); offset to the back so it stays 1.5 from the cross-screw pilots (y <= -2)"""
    za, zb = LCH_ZJ
    lo, up = _slot_xy(LCH_X, AXZ, za + 0.01), _slot_xy(LCH_X2, zb - 0.01, TEN[4] + 1)
    w0 = lo.faces().sort_by(Axis.Z)[-1].outer_wire()
    w1 = up.faces().sort_by(Axis.Z)[0].outer_wire()
    return lo + Solid.make_loft([w0, w1]) + up


def lug_plus():
    """+X lug (usko_lozisko): SLEEVE r4.04..5.54 x16.5..17.8 (MR85 outer ring glued in, bore to 18.5 = ring stop),
    wire chamber r3.3 x18.5..21.3, wire slot (lug_channel) to the tenon top; E2: groove r6.4..8.4 x17.8..18.4 for the
    static +X lip ring.  No aprons, no pegs."""
    l = lug_blank(1)
    s0, s1, sr0, sr1 = SLV
    l = l + xcyl(sr1, s0, s1 + 0.3, 0, AXZ)
    g0, g1, gx = GROOVE_P
    l = l - (xcyl(g1, LUG0 - 0.01, gx, 0, AXZ) - xcyl(g0, LUG0 - 1, gx + 1, 0, AXZ))
    l = l - xcyl(sr0, s0 - 0.01, BRG_X1, 0, AXZ) - xcyl(LCH_R, BRG_X1 - 0.01, LCH_Z0, 0, AXZ)
    l = l - lug_channel()
    for g in groove_holes(1):
        l = l - g
    return l.solids()[0] if len(l.solids()) == 1 else l


def head_floor_z(x, y):
    """lowest z of the head exterior on the vertical line (x, y)"""
    return (HC.head_outer(HZ) & zcyl(0.005, HZ - 5, HZ + 10, x=x, y=y)).bounding_box().min.Z


def slot_mouth_break(sx):
    """E1 4.5: 0.3 x 45 deg break on the tenon-slot mouth in the head floor (frustum cut, floor height taken from the
    head exterior at the slot centre, so it follows any floor shape)"""
    zf = head_floor_z(sx * (TEN[0] + TEN[1]) / 2, 0.0)
    a = tenon_box(sx, 0.1 + 0.8, zf - 0.6, zf - 0.5).faces().sort_by(Axis.Z)[0].outer_wire()
    b = tenon_box(sx, 0.1, zf + 0.3, zf + 0.4).faces().sort_by(Axis.Z)[0].outer_wire()
    return Solid.make_loft([a, b])


def lead_floor_slot():
    """E2 C2: servo-lead slot through the head floor: x XB-4.6..XB-0.1 (the floor travels +-8.8 past the static lead at
    +-40 deg), end walls flared 40 deg so a straight lead clears them through the whole floor thickness; corner
    edges R2.2.  INTEGRATION: the flare starts LEAD_LAND = 3.0 above the head bottom; below it the end walls are
    vertical at |y| = 11.2 + 3.0 tan40 = 13.72 (never closer to the lead than the plain flare).  With the flare
    running down to the exterior, the back end wall met the rising floor of the W110 x H79 head in a 38 deg feather
    edge (ray-cast wall 0.01..1.0 at y 11.9..13; with a 2.0 land still 0.9); now the land is 1.6 high at the back
    (floor exterior at local z 1.4 there), the front end wall is vertical through the whole 2.5 floor."""
    x0, x1, hy, a, zt, r = LEAD_FSLOT
    t = math.tan(math.radians(a))
    zb, zl = HZ - 1.0, HZ + LEAD_LAND
    L = lambda z: hy + (z - HZ) * t
    c = prism_x([(-L(zl), zb), (L(zl), zb), (L(zl), zl), (L(zt), zt), (-L(zt), zt), (-L(zl), zl)], x0, x1)
    ed = [e for e in c.edges() if abs(e.tangent_at(0.5).X) < 0.1 and abs(e.tangent_at(0.5).Z) > 0.5 and e.length > 1.0]
    f = fillet(ed, r)
    if not (f.is_valid and len(f.solids()) == 1 and len(ed) == 8):
        raise RuntimeError("lead_floor_slot fillet failed")
    # the slot lies under the vault (lead_hood): nothing is cut beyond the vault's inner radius
    f = f & xcyl(HOOD_R[0], x0 - 1.0, x1 + 1.0, 0, AXZ)
    return f.solids()[0] if len(f.solids()) == 1 else f


def lead_hood():
    """INTEGRATION (E9): vault over the servo-lead floor slot, part of the white shell (paint its inside matt black).
    Through the open slot the display board, the carrier bars, an LED board and the cross-screw heads could be seen
    from below / behind (up to 29 mm2 at +-40 deg).  The vault is a cylindrical shell CONCENTRIC with the hinge axis
    (inner r 19.8 = lead envelope r 19.3 + 0.5, wall 1.3, top at local z 10.6): the static lead sweeps under it at
    constant clearance for every tilt.  +X end closed by an end wall against the +X pad (x 12.5..14.0), -X end = open
    mouth at x -6 (inner edge R0.6) through which the lead leaves toward the cable bridge.  Every sight line through
    the slot ends on the vault / end wall or leaves the mouth too low to reach an internal part."""
    x0, x1, x2 = HOOD_X
    ri, ro = HOOD_R
    tube = xcyl(ro, x0, x2, 0, AXZ) - xcyl(ri, x0 - 1.0, x1, 0, AXZ)
    try:
        from build123d import GeomType
        ce = [e for e in tube.edges() if e.geom_type == GeomType.CIRCLE and abs(e.center().X - x0) < 1e-6]
        inner = [e for e in ce if abs(e.radius - ri) < 1e-6]
        outer = [e for e in ce if abs(e.radius - ro) < 1e-6]
        t2 = fillet(inner, 0.6)
        oe = [e for e in t2.edges() if e.geom_type == GeomType.CIRCLE and abs(e.center().X - x0) < 1e-6 and abs(e.radius - ro) < 1e-6]
        t2 = fillet(oe, 0.4)
        if t2.is_valid and len(t2.solids()) == 1:
            tube = t2
        else:
            print("lead_hood: mouth round skipped (invalid)", flush=True)
    except Exception as ex:
        print("lead_hood: mouth round skipped", repr(ex)[:80], flush=True)
    h = HC.clip_inside(tube & (Pos(0, 0, HZ + 9.0) * Box(80, 60, 20.0)), HZ)
    return h.solids()[0] if len(h.solids()) == 1 else h


def lead_plug():
    """INTEGRATION (E9): black closed-cell foam plug 4.5 x 4.7 x 1.3 (cut a little oversize, with a slit for the lead),
    pressed into the knuckle lead slot around the sleeved lead, 0.5 above the nub and just below the knuckle surface:
    with the head tilted +-40 deg the servo end face was visible through the slot from 3/4 above (up to 4.7 mm2).
    Modelled as filling the CLOSED slot exactly (x 8.0..12.5, |y| <= 2.35, corners R0.5) around the lead tube."""
    x0, x1, hy, r = LEAD_KSLOT
    p = rbox(x0, x1, -hy + CLOSE, hy - CLOSE, PLUG_Z[0], PLUG_Z[1], r, Axis.Z)
    return p - zcyl(LEAD_R, PLUG_Z[0] - 1, PLUG_Z[1] + 1, x=LEAD_X)


def head_pads_and_cuts():
    """adds / cuts for HC.head_shell() - GENERIC: only HC.head_outer() and HC.clip_inside() of the head module are used
    (see E2 INTERFACE at the top).  adds = [pad -X, pad +X, lead vault]; cuts = tenon slots with mouth breaks, pilot /
    clearance holes, servo-lead floor slot.  No apron-peg holes."""
    adds, cuts = [], []
    for sx in (-1, 1):
        xa, xb = sorted((sx * PAD[0], sx * PAD[1]))
        adds.append(HC.clip_inside(rbox(xa, xb, -PAD[2], PAD[2], HZ - 1.0, TEN[4]), HZ))
        cuts.append(tenon_box(sx, 0.1, HZ - 1.5, TEN[4] + 0.5))
        cuts.append(slot_mouth_break(sx))
        cuts += groove_holes(sx)
        # inner screw: clearance D2.2 through the R1.1 slot-corner zone (to y -6.9), as R4
        cuts.append(ycyl(1.1, -PAD[2] - 0.6, -TEN[2] + 1.1, sx * SCR_X[0], ZS))
        # E2 outer screw: the slot corner is R3.0 there -> clearance D2.2 to the end of the corner zone (y -5.1) + a
        # 2.0 high pocket joining it to the slot corner (no resin wedge between the hole and the curved slot wall)
        yc = -(TEN[2] + 0.1 - (TEN_R[1] + 0.1))
        cuts.append(ycyl(1.1, -PAD[2] - 0.6, yc, sx * SCR_X[1], ZS))
        xa, xb = sorted((sx * (TEN[1] + 0.1 - (TEN_R[1] + 0.1)), sx * SCR_X[1]))
        cuts.append(rbox(xa, xb, -TEN[2] - 0.1, yc, ZS - 1.0, ZS + 1.0))
    adds.append(lead_hood())                      # integration: vault over the lead slot (fused before the slot is cut)
    cuts.append(lead_floor_slot())
    return adds, cuts


def cross_screws():
    """4 x M2x8 ISO 7380-1 button head, E2: modelled at the standard maximum dk 3.8 x k 1.3 (hex 1.3), thread-forming
    in the D1.6 pilot, along +Y, head on the pad front face y=-11 (axes 4.0 apart -> 0.2 between the heads)"""
    r, k = SCR_HEAD
    return Compound([ycyl(r, -PAD[2] - k, -PAD[2], sx * x, ZS) + ycyl(0.8, -PAD[2], -PAD[2] + 8.0, sx * x, ZS)
                     for sx in (-1, 1) for x in SCR_X])


TOP = 4.0                                   # torso top (collar disc top), static
COLLAR = (26.5, 26.75, 28.25, 28.35)        # E2: disc r, ring inner r (seam 0.25), ring outer r, torso recess r (seam 0.1)


def collar():
    """golier (E1 6): disc R26.5 (z -2..4, top flush with the torso) with the 45.5 x 20.5 slot, corners R3.25 (blade
    R3 + 0.25), slot top edge R0.6, disc outer top edge R0.3; ring r26.75..28.25 (0.25 running seam to the disc, 0.1
    glue seam to the torso recess r28.35), outer top edge R0.3"""
    rd, ri, ro, _ = COLLAR
    slot = fillet((Pos(0, 0, TOP - 3) * Box(BW + 0.5, BT + 0.5, 10)).edges().filter_by(Axis.Z), BLADE_R + 0.25)
    disc = (Pos(0, 0, TOP - 3) * Cylinder(rd, 6) - slot).solids()[0]
    top = [e for e in disc.edges() if abs(e.bounding_box().min.Z - TOP) < 1e-6 and abs(e.bounding_box().max.Z - TOP) < 1e-6]
    inner = [e for e in top if e.bounding_box().size.X < 2 * rd - 1]
    outer = [e for e in top if e.bounding_box().size.X >= 2 * rd - 1]
    disc = fillet(inner, 0.6)
    outer = [e for e in disc.edges() if abs(e.bounding_box().min.Z - TOP) < 1e-6 and e.bounding_box().size.X >= 2 * rd - 1]
    disc = fillet(outer, 0.3)
    ring = (Pos(0, 0, TOP - 3) * (Cylinder(ro, 6) - Cylinder(ri, 6.2))).solids()[0]
    eo = [e for e in ring.edges() if abs(e.bounding_box().min.Z - TOP) < 1e-6 and e.bounding_box().size.X >= 2 * ro - 0.1]
    ring = fillet(eo, 0.3)
    return disc, ring


TORSO_RIM = {"r": 0.0}                     # rim round actually achieved by torso() (0 = OCC refused: do it in the torso CAD)


def torso():
    """illustrative torso as exported for B (top_r 29.8, neck well down to z -40), E2: collar recess r28.35 (0.1 glue
    seam to the ring), well 47 x 22 with R4 corners (1.0 around the R3 blade), rim edge R1.0 where OCC allows it"""
    sys.path.insert(0, "/home/user/Robot")
    from nova_v8 import klasik as KL
    KL.K["torso"].update(w=108.0, d=74.0, h=100.0, top_r=29.8)
    t = KL.loft(KL.torso_secs())
    t = t.moved(Location((0, 0, TOP - t.bounding_box().max.Z)))
    t = t - (Pos(0, 0, TOP - 2.995) * Cylinder(COLLAR[3], 6.01))                    # recess floor z=-2 (disc rests on it)
    well = fillet((Pos(0, 0, -21.0) * Box(BW + 2.0, BT + 2.0, 38.2)).edges().filter_by(Axis.Z), BLADE_R + 1.0)
    t = t - well
    try:                                                                            # E1 6.2: rim edge R1.0 (G1 to the dome)
        from build123d import GeomType
        topf = max([f for f in t.faces() if f.geom_type == GeomType.PLANE and abs(f.center().Z - TOP) < 0.01
                    and f.normal_at().Z > 0.99], key=lambda f: f.area)
        for r in (1.0, 0.8, 0.6, 0.4):
            try:
                tf_ = fillet(list(topf.outer_wire().edges()), r)
                if tf_.is_valid and len(tf_.solids()) == 1:
                    t = tf_
                    TORSO_RIM["r"] = r
                    break
            except Exception:
                continue
    except Exception as ex:
        print("torso rim round skipped:", repr(ex)[:80], flush=True)
    return t


def tube(pts, R, r=WIRE_R):
    """wire group: circle swept along a polyline whose corners are filleted with radius R (= bend radius)"""
    from build123d import FilletPolyline, Wire, Plane, Circle, sweep, Vector as V
    w = Wire(FilletPolyline(*pts, radius=R).edges())
    sec = Plane(origin=pts[0], z_dir=(V(*pts[1]) - V(*pts[0])).normalized()) * Circle(r)
    return sweep(sec, path=w)


def cable_paths():
    """kabel, head wires 4 x D0.85 (AWG30 silicone / AWG28 PTFE), modelled as ONE tube r 0.6 on the centre line of the
    group (flat row of 4 in the chamber and in the lug slot, 2 x 2 in the pin bore; passages are sized for the real
    wires - see checks_e2_neck).  STATIC part: neck bottom -> chamber beside the servo bottom cover (x 13.8) -> up
    through the pin's -Z end slot -> bend R1.5 inside the pin bore -> pin end x18.5.  ROTATING part (turns with the
    head): pin end on the hinge axis (pure twist) -> bend R2.0 inside the lug chamber -> lug slot x20.5 -> (tilted)
    x20.3 in the tenon -> tenon top -> display."""
    XJ = BRG_X1 - 0.1                                     # static/rotating joint on the axis (inside the chamfer)
    zl, yl = HZ + WIRE_LOOP[0], WIRE_LOOP[1]
    px, py, pz = HC.header_pin(WIRE_PIN, HZ)              # integration: 5V pin of the display header (mouth faces +Y)
    return [([(WB[0], 0, ZB - 3.0), (WB[0], 0, AXZ), (XJ, 0, AXZ)], WB[1], "N"),
            ([(XJ, 0, AXZ), (LCH_X, 0, AXZ), (LCH_X, 0, LCH_ZJ[0]), (LCH_X2, 0, LCH_ZJ[1]), (LCH_X2, 0, HZ + 9.0)],
             LCH_X - BRG_X1, "H"),
            # integration: tenon top -> up -> service loop to the back (U-turn in the y-z plane) -> header pin 2
            ([(LCH_X2, 0, HZ + 9.0), (LCH_X2, 0, zl), (LCH_X2, yl, zl), (LCH_X2, yl, pz), (px, WIRE_PLUG_Y, pz),
              (px, py, pz)], 1.9, "H")]


def lead_path():
    """E2 C2 (integration): servo lead run INSIDE the head (group H): floor slot -> up to local z 7.5 under the vault
    -> along -X out of the vault mouth -> climbs to local z 10.4 (x -7..-13) -> level over the -X pad onto the
    cable-bridge deck (tied there, 44 mm from the lead exit) -> turn back and up -> return run along +X at y +7 on the
    level of the even header row -> into the header at pin 4 (G; 5V = pin 2 next to it).
    Bend radius 3.0 everywhere.  Free length bridge -> plug ~95 mm = service loop for pulling the front module."""
    zt, zr = HZ + LEAD_ZTURN, HZ + LEAD_ZRUN
    tx, ty = LEAD_TURN
    px, py, pz = HC.header_pin(LEAD_PIN, HZ)
    return [(LEAD_X, 0, HZ), (LEAD_X, 0, zt), (LEAD_RISE[0], 0, zt), (LEAD_RISE[1], 0, zr), (tx, 0, zr), (tx, ty, pz),
            (px, ty, pz), (px, py, pz)], 3.0


def cables():
    """-> head wires static (N), head wires rotating (H), servo-lead stub nub -> knuckle surface (N), servo-lead run
    inside the head (H).  The 0.5 mm between stub and run is the flexing zone in the knuckle / floor gap."""
    c = cable_paths()
    neck = tube(*c[0][:2])
    head = tube(*c[1][:2]) + tube(*c[2][:2])
    stub = zcyl(LEAD_R, SZ1 + NUB[3], AXZ + RK, x=LEAD_X)
    pts, R = lead_path()
    return neck, head, stub, tube(pts, R, LEAD_R)


def tube_mesh(pts, R, r=WIRE_R, n=24, ds=0.12, ph0=0.0):
    """R3: watertight triangle mesh of the same tube (filleted polyline, ring of n, parallel-transport frames, caps)"""
    import numpy as np
    P = [np.array(p, float) for p in pts]
    path = [P[0]]
    Rs = list(R) if isinstance(R, (list, tuple)) else [R] * (len(P) - 2)
    for i in range(1, len(P) - 1):
        a, b, c, R = P[i - 1], P[i], P[i + 1], Rs[i - 1]
        u, v = (a - b) / np.linalg.norm(a - b), (c - b) / np.linalg.norm(c - b)
        th = math.acos(np.clip(u @ v, -1, 1))
        t = R / math.tan(th / 2)
        ctr = b + (u + v) / np.linalg.norm(u + v) * R / math.sin(th / 2)
        p0, p1 = b + u * t, b + v * t
        k = max(2, int(math.ceil(np.linalg.norm(p0 - path[-1]) / 1.0)))
        path += [path[-1] + (p0 - path[-1]) * j / k for j in range(1, k + 1)]
        e0, e1 = p0 - ctr, p1 - ctr
        ang = math.acos(np.clip(e0 @ e1 / (R * R), -1, 1))
        w = np.cross(np.cross(e0, e1), e0); w /= np.linalg.norm(w)
        m = max(4, int(math.ceil(R * ang / ds)))
        path += [ctr + R * (math.cos(ang * j / m) * e0 / R + math.sin(ang * j / m) * w) for j in range(1, m + 1)]
    k = max(2, int(math.ceil(np.linalg.norm(P[-1] - path[-1]) / 1.0)))
    path += [path[-1] + (P[-1] - path[-1]) * j / k for j in range(1, k + 1)]
    Q = np.array(path)
    keep = np.r_[True, np.linalg.norm(np.diff(Q, axis=0), axis=1) > 1e-6]
    Q = Q[keep]
    T = np.gradient(Q, axis=0); T /= np.linalg.norm(T, axis=1, keepdims=True)
    nrm = np.cross(T[0], [0.0, 1.0, 0.0] if abs(T[0][1]) < 0.9 else [1.0, 0.0, 0.0]); nrm /= np.linalg.norm(nrm)
    rings = []
    for i in range(len(Q)):
        if i:
            nrm = nrm - (nrm @ T[i]) * T[i]; nrm /= np.linalg.norm(nrm)
        bn = np.cross(T[i], nrm)
        rings.append([Q[i] + r * (math.cos(2 * math.pi * (j + ph0) / n) * nrm + math.sin(2 * math.pi * (j + ph0) / n) * bn)
                      for j in range(n)])
    V = np.array(rings)
    tri = []
    for i in range(len(Q) - 1):
        for j in range(n):
            a, b_, c, d = V[i, j], V[i + 1, j], V[i + 1, (j + 1) % n], V[i, (j + 1) % n]
            tri += [(a, c, b_), (a, d, c)]
    for j in range(n):
        tri.append((Q[0], V[0, (j + 1) % n], V[0, j]))
        tri.append((Q[-1], V[-1, j], V[-1, (j + 1) % n]))
    Tr = np.array(tri, np.float32)
    sv = np.einsum('ij,ij->i', Tr[:, 0], np.cross(Tr[:, 1], Tr[:, 2])).sum()
    return Tr if sv > 0 else Tr[:, [0, 2, 1]]


def head_parts(adds, cuts):
    """head-side registry entries of the E2 head module (E2_spec D): hlava_skrupina (shell with the pads / cuts of
    head_pads_and_cuts()), ram_displeja, displej (glass, lcd, pcb, standoffs, header, usbc, small), pena_displeja,
    drziak_displeja (2 bars), magnety (bezel side, shell side), usi, led_kruzky, led_dosky, oci_len_vizualizacia,
    skrutky (carrier screws, carrier inserts)."""
    return HC.head_parts(HZ, cuts=cuts, adds=adds)


def build_all():
    """registry: name -> list of (shape, group); group H = head side (lifts + tilts), N = neck side (lifts), T = torso.
    E2 names (section D): N: krk_predna_polovica, krk_zadna_polovica, servo_MG90S, pena_serva (4 pocket foams | the
    black plug of the knuckle lead slot), capy, skrutky[0],
    kabel[0] + kabel[2], loziska_MR85[1];  H: usko_kryt, usko_lozisko, paka, klzny_kruzok, skrutky[1:] (horn screw,
    4 cross screws, 8 carrier screws, 4 carrier inserts), kabel[1] (head wires) + kabel[3] (servo-lead run),
    loziska_MR85[0] + the head module's parts (hlava_skrupina, ram_displeja, displej, pena_displeja, drziak_displeja,
    magnety, usi, led_kruzky, led_dosky, oci_len_vizualizacia);  T: golier_kotuc, golier_prstenec (+ trup in export)."""
    adds, cuts = head_pads_and_cuts()
    P = head_parts(adds, cuts)
    head_scr = P.pop("skrutky", [])
    nf, nb = halves()
    P["krk_predna_polovica"] = [(nf, "N")]
    P["krk_zadna_polovica"] = [(nb, "N")]
    P["usko_kryt"] = [(cap(), "H")]
    P["usko_lozisko"] = [(lug_plus(), "H")]
    P["paka"] = [(horn(), "H")]
    P["klzny_kruzok"] = [(ptfe_ring(), "H")]
    P["servo_MG90S"] = [(servo(), "N")]
    P["pena_serva"] = [(foam(), "N"), (lead_plug(), "N")]                 # 2 Y strips + 2 X pads (compressed) | slot plug
    bo, bi = bearing()
    P["loziska_MR85"] = [(bo, "H"), (bi, "N")]
    nsc, dw = neck_fasteners()
    P["capy"] = [(pin(), "N"), (dw, "N")]
    P["skrutky"] = [(nsc, "N"), (horn_screw(), "H"), (cross_screws(), "H")] + list(head_scr)
    cn, ch, ls, lr = cables()
    P["kabel"] = [(cn, "N"), (ch, "H"), (ls, "N"), (lr, "H")]
    disc, ring = collar()
    P["golier_kotuc"] = [(disc, "T")]
    P["golier_prstenec"] = [(ring, "T")]
    return P


AX = Axis((0, 0, AXZ), (1, 0, 0))


def pose(shape, group, lift=0.0, tilt=0.0):
    """lift: 0 = extended, -20 = rest; tilt about the hinge axis (+ = nod down / front down)"""
    if group == "T":
        return shape
    s = shape.rotate(AX, tilt) if (group == "H" and tilt) else shape
    return s.moved(Location((0, 0, lift))) if lift else s


def tris(shape, tol=0.01, ang=0.1):
    import numpy as np
    out = []
    for s in (shape.solids() if shape.solids() else [shape]):
        v, t = s.tessellate(tol, ang)
        if t:
            V = np.array([[p.X, p.Y, p.Z] for p in v], dtype=np.float32)
            out.append(V[np.array(t)])
    return np.concatenate(out) if out else np.zeros((0, 3, 3), np.float32)


def write_stl(path, T):
    import numpy as np
    T = np.asarray(T, np.float32)
    R = np.round(T.astype(np.float64), 5)                 # E2: drop degenerate triangles (sphere poles of the ear domes
    keep = ~((R[:, 0] == R[:, 1]).all(1) | (R[:, 1] == R[:, 2]).all(1) | (R[:, 0] == R[:, 2]).all(1))   # -> open edges)
    T = T[keep]
    n = np.cross(T[:, 1] - T[:, 0], T[:, 2] - T[:, 0]); n /= np.maximum(np.linalg.norm(n, axis=1, keepdims=True), 1e-12)
    rec = np.zeros(len(T), dtype=np.dtype([('n', '<f4', 3), ('v', '<f4', (3, 3)), ('a', '<u2')]))
    rec['n'], rec['v'] = n, T
    with open(path, 'wb') as f:
        f.write(b"NOVA mini B (mm, Z up, front -Y)".ljust(80, b" ")); f.write(len(T).to_bytes(4, 'little')); f.write(rec.tobytes())


def read_stl(path):
    import numpy as np
    d = open(path, 'rb').read(); n = int.from_bytes(d[80:84], 'little')
    return np.frombuffer(d[84:], dtype=np.dtype([('n', '<f4', 3), ('v', '<f4', (3, 3)), ('a', '<u2')]), count=n)['v'].copy()


def tf(T, lift=0.0, tilt=0.0):
    """numpy pose of a triangle array (same convention as pose())"""
    import numpy as np
    T = T.copy()
    if tilt:
        a = math.radians(tilt); c, s = math.cos(a), math.sin(a)
        y, z = T[..., 1].copy(), T[..., 2] - AXZ
        T[..., 1], T[..., 2] = c * y - s * z, s * y + c * z + AXZ
    T[..., 2] += lift
    return T


SRC_T = "/home/user/Robot/obrazky/postupne/03_koncept_otocny_krk/stl/B_servo_v_krku/"
NOT_IN_CELOK = ()                               # E2: every registry part is a real part (drziak_displeja = 2 bars)


def export(P):
    import numpy as np, os, glob
    os.makedirs(f"{D}/stl", exist_ok=True)
    for old in glob.glob(f"{D}/stl/*.stl"):      # no stale names (e.g. the round-5 sklo.stl) may survive an export
        os.remove(old)
    M = {}                                       # name -> list of (tris extended pose, group)
    for k, lst in P.items():
        M[k] = [(tris(s), g) for s, g in lst]
    M["trup"] = [(tris(torso(), 0.02, 0.15), "T")]                                     # repaired (see torso())
    (pn, rn, _), (ph, rh, _), (ph2, rh2, _) = cable_paths()                # one closed tube per side (no shared caps):
    rr = [rh] * (len(ph) - 2) + [rh2] * (len(ph2) - 2)                    # R4: path 2 has 3 corners (tilted channel)
    ph = [(ph[0][0] - 0.1,) + tuple(ph[0][1:])] + ph[1:-1] + ph2[1:]       # head tube starts 0.1 inside the neck tube
    lp, lr_ = lead_path()
    M["kabel"] = [(tube_mesh(pn, rn), "N"), (tube_mesh(ph, rr, ph0=0.5), "H"), (tris(P["kabel"][2][0]), "N"),
                  (tube_mesh(lp, lr_, r=LEAD_R), "H")]
    files = []
    for k, lst in M.items():                     # every part separately, REST pose (neck + head -20)
        T = np.concatenate([t if g == "T" else tf(t, -LIFT) for t, g in lst])
        write_stl(f"{D}/stl/{k}.stl", T); files.append(f"{D}/stl/{k}.stl")
    for fn, tilt in (("CELOK_vysunute", 0.0), ("CELOK_naklon40", 40.0)):
        T = np.concatenate([t if g != "H" else tf(t, 0.0, tilt) for k, lst in M.items() if k not in NOT_IN_CELOK
                            for t, g in lst])
        write_stl(f"{D}/stl/{fn}.stl", T); files.append(f"{D}/stl/{fn}.stl")
    T = np.concatenate([t if g == "T" else tf(t, -LIFT) for k, lst in M.items() if k not in NOT_IN_CELOK for t, g in lst])
    write_stl(f"{D}/stl/CELOK_pokoj.stl", T); files.append(f"{D}/stl/CELOK_pokoj.stl")
    return files


if __name__ == "__main__":
    import time
    t0 = time.time()
    P = build_all()
    for k, lst in P.items():
        print(k, [(s.is_valid, len(s.solids())) for s, g in lst], round(time.time() - t0, 1), flush=True)
    files = export(P)
    print("exported", len(files), round(time.time() - t0, 1), flush=True)
