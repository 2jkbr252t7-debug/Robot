# NOVA mini – variant B – revision E2 (real-part dimensions + smooth exterior)

World mm, Z up, front −Y, robot right −X. Head-local frame: bottom z=0, centre y=0, front face y=−33.
HZ=27 (neck extended) / 7 (rest), hinge axis AXZ=16.5 along X, LIFT 20, torso top z=4. Target look:
`ref/R01_cielovy_vzhlad.png` (black bezel frame with a slightly recessed black glass screen, white pillow shell,
round black neck/hinge, cyan ear rings).

The user decided: keep mechanism B, fix everything to REAL part dimensions, smooth rounded surfaces with no steps or
broken-looking pieces, bare display board (no case). This file overrides `E1_exterior_spec.md` where they differ;
E1 §3 (ear pods), §4 (lugs), §5 (neck), §6 (collar), §7 (continuity table), §8 (finish) stay valid unless changed here.

## A. Real parts (sources in ref/)

### A1. Display = Waveshare ESP32-S3-Touch-LCD-3.5B, bare board (ref/displej_3.5B_oficialny_vykres_bez_krytu.jpg)
- Cover glass (capacitive touch, black border): 92.44 × 61.00, corner R6.00, thickness 1.10. It is the largest outline.
- Active area 73.44 × 48.96, centred on the glass (border 9.50 left/right, 6.02 top/bottom).
- 4 × M2 threaded brass standoffs on the BACK of the PCB, pattern 72.00 × 48.50 centred on the glass
  (10.22 / 6.25 from the glass edges).
- Thickness: 7.50 and 11.50 are dimensioned from the glass front in the side view. Read the image (zoom in) and decide
  what 7.50 ends on (standoff end plane vs. PCB back). Model: mounting plane 7.50 behind the glass front, tallest
  part (2×16 pin header, also USB-C/TF/JST) 11.50 behind the glass front. Keep-out behind the PCB to 11.5 everywhere.
- PCB is smaller than the glass (about 79.5 × 55, measure from the drawing; the FPC tail side is wider).
- Orientation in the head: as the official front view – header along the BOTTOM edge, buttons along the top edge,
  USB-C on the viewer's right (= robot +X). Display centre = head centre (x 0, local z H/2).
- Header pins (ref/displej_3.5B-C… rear label): 5V G 19 20 11 10 9 17 18 0 RST PWR SCL SDA G 3V3 / BAT G 21 38 39 40 41
  42 45 46 47 48 TX RX G 3V3. The tilt servo plugs here (5V, G, one GPIO).
- OLD model values that are WRONG and must disappear: board 85.5 × 55.5 (DW 86, DH 56, DR 2), holes ±39.75/±24.75,
  LCD_T 3.0 / PCB_T 1.4, corner seats and ribs in the shell, 5.9 mm clear visor in front of the display, visor tape.

### A2. Servo MG90S (ref/MG90S_*.png; user's dimension picture + three photos)
Side-view drawing measured at 27.19 px/mm (ref/MG90S_vykres_bok_3x.png: spline axis x≈925, case bottom y≈1027.5):
case 22.4–22.8 long × 12.0–12.3 wide × 22.5–22.8 high (bottom → case top); turret top 28.0–28.5 above the bottom
(5.4–6.2 above the case top); horn top 32.0–32.6; spline axis 5.7–5.9 from the near case end.
- The turret is a KEYHOLE: big boss around the output shaft + a second lobe of the SAME height toward the case centre.
  Lobe (measured): spans to 8.1–8.5 mm from the spline axis; model it as r 2.9 at centre distance 5.6, full turret
  height, joined to the boss. Tolerance range to accept: centre 5.0–6.5, r 2.6–3.1, height 5.4–6.2.
  (Round 5 had a 1.2 mm bump at 7.2 – wrong.)
- The lead exits the END FACE NEAREST THE OUTPUT SHAFT, low, next to the bottom cover (all three photos).
  In the neck that end is the TOP of the pocket (z = AXZ+5.9), x ≈ XB−4.3 … XB−0.35, |y| ≤ 2.2 (3-wire flat lead
  ≈ 3.6 × 1.2 mm, strain-relief nub ≈ 4 × 2 × 2). (Round 5 had it on the opposite end – wrong.)
- Mounting tabs: position along the height is uncertain (15.5–18.5 or higher). DECISION: BOTH tabs are cut off flush
  (side cutters + file); no tab slot in the pocket.
- Horn: stock 2-arm horn trimmed to 12 mm; hub height 3.0–4.2; arm top 8.9–10.3 above the case top must be accepted
  WITHOUT rework (nominal 9.6); outside that the assembly text gives the remedy (shim / file).
- Spline 21T Ø4.8 (clones 20T Ø4.9): always use the horn supplied with the servo.

### A3. Others unchanged: MR85ZZ 5×8×2.5, hollow pin Ø4.99/3, SK6805-EC15 LED boards, M2 hardware.
Head wires torso→head: 4 wires (5V, GND, 2 signals). Size the passages for 4 × Ø0.85 (AWG30 silicone / AWG28 PTFE).

## B. Decisions for this revision

### B1. Head envelope and shell (white, `hlava_skrupina`)
- W 110 × H 79 × D 66 (was 108 × 77), front-view superellipse exponent N = 5.0 (was 3.6) – squarer, like R01.
- Front round: EQUAL inset in x and z, elliptical, 9 deep × 7.5 inset (E1 §1.2 formula with the new W/2, H/2):
  for y in [−33, −24]: s = (−24−y)/9, q = sqrt(1−s²), a = W/2 − 7.5·(1−q), b = H/2 − 7.5·(1−q).
  Back zone as before (R_BACK 30 → factor 0.30), scaled to the new W/H.
- Wall 2.5. Colour break Y_SEAM = −26.0 (black bezel owns y −33..−26, white shell from −26 back).
- The old display seats / ribs / inserts inside the shell are DELETED. Shell-side magnet bosses are added (B3).
- Ear pods per E1 §3, re-positioned for the new width (centre local z = H/2).
- Head floor interface (tenon slots, pads, cross screws, groove holes) comes from the neck/hinge side
  (`build.head_pads_and_cuts()`); new: one slot for the servo lead (C2). No apron-peg holes any more.

### B2. Front module = bezel + display + carrier (removable as one unit, magnets, no visible fasteners)
- `ram_displeja` (bezel): OPAQUE black resin, gloss black paint. Outer surface = the SAME loft as the head for
  y −33..−26 (step 0 to the shell), V-seam 0.25 × 0.12 at y=−26 (chamfer 0.12 on both edges), spigot/rabbet 0.9/1.0
  lap as E1 §2.2.
- Window through the bezel front: 90.0 × 58.6, corner R4.8 (the lip overlaps the glass border by 1.22 all around;
  the whole active area and ≥ 8 mm / 4.8 mm of black border stay visible and touchable).
  Window front edge rounded R1.0 (soft inner edge like R01); lip thickness 1.5 (lip back face y = −31.5).
- Glass pocket behind the lip: 92.84 × 61.40, R6.2 (0.2 clearance), open to the back of the bezel.
- Gasket `pena_displeja`: closed-cell foam frame 1.0 wide on the lip back face, 0.5 free → 0.3 compressed (drawn
  compressed). Glass front plane yG = −31.2 → glass −31.2..−30.1, mounting plane −23.7, header top −19.7.
- `drziak_displeja` (carrier, printed, black): two bars (top / bottom). Each bar is screwed to two display standoffs
  (M2×4 from behind, holes at x ±36.0, z H/2 ± 24.25) and to two bezel bosses with glued M2 brass inserts
  (OD 3.2 × 3.0 in Ø3.4 × 4.0 holes) located OUTSIDE the glass outline in the bezel ring (top and bottom ring).
  Bars must clear the header, USB-C, TF, JST connectors and the FPC (leave the PCB back open; ≥ 0.5 clearance to
  the 11.5 keep-out where they cross it, or stay outside its footprint).
  Boss faces, standoff ends and bar front face are coplanar at y = −23.7. Bar ≥ 2.0 thick.
- Front module → shell: 6 magnet pairs (N35 Ø4 × 2; if a wall < 1.0 results use Ø3 × 2 and 8 pairs), bezel side in
  the ring between glass pocket and spigot, shell side in bosses just behind the front opening, faces at the
  rabbet-floor plane y = −25.0. Total hold ≥ 12 N. Polarity note in the assembly text.
  Removal: suction cup on the glass, pull −Y. The shell front opening must let the whole module pass.
- Nothing of the shell may be visible through the window; the display glass IS the face. Eyes for visualisation
  (`oci_len_vizualizacia`) are drawn ON the active area plane (inside the 73.44 × 48.96 area), thin (0.05) and
  slightly in front of the glass front so they render; two vertical rounded pills like R01.

### B3. Minimum walls and seams
Resin wall ≥ 1.2 everywhere (blind cosmetic walls ≥ 1.0 only where stated), nothing sharper than R0.3 on the outside,
no planar facet on visible black parts except the lug end faces, seams: bezel/shell V 0.25, hinge 0.3, collar 0.25/0.1,
ear pod 0.15.

## C. Neck / hinge / servo pocket (black)

### C1. Servo pocket (both neck halves)
- Servo model per A2 (keyhole turret, lead on the shaft end, no tabs).
- Pocket: datum = gear face against the −X wall (0.05), +X end 0.75 longer than the 22.5 case with a self-adhesive
  foam pad 1.0 free on the bottom-cover wall (accepts case height 22.4–23.0, pushes the servo to the datum).
  Y as round 5 (foam strips), Z floor datum as round 5, roof clearance as round 5. No tab slot.
- Keyhole bore for boss + lobe down to the common floor (boss floor rule of round 5: 0.3 above the nominal turret,
  end wall ≥ 1.3); lobe relief covers the tolerance range of A2 with ≥ 0.2 radial clearance.
- Delete the round-5 bump relief, tab slot, lead channel down the neck and the strain relief at the far end.

### C2. Servo lead goes UP into the head
- Slot through the knuckle top above the pocket roof: x XB−4.6 … XB−0.1, |y| ≤ 2.4, from the pocket roof to the
  outer knuckle surface, edges R0.5. It lies on the parting plane, so the lead drops in when the halves close.
- Matching slot through the head floor: same x range, |y| ≤ 11.2 (the floor travels ±8.8 mm past the static lead at
  ±40° tilt), ends R2.25. It is cut via `head_pads_and_cuts()`.
- Inside the head the lead is tied down ≥ 20 mm from the slot (printed cable bridge on the floor, head side) and goes
  to the display header. In the gap between knuckle and floor the lead wears a black sleeve (assembly text) and the
  three wires are separated for 15 mm so they flex easily.
- Model the lead as a tube: a stub fixed to the neck (group N) and the run inside the head (group H).

### C3. Hinge (−X cap `usko_kryt`, +X lug `usko_lozisko`)
- Cap accepts arm top 8.9–10.3 above the case top (A2) – deepen the arm slot / screw-head bore; the blind cap end
  wall may go down to 1.0 (state it). Clear the horn by ≥ 0.3 from the static knuckle face over the servo's axial
  float (round-5 minor: 0.10).
- Hinge seam 0.3 (KN 17.5, LUG0 17.8, LUG1 22.5); lip ring / groove / sleeve / counterbore move with it.
  Add a static lip ring on the +X knuckle end as on −X so the sleeve is not visible through the seam.
- Thrust: PTFE ring 0.25 (`klzny_kruzok`) so the head has ≤ 0.05 axial float.
- Head-wire passage in the +X lug/tenon: slot instead of Ø1.6 – 4 × Ø0.85 wires must pass with ≥ 0.3 total clearance
  after 0.15 print shrink per wall; tenon walls ≥ 1.2; ≥ 1.0 to the cross-screw pilots. Check pin slot and chamber too.
- Lug exterior per E1 §4: barrel R10 + web, concave R3 blend, end-face rounds R2. Aprons and apron pegs DELETED.
- Cross screws: ISO 7380-1 M2×8, model dk 3.8 × k 1.3.

### C4. Neck exterior per E1 §5 (blade corners R3, convex R3 saddle fillet instead of the 35° land, parting line as a
V 0.3 × 0.15) and collar per E1 §6 (slot R3.25, edge R0.6, seams 0.25 / 0.1).

## D. Part names (registry keys / STL names) – fixed, so the render pipeline can be prepared
H group: hlava_skrupina, ram_displeja, displej, pena_displeja, drziak_displeja, magnety, usi, led_kruzky, led_dosky,
oci_len_vizualizacia, usko_kryt, usko_lozisko, paka, klzny_kruzok (or N – say which), skrutky (H items), kabel (H run).
N group: krk_predna_polovica, krk_zadna_polovica, servo_MG90S, pena_serva, capy, skrutky (N items), kabel (N items),
loziska_MR85 (outer H / inner N as before). T group: golier_kotuc, golier_prstenec (+ trup added by export()).
Removed names: sklo, the old fused drziak_displeja (seats/ribs).
`build_all()` keeps returning {name: [(shape, group), …]} and `export(P)` keeps writing stl/<name>.stl + CELOK_*.stl.

## E. Acceptance checks (numbers must be produced by code, not by eye)
E1 every solid valid; mesh volumes sane (use HC.mesh_volume for lofts).
E2 zero interference between all parts at rest and extended, tilt −40..+40 step 5 (intended press fits listed).
E3 clearances H vs N/T ≥ 0.25 over the sweep; hinge seams 0.3 uniform.
E4 walls ≥ 1.2 (ray-cast rule of round 5), listed exceptions only.
E5 servo envelope range of A2 fits the closed halves: width 12.0/12.3, length 22.4/22.8, height 22.4/23.0,
   turret height 5.4/6.2, lobe centre 5.0/6.5 and r 2.6/3.1, lead nub anywhere in x XB−4.3…XB−0.35.
E6 horn arm top 8.9 / 9.6 / 10.3 above the case top: cap fits, sweep ±40° clear.
E7 display: official outline fits – glass 0.2 to the pocket, lip overlap 1.2 ± 0.05, window clear of the active area
   by ≥ 8 / 4.5 mm, standoff screws line up (72.0 × 48.5), nothing within the 11.5 keep-out, module passes the shell
   opening, bezel ↔ shell step ≤ 0.02 at 72 seam points.
E8 magnets: walls ≥ 1.0, pairs aligned ≤ 0.1.
E9 visibility ray-cast (round-5 method): no internal part visible from outside at rest and at ±40°, except the
   servo lead in the knuckle/floor gap (report the visible area).
E10 lead slot: floor slot never touches the static lead over ±40° (≥ 0.5).
