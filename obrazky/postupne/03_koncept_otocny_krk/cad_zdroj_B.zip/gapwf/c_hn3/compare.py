import sys, json
sys.path.insert(0, "/home/user/Robot")
from PIL import Image, ImageDraw
from nova.render import sheet as S
OUT = "/home/user/Robot/obrazky/postupne/03_koncept_otocny_krk/NOVA_mini_servo_hlava_vs_krk.png"
BG = (243, 243, 241); OR = (230, 120, 40); GR = (110, 110, 110); INK = S.INK; GOOD = (40, 140, 90); BAD = (190, 70, 50)
W = 2900; M = 50; NC = 4; GX = 30; COLW = (W - 2 * M - (NC - 1) * GX) // NC; CELLH = 860
ROWS = [dict(d="/tmp/claude-0/gapwf/c_hn2", t="A · SERVO V HLAVE – štíhly krk 34 × 16 mm",
             plus=["štíhly krk", "nízky pánt pod hlavou"],
             minus=["tiahlo + páka (malá vôľa v čapoch)", "servo v hlave 10 mm za displejom", "malý otvor v spodku hlavy (zakrytý pántom)"]),
        dict(d="/tmp/claude-0/gapwf/c_hn3", t="B · SERVO V KRKU – krk 45 × 20 mm (servo točí hlavou priamo)",
             plus=["žiadne tiahlo, priamy pohon – menej dielov a vôle", "hlava voľná len pre displej a elektroniku", "bez otvoru v hlave, kratšie káble serva"],
             minus=["krk širší o 11 mm a hrubší o 4 mm", "vysúva sa o 1 mm viac (20 mm)"])]
COLS = [("front", "SPREDU"), ("side", "ZBOKU"), ("tD", "40° DOLE"), ("xside", "PRIEHĽADNE")]
def load(d, k):
    im = Image.open(f"{d}/{k}/v.png").convert("RGBA")
    return im, im.getchannel("A").point(lambda a: 255 if a > 8 else 0).getbbox()
data = {(r["d"], k): load(r["d"], k) for r in ROWS for k, _ in COLS}
sc = min(min((COLW - 10) / (bb[2] - bb[0]) * im.size[0], (CELLH - 70) / (bb[3] - bb[1]) * im.size[0]) for im, bb in data.values())
ROWH = 70 + CELLH + 20 + 3 * 44 + 50
H = 170 + 2 * ROWH + 20
out = Image.new("RGB", (W, H), BG); d = ImageDraw.Draw(out)
d.text((M, 36), "NOVA mini / SERVO NÁKLONU: V HLAVE alebo V KRKU?", fill=INK, font=S.font(58, "Bold"))
d.text((M, 110), "rovnaká mierka · hlava 108 × 77 mm s displejom 3,5\" 86 × 56 mm · krk vysunutý · náklon ±40° v oboch verziách",
       fill=GR, font=S.font(30))
for ri, r in enumerate(ROWS):
    y0 = 170 + ri * ROWH
    d.text((M, y0), r["t"], fill=INK, font=S.font(44, "Bold"))
    for ci, (k, lab) in enumerate(COLS):
        im, bb = data[(r["d"], k)]; f = sc / im.size[0]
        c = im.crop(bb).resize((round((bb[2] - bb[0]) * f), round((bb[3] - bb[1]) * f)), Image.LANCZOS)
        x0 = M + ci * (COLW + GX); yc = y0 + 65
        d.text((x0, yc), lab, fill=OR, font=S.font(34, "Bold"))
        out.paste(c, (x0 + (COLW - c.size[0]) // 2, yc + 50 + (CELLH - 60 - c.size[1])), c)
    by = y0 + 65 + CELLH + 10
    half = (W - 2 * M) // 2
    for i, t in enumerate(r["plus"]):
        d.text((M, by + i * 44), "+  " + t, fill=GOOD, font=S.font(32, "Bold"))
    for i, t in enumerate(r["minus"]):
        d.text((M + half, by + i * 44), "–  " + t, fill=BAD, font=S.font(32, "Bold"))
out.save(OUT, optimize=True); print(out.size)
