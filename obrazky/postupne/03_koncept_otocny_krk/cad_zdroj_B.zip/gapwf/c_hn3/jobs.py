import json, math, os
B = "/tmp/claude-0/gapwf/c_hn3"
SH = ["H", "V", "E", "L", "Y", "N", "K"]
IN = ["servo", "horn", "pins", "brg", "spring", "cable", "scable", "lcd", "pcb", "comp"]
def job(name, parts, view, res=(1300, 1300), samples=64, xray=False):
    j = dict(out=f"{B}/{name}", glb_dir=B, manifest_dir=f"{B}/manifest", parts=parts, internal=xray, res=list(res),
             samples=samples, shadow=False, exposure=-1.5, write_meta=True, views=[view])
    if xray:
        j.update(xray=True, xray_alpha=0.12)
    return j
def iso(yaw, el, d=900, zt=40):
    a, e = math.radians(yaw), math.radians(el)
    return [d * math.cos(e) * math.sin(a), -d * math.cos(e) * math.cos(a), zt + d * math.sin(e)]
side = lambda: {"name": "v", "loc": [800, 0, 40], "target": [0, 0, 40], "lens": 50, "ortho": True, "ortho_scale": 140}
ext = lambda t: [p + t for p in SH]
allp = lambda t: [p + t for p in SH + IN]
jobs = {"front": job("front", ext("0"), {"name": "v", "loc": [0, -800, 40], "target": [0, 0, 40], "lens": 50, "ortho": True, "ortho_scale": 140}),
        "side": job("side", ext("0"), side()),
        "iso": job("iso", ext("0"), {"name": "v", "loc": iso(-34, 14), "target": [0, 0, 40], "lens": 50, "ortho": True, "ortho_scale": 140}),
        "tD": job("tD", ext("D"), side(), res=(1000, 1000), samples=48),
        "tU": job("tU", ext("U"), side(), res=(1000, 1000), samples=48),
        "close": job("close", ext("U"), {"name": "v", "loc": iso(-30, -8, 260, 22), "target": [0, 0, 22], "lens": 60}, res=(1300, 1000)),
        "xside": job("xside", allp("0"), side(), xray=True),
        "xiso": job("xiso", allp("0"), {"name": "v", "loc": iso(140, 16), "target": [0, 0, 40], "lens": 50, "ortho": True, "ortho_scale": 140}, xray=True)}
for k, j in jobs.items():
    open(f"{B}/{k}.json", "w").write(json.dumps(j))
print(list(jobs))
