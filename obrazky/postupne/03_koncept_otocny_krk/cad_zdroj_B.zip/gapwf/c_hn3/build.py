"""Variant 'servo v krku': tilt MG90S sits in the neck top with its shaft ON the hinge axis (direct drive, no link).
Neck blade 45 x 20 (knuckle R10 so the servo corners keep 1.5 mm wall), knuckle |x| <= 17.5, head lugs 18..22.5.
Horn in the right lug (-X), left lug on an MR85 over a hollow Ø5 pin from the +X knuckle end wall (cable).
Head = same as c_hn2 (108 x 77, real 86x56 display), no window in the head bottom."""
import sys, math, json
sys.path.insert(0, "/home/user/Robot"); sys.path.insert(0, "/tmp/claude-0/pan16")
from build123d import Pos, Rot, Box, Cylinder, Axis, Location, fillet, export_stl, Torus, Solid
from nova.cad.common import PartRec, export_parts
from nova import spec
import softhead as SH
SH.W, SH.H, SH.N = 108.0, 77.0, 3.6
spec.MATERIALS["servo_blue"] = dict(desc="servo", rgb=(0.22, 0.42, 0.86), rough=0.45)
spec.MATERIALS["bracket"] = dict(desc="držiak", rgb=(0.60, 0.38, 0.86), rough=0.45)
spec.MATERIALS["pcb"] = dict(desc="doska", rgb=(0.10, 0.32, 0.20), rough=0.5)
B = "/tmp/claude-0/gapwf/c_hn3"
HZ = 27.0                                   # neck extended 20 mm (rest head bottom 7)
BW, BT, RK = 45.0, 20.0, 10.0
AXZ = HZ - (RK + 0.5)
KN, LUG0, LUG1 = 17.5, 18.0, 22.5
ZB = -16.5
WALL = 2.5
LCD_Y0 = SH.YF + SH.VISOR_T + 0.3
ZC = HZ + SH.H / 2


def xcyl(r, x0, x1, y, z):
    return Pos((x0 + x1) / 2, y, z) * Rot(0, 90, 0) * Cylinder(r, abs(x1 - x0))


def zcyl(r, z0, z1, x=0.0, y=0.0):
    return Pos(x, y, (z0 + z1) / 2) * Cylinder(r, z1 - z0)


def rbox_y(w, h, r, y0, y1, zc=ZC, x=0.0):
    b = Pos(x, (y0 + y1) / 2, zc) * Box(w, y1 - y0, h)
    return fillet(b.edges().filter_by(Axis.Y), r)


def servo():
    """MG90S, shaft along -X on the hinge axis: spline -18.0..-15.0, boss -15..-9, case -9..13.5"""
    case = Pos(-8.4 + 22.5 / 2, 0, AXZ + 5.9 - 22.8 / 2) * Box(22.5, 12.2, 22.8)
    boss = xcyl(5.9, -14.4, -8.4, 0, AXZ)
    spl = xcyl(2.4, -17.4, -14.4, 0, AXZ)
    return case + boss + spl


def blade():
    body = Pos(0, 0, (ZB + AXZ) / 2) * Box(BW, BT, AXZ - ZB)
    body = fillet(body.edges().filter_by(Axis.Z), 2.0)
    for sx in (-1, 1):
        body = body - (Pos(sx * (KN + 0.25 + 3.5), 0, AXZ) * Box(7.0, BT + 2, 2 * RK + 1.0))
    body = body + xcyl(RK, -KN, KN, 0, AXZ)
    inner = Pos(0, 0, (ZB + 3 + AXZ - 1) / 2) * Box(BW - 4, BT - 4, AXZ - 1 - ZB - 3)
    inner = inner + xcyl(RK - 1.3, -(KN - 3), KN - 3, 0, AXZ)            # servo bay in the knuckle
    hole = xcyl(3.2, -KN - 1, -KN + 3.5, 0, AXZ)                          # spline/horn hub through the -X end wall
    return body - inner - hole


def lugs():
    L = None
    for sx in (-1, 1):
        x0, x1 = sorted((sx * LUG0, sx * LUG1))
        l = xcyl(RK, x0, x1, 0, AXZ) + Pos((x0 + x1) / 2, 0, (AXZ + HZ + 1.5) / 2) * Box(x1 - x0, 2 * RK, HZ + 1.5 - AXZ)
        if sx < 0:
            l = l - xcyl(6.2, -LUG0 - 2.0, -LUG0 + 0.5, 0, AXZ) - xcyl(2.6, x0 - 1, x1 + 1, 0, AXZ)   # horn pocket
        else:
            l = l - xcyl(4.05, 19.0, 21.5, 0, AXZ) - xcyl(2.6, x0 - 1, x1 + 1, 0, AXZ) - zcyl(1.6, AXZ, HZ + 2, x=20.25)
        L = l if L is None else L + l
    return L


def internals():
    I = {}
    I["servo"] = servo()
    I["horn"] = xcyl(6.0, -19.8, -18.3, 0, AXZ) + xcyl(3.0, -18.3, -17.3, 0, AXZ)
    I["pins"] = xcyl(2.5, 14.5, 22.0, 0, AXZ) - xcyl(1.5, 14.0, 22.5, 0, AXZ)
    I["brg"] = xcyl(4.0, 19.0, 21.5, 0, AXZ) - xcyl(2.5, 18.5, 22.0, 0, AXZ)
    spring = None
    for i in range(3):
        t = Pos(18.4 + i * 0.25, 0, AXZ) * Rot(0, 90, 0) * Torus(3.4, 0.3)
        spring = t if spring is None else spring + t
    I["spring"] = spring
    I["cable"] = (zcyl(1.3, ZB + 3.5, AXZ, x=16.0, y=-5.0) + Pos(16.0, -2.5, AXZ) * Box(2.4, 5.0, 2.4) +
                  xcyl(1.2, 16.0, 22.4, 0, AXZ) + zcyl(1.2, AXZ, HZ + 3, x=20.25))
    I["scable"] = zcyl(1.0, ZB + 3.5, AXZ - 16.9, x=-2.0, y=3.0)          # servo cable down the neck
    return I


def head_internals():
    H = {}
    H["lcd"] = rbox_y(86, 56, 2.0, LCD_Y0, LCD_Y0 + 3.0)
    H["pcb"] = rbox_y(86, 56, 2.0, LCD_Y0 + 3.2, LCD_Y0 + 4.6)
    H["comp"] = rbox_y(62, 40, 2.0, LCD_Y0 + 4.6, LCD_Y0 + 11.6, zc=ZC - 4)
    return H


if __name__ == "__main__":
    head = (SH.outer() - SH.white_cut()).moved(Location((0, 0, HZ)))
    inner_skin = Solid.make_loft([SH.sec(y, shrink=WALL) for y in SH.ys(SH.YF + WALL, SH.YB - 0.4 - WALL, 34)]).moved(Location((0, 0, HZ)))
    lg = lugs()
    head = head - lg
    visor = SH.visor().moved(Location((0, 0, HZ))); ears, leds = (s.moved(Location((0, 0, HZ))) for s in SH.ears(ear_z=SH.H / 2))
    eyes = None
    for sx in (-1, 1):
        e = Pos(sx * 11.0, SH.YF - 0.2, ZC) * Box(10.0, 0.4, 17.5)
        e = fillet([ed for ed in e.edges() if abs(ed.tangent_at(0.5).Y) > 0.9], 4.9)
        eyes = e if eyes is None else eyes + e
    bl = blade(); I = internals(); HI = head_internals()
    print("valid", head.is_valid, bl.is_valid, lg.is_valid, {k: v.is_valid for k, v in {**I, **HI}.items()}, flush=True)
    rep = {}
    rep["servo into blade wall"] = round((I["servo"] & bl).volume, 2)
    rep["servo to blade mm"] = round(I["servo"].distance_to(bl), 2)
    rep["servo/horn into lugs (horn in pocket expected 0)"] = round(((I["servo"] + I["horn"]) & lg).volume, 2)
    rep["cable into blade"] = round((I["cable"] & bl).volume, 2)
    rep["cable to servo mm"] = round(I["cable"].distance_to(I["servo"]), 2)
    for k, v in HI.items():
        rep[f"{k} outside head skin"] = round((v - inner_skin).volume, 2)
    ax = Axis((0, 0, AXZ), (1, 0, 0))
    for th in (-40, 0, 40):
        rep[f"head th{th:+d} to blade mm"] = round(head.rotate(ax, th).distance_to(bl), 2)
        rep[f"lugs th{th:+d} to blade mm"] = round(lg.rotate(ax, th).distance_to(bl), 2)
    for k, v in rep.items():
        print(" ", k, v, flush=True)
    json.dump(rep, open(f"{B}/checks.json", "w"), indent=1)
    mats = dict(H="white", V="black_gloss", E="black_satin", L="cyan_led", Y="eye", N="black_satin", K="black_satin")
    shells = dict(H=head, V=visor, E=ears, L=leds, Y=eyes, N=bl, K=lg)
    mi = dict(servo="servo_blue", horn="metal", pins="metal", brg="metal", spring="metal", cable="rubber", scable="rubber",
              lcd="display", pcb="pcb", comp="grey")
    recs = []
    for tag, th in (("0", 0.0), ("D", 40.0), ("U", -40.0)):
        for k, v in shells.items():
            recs.append(PartRec(f"{k}{tag}", k, v.rotate(ax, th) if k != "N" else v, mats[k], "head", "J3"))
        for k, v in I.items():
            v2 = v.rotate(ax, th) if k in ("horn", "brg", "spring") else v
            recs.append(PartRec(f"{k}{tag}", k, v2, mi[k], "head", "J3", internal=True))
        for k, v in HI.items():
            recs.append(PartRec(f"{k}{tag}", k, v.rotate(ax, th), mi[k], "head", "J3", internal=True))
    export_parts(recs, "hn3", step=False, out_dir=B)
    for r in recs:
        export_stl(r.shape, f"{B}/stl/{r.id}.stl", tolerance=0.012, angular_tolerance=0.1)
    print("done", flush=True)
