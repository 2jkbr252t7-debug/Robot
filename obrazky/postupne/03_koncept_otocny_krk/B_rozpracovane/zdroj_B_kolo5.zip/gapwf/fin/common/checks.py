"""Self-check of head_common (run: /opt/venv/cad/bin/python checks.py [HZ]) -> checks.json + stl/ for Blender."""
import sys, json, time, math, warnings
warnings.filterwarnings("ignore")
sys.path.insert(0, "/tmp/claude-0/gapwf/fin/common")
import head_common as HC, softhead as SH
from build123d import Vector, Compound, GeomType, export_stl, Location
HZ = float(sys.argv[1]) if len(sys.argv) > 1 else 26.0
B = "/tmp/claude-0/gapwf/fin/common"
mv = HC.mesh_volume
R = {"HZ": HZ}
t0 = time.time()


def r3(x):
    return round(float(x), 3)


def inter(a, b):
    """mesh volume of the boolean intersection (0 = no overlap; touching faces give ~0)"""
    try:
        return r3(mv(a & b))
    except Exception as e:
        return f"err {e}"


shell = HC.head_shell(HZ)
outer = HC.head_outer(HZ)
inner = HC.inner_skin(HZ)
vis, ears, rings, leds = HC.visor(HZ), HC.ears(HZ), HC.led_rings(HZ), HC.led_boards(HZ)
D, M = HC.display_parts(HZ), HC.display_mount(HZ)
base = (outer - SH.white_cut().moved(Location((0, 0, HZ)))) - inner          # plain 2.5 shell, no features
bb = shell.bounding_box()
R["shell"] = dict(valid=shell.is_valid, solids=len(shell.solids()), mesh_volume=r3(mv(shell)),
                  outer_mesh_volume=r3(mv(outer)), occ_volume_unreliable=r3(shell.volume),
                  bbox=[[r3(bb.min.X), r3(bb.min.Y), r3(bb.min.Z)], [r3(bb.max.X), r3(bb.max.Y), r3(bb.max.Z)]])
zc = HZ + SH.H / 2
probes = {"cavity centre (0,0,zc)": (0, 0, zc), "cavity (0,20,zc)": (0, 20, zc), "cavity (30,-10,zc+20)": (30, -10, zc + 20),
          "wall side (-52.8,-20,zc)": (-52.8, -20, zc), "ear hole (-52.8,0,zc) = void": (-52.8, 0, zc), "wall top (0,0,HZ+75.8)": (0, 0, HZ + 75.8),
          "wall bottom (0,0,HZ+1.2)": (0, 0, HZ + 1.2), "wall back (0,31.5,zc)": (0, 31.5, zc)}
R["shell"]["probes_inside_material"] = {k: shell.is_inside(Vector(*p)) for k, p in probes.items()}
print("shell", R["shell"], round(time.time() - t0, 1), flush=True)

# ---- min wall: exterior faces vs every interior face that does not share an edge with them
o_lat = [f for f in HC.head_outer(HZ).faces() if f.geom_type != GeomType.PLANE]


def on_exterior(f):
    c = f.center()
    if f.geom_type == GeomType.PLANE and abs(f.normal_at(c).Y) > 0.99 and abs(c.Y - (SH.YB - 0.4)) < 1e-3:
        return True                                           # back cap
    return f.geom_type == GeomType.BSPLINE and min(of.distance_to(c) for of in o_lat) < 1e-3


ext = [f for f in shell.faces() if on_exterior(f)]
ext_edges = set(hash(e) for f in ext for e in f.edges()); ext_ids = set(hash(f) for f in ext)
intr = [f for f in shell.faces() if hash(f) not in ext_ids and not any(hash(e) in ext_edges for e in f.edges())]
walls = []
for f in intr:
    d = Compound(ext).distance_to(f)
    walls.append((r3(d), f.geom_type.name, [r3(f.center().X), r3(f.center().Y), r3(f.center().Z)]))
walls.sort()
R["min_wall_exterior_to_interior"] = dict(min=walls[0][0], n_ext_faces=len(ext), n_int_faces=len(intr), lowest5=walls[:5])
print("walls", R["min_wall_exterior_to_interior"], round(time.time() - t0, 1), flush=True)

# ---- overlaps (mesh volume of intersections, mm3; ~0 = only touching) and distances (mm)
lcdpcb = D["lcd"] + D["pcb"]
O = {}
O["visor x shell"] = inter(vis, shell)
O["visor - shell distance (0 = flange sits on the rim face)"] = r3(vis.distance_to(shell))
O["ears x shell"] = inter(ears, shell)
O["ears - shell distance (0 = disc back face on the lip)"] = r3(ears.distance_to(shell))
O["rings x ears"] = inter(rings, ears)
O["rings x shell"] = inter(rings, shell)
O["rings - shell distance"] = r3(rings.distance_to(shell))
O["led boards x shell / x ears"] = (inter(leds, shell), inter(leds, ears))
O["led boards - shell distance"] = r3(leds.distance_to(shell))
O["lcd x visor"] = inter(D["lcd"], vis)
O["lcd front - visor gap (target 0.2)"] = r3(D["lcd"].distance_to(vis))
O["gasket x visor / x lcd"] = (inter(D["gasket"], vis), inter(D["gasket"], D["lcd"]))
O["lcd+pcb x shell"] = inter(lcdpcb, shell)
O["lcd+pcb - shell distance (0 = pcb back on the 4 seats)"] = r3(lcdpcb.distance_to(shell))
O["lcd+pcb - plain wall clearance (no ribs/seats)"] = r3(lcdpcb.distance_to(base))
O["lcd+pcb - ribs clearance (target 0.25)"] = r3(lcdpcb.distance_to(M["ribs"]))
O["pcb - seats distance (0 = contact)"] = r3(D["pcb"].distance_to(M["seats"]))
O["lcd - seats distance"] = r3(D["lcd"].distance_to(M["seats"]))
O["comp keep-out x shell"] = inter(D["comp"], shell)
O["comp keep-out - shell distance (0 = touches the seats at the corner-zone edges)"] = r3(D["comp"].distance_to(shell))
O["comp keep-out - plain wall clearance"] = r3(D["comp"].distance_to(base))
O["inserts x shell"] = inter(M["inserts"], shell)
O["inserts x pcb"] = inter(M["inserts"], D["pcb"])
O["visor x ears / x display"] = (inter(vis, ears), inter(vis, lcdpcb))
O["ears x display keep-out"] = inter(ears + leds, D["comp"] + lcdpcb)
R["overlaps_and_clearances"] = O
print("overlaps", O, round(time.time() - t0, 1), flush=True)

# ---- closure: shell + visor + ears + rings fused must enclose the cavity (2 shells = sealed void, no see-through hole)
U = shell + vis + ears + rings
R["closure"] = dict(fused_solids=len(U.solids()), shells_of_first_solid=len(U.solids()[0].shells()),
                    sealed=len(U.solids()) == 1 and len(U.solids()[0].shells()) == 2)
print("closure", R["closure"], round(time.time() - t0, 1), flush=True)

# ---- feature dimensions (measured where possible, else by construction)
from build123d import Pos, Box
spig = HC.prism_y(HC.SPIG_SH, HC.Y_SEAM, HC.Y_SEAM, HC.Y_VB).moved(Location((0, 0, HZ)))
disc_out = ears & (Pos(0, 0, 0) * Box(2 * (HC.EAR_X0 + 0.3), 400, 400)).moved(Location((0, 0, 0)))
disc_out = ears - disc_out                                    # disc portion |x| > 49.8 (in the hole)
F = dict(
    rabbet_outer_lip_measured=walls[0][0],
    visor_spigot_clearance_measured=r3(spig.distance_to(shell)),
    ear_disc_radial_clearance_in_hole_measured=r3(disc_out.distance_to(shell)),
    visor_step_at_seam=HC.VIS_IN, visor_centre_thickness=r3(HC.Y_VB - SH.YF),
    rabbet_floor_glue_gap=HC.SPIG_GAP, lcd_front_y_local=HC.Y_L0, pcb_back_y_local=HC.Y_P1,
    keepout_back_y_local=r3(HC.Y_P1 + HC.KEEP),
    ear_lip_thickness=HC.LIP_T, ear_lip_radial=r3(HC.EAR_R + HC.EAR_CL - HC.LIP_R0),
    ear_boss_ring_radial=r3(HC.BOSS_R - HC.EAR_R - HC.EAR_CL),
    ear_disc_wall_beside_groove=r3(HC.EAR_R - HC.RING_R1 - HC.GROOVE_CL), ear_disc_floor_under_groove=r3(HC.RING_X0 - HC.EAR_X0),
    light_guide_ring_axial_x_radial=(r3(HC.RING_X1 - HC.RING_X0), r3(HC.RING_R1 - HC.RING_R0)),
    ear_proud_at_equator=r3(HC.EAR_X1 - SH.W / 2), ring_face_proud_of_disc=r3(HC.RING_X1 - HC.EAR_X1),
    seat_insert_hole_wall=r3(min(HC.HOLE_X - HC.INS_D / 2 - (HC.DW / 2 - HC.CZ), HC.HOLE_Z - HC.INS_D / 2 - (HC.DH / 2 - HC.CZ))),
    seat_floor_behind_insert=r3(HC.SEAT_T - HC.INS_L), rib_width=HC.RIB_W,
    volumes_mesh=dict(visor=r3(mv(vis)), ears=r3(mv(ears)), rings=r3(mv(rings)), seats=r3(mv(M["seats"])), ribs=r3(mv(M["ribs"]))),
    valid=dict(visor=vis.is_valid, ears=ears.is_valid, rings=rings.is_valid, leds=leds.is_valid,
               **{k: v.is_valid for k, v in D.items()}, **{k: v.is_valid for k, v in M.items()}))
R["features"] = F
print("features", F, round(time.time() - t0, 1), flush=True)
json.dump(R, open(f"{B}/checks.json" if HZ == 26.0 else f"{B}/checks_HZ{HZ:g}.json", "w"), indent=1, default=str)

import os
os.makedirs(f"{B}/stl", exist_ok=True)
for k, s in dict(shell=shell, visor=vis, ears=ears, led_rings=rings, led_boards=leds, **D, **M).items():
    export_stl(s, f"{B}/stl/HC{HZ:g}_{k}.stl", tolerance=0.01, angular_tolerance=0.1)
print("done", round(time.time() - t0, 1))
