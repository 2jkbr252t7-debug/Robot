"""NOVA mini - SHARED hollow head (variants A and B).  World mm, Z up, front -Y, robot right -X.
Every public function takes HZ = world z of the head bottom (A 26, B 27 with the neck extended) and returns
solids already in world position.  Exterior look = /tmp/claude-0/pan16/softhead.py patched to W108 H77 N3.6
(white shell y >= -28, black glass visor y -33..-28 with the 1 mm step, ear discs + cyan rings).

Head-local frame (before +HZ): bottom z=0, centre y=0, head centre z ZC_L = 38.5, front face y = -33.
Stack at the front (y):  visor -33..-28 (flange) + spigot -28..-27.1 | gasket -27.1..-26.9 | LCD -26.9..-23.9 |
PCB -23.7..-22.3 | component keep-out -22.3..-13.3 (9 mm).  Shell rim face y=-28, rabbet -28..-27 (shrink 1.5).
"""
import sys, math, functools
sys.path.insert(0, "/home/user/Robot"); sys.path.insert(0, "/tmp/claude-0/pan16")
from build123d import Pos, Rot, Box, Cylinder, Axis, Location, Solid, Compound, fillet
import softhead as SH

# ---------------------------------------------------------------- parameters (head-local, mm)
WALL = 2.5                    # nominal shell wall (normal)
Y_SEAM = -28.0                # white shell front face = SH.YF + SH.VISOR_T
VIS_IN = 1.0                  # visor outline = sec(y, shrink 1.0) -> the 1 mm step (unchanged look)
RAB_SH, RAB_D = 1.5, 1.0      # rabbet: inner part of the rim (shrink >= 1.5 of sec(Y_SEAM)) cut 1.0 deep
SPIG_SH, SPIG_GAP = 1.6, 0.1  # visor spigot shrink 1.6 (0.1 side clearance), 0.1 glue gap at the rabbet floor
Y_VB = Y_SEAM + RAB_D - SPIG_GAP          # visor back face (centre) = -27.1
GASKET = 0.2                              # LCD front 0.2 mm behind the visor (0.2 mm adhesive foam frame)
Y_L0 = Y_VB + GASKET                      # LCD front = -26.9
LCD_T, PCB_GAP, PCB_T, KEEP = 3.0, 0.2, 1.4, 9.0
Y_P0 = Y_L0 + LCD_T + PCB_GAP             # PCB front = -23.7
Y_P1 = Y_P0 + PCB_T                       # PCB back  = -22.3
DW, DH, DR = 86.0, 56.0, 2.0              # display model outline (board 85.5 x 55.5)
HOLE_X, HOLE_Z = 39.75, 24.75             # ASSUMED board mounting holes (3.0 mm from the 85.5 x 55.5 edges)
CZ = 6.5                                  # component-free corner zone (6.5 x 6.5 from each board corner)
SEAT_T = 6.0                              # corner seat thickness behind the PCB
INS_D, INS_L = 3.4, 4.0                   # glue-in M2 knurled insert (OD 3.2 x 3.0) hole
RIB_W, FIT = 3.0, 0.25                    # locating ribs, clearance to the 86 x 56 outline
EAR_Y, EAR_R, EAR_X0, EAR_X1 = -1.0, 13.0, 49.5, 55.5     # ear disc (|x| range), as SH.ears()
EAR_CL = 0.15                             # radial clearance of the disc in the shell hole
LIP_R0, LIP_T, BOSS_R = 11.0, 1.5, 16.0   # ear seat lip (inner r, thickness) and boss outer r
RING_R0, RING_R1, RING_X0, RING_X1 = 8.6, 10.5, 53.85, 55.85   # light-guide ring (2.0 thick, face as the old decal)
GROOVE_CL = 0.1
LED_HOLE_R, LED_HOLE_PCD = 0.8, 9.55        # D1.6 light holes stay inside the ring footprint (r 8.75..10.35)
INNER_Y0, INNER_Y1 = SH.YF + WALL, 29.5     # cavity loft range (-30.5: a start at -29 breaks the booleans)


def ZC_L():
    return SH.H / 2


def setup():
    """patch softhead to the final exterior (idempotent) and clear the caches"""
    SH.W, SH.H, SH.N = 108.0, 77.0, 3.6
    for f in (_outer_l, _inner_l, _visor_l, _shell_base_l):
        f.cache_clear()


def _w(s, HZ):
    return s.moved(Location((0, 0, HZ)))


def xcyl(r, x0, x1, y, z):
    x0, x1 = sorted((x0, x1))
    return Pos((x0 + x1) / 2, y, z) * Rot(0, 90, 0) * Cylinder(r, x1 - x0)


def ycyl(r, y0, y1, x, z):
    y0, y1 = sorted((y0, y1))
    return Pos(x, (y0 + y1) / 2, z) * Rot(90, 0, 0) * Cylinder(r, y1 - y0)


def rbox_y(w, h, r, y0, y1, zc, x=0.0):
    b = Pos(x, (y0 + y1) / 2, zc) * Box(w, y1 - y0, h)
    return fillet(b.edges().filter_by(Axis.Y), r)


def prism_y(shrink, y_sec, y0, y1):
    """straight prism (along Y) of the softhead section taken at y_sec"""
    s = SH.sec(y_sec, shrink=shrink)
    return Solid.make_loft([s.moved(Pos(0, y0 - y_sec, 0)), s.moved(Pos(0, y1 - y_sec, 0))])


def _dA(y, h=1e-3):
    return SH.W / 2 * (SH.factor(y + h) - SH.factor(y - h)) / (2 * h)


def inner_shrink(y):
    """2.5 everywhere; in the big back round the section shrink is increased to 2.5*sqrt(1+(da/dy)^2) so the
    NORMAL wall stays ~2.5 (a constant 2.5 section shrink leaves only 0.8 mm at the back)."""
    return WALL * math.sqrt(1 + _dA(y) ** 2) if y > 0 else WALL


@functools.lru_cache(None)
def _outer_l():
    return SH.outer()


@functools.lru_cache(None)
def _inner_l():
    ys = SH.ys(INNER_Y0, INNER_Y1, 40)
    return Solid.make_loft([SH.sec(y, shrink=inner_shrink(y)) for y in ys])


def head_outer(HZ):
    """full exterior volume of the head (white + visor zone), solid"""
    return _w(_outer_l(), HZ)


def inner_skin(HZ):
    """cavity solid: loft of softhead.sec(y, shrink=2.5) (slope-compensated in the back round), y -30.5..29.5;
    it pierces the rim face y=-28 (front opening, closed by the visor)"""
    return _w(_inner_l(), HZ)


# ---------------------------------------------------------------- visor (smoked clear resin, glued in the rabbet)
@functools.lru_cache(None)
def _visor_l():
    flange = Solid.make_loft([SH.sec(y, shrink=VIS_IN) for y in SH.ys(SH.YF, Y_SEAM, 12)])
    return flange + prism_y(SPIG_SH, Y_SEAM, Y_SEAM, Y_VB)


def visor(HZ):
    """black-glass visor: visible part = loft sec(y, 1.0) for y -33..-28 (flat front 90.9 x 67), flange back face on the
    rim face y=-28 (shrink 1.0..1.5), spigot sec(-28, 1.6) to y=-27.1 inside the shell rabbet (0.1 side clearance,
    0.1 glue gap at the rabbet floor y=-27).  Print in clear resin + smoke tint (or cast), front face polished."""
    return _w(_visor_l(), HZ)


# ---------------------------------------------------------------- ears + light-guide rings + LED boards
def _ear_axis_pts():
    zc = ZC_L()
    return [(EAR_Y + LED_HOLE_PCD * math.cos(math.radians(a)), zc + LED_HOLE_PCD * math.sin(math.radians(a)))
            for a in (45, 135, 225, 315)]


def ears(HZ):
    """2 black ear discs R13 x 6 (|x| 49.5..55.5, 1.5 mm proud at the equator as before) with an annular groove
    r 8.5..10.6 x 1.65 deep for the light-guide ring and 4 light holes D1.6 (PCD r 9.55) to the LED board behind"""
    zc, out = ZC_L(), None
    for sx in (-1, 1):
        d = xcyl(EAR_R, sx * EAR_X0, sx * EAR_X1, EAR_Y, zc)
        d = d - (xcyl(RING_R1 + GROOVE_CL, sx * RING_X0, sx * (EAR_X1 + 1), EAR_Y, zc)
                 - xcyl(RING_R0 - GROOVE_CL, sx * RING_X0 - sx, sx * (EAR_X1 + 2), EAR_Y, zc))
        for y, z in _ear_axis_pts():
            d = d - xcyl(LED_HOLE_R, sx * (EAR_X0 - 1), sx * (RING_X0 + 0.01), y, z)
        out = d if out is None else out + d
    return _w(out, HZ)


def led_rings(HZ):
    """cyan light-guide rings (clear/cyan resin) r 8.6..10.5, 2.0 thick (|x| 53.85..55.85): seated on the groove floor,
    front face 0.35 proud of the disc = the old decal position (unchanged look)"""
    zc, out = ZC_L(), None
    for sx in (-1, 1):
        r = xcyl(RING_R1, sx * RING_X0, sx * RING_X1, EAR_Y, zc) - xcyl(RING_R0, sx * (RING_X0 - 1), sx * (RING_X1 + 1), EAR_Y, zc)
        out = r if out is None else out + r
    return _w(out, HZ)


def led_boards(HZ):
    """internal: D21 x 1.0 LED PCB + 4 x 1.5x1.5x0.8 RGB LEDs (SK6805-1515) on the disc back face, inside the lip hole"""
    zc, out = ZC_L(), None
    for sx in (-1, 1):
        b = xcyl(10.5, sx * (EAR_X0 - 1.8), sx * (EAR_X0 - 0.8), EAR_Y, zc)
        for y, z in _ear_axis_pts():
            b = b + Pos(sx * (EAR_X0 - 0.4), y, z) * Box(0.8, 1.5, 1.5)
        out = b if out is None else out + b
    return _w(out, HZ)


def eyes_decal(HZ):
    """render-only: the eyes are LCD content; 0.3 mm decals in front of the visor face as in c_hnA (do not print)"""
    out = None
    for sx in (-1, 1):
        e = Pos(sx * 11.0, SH.YF - 0.15, ZC_L()) * Box(10.0, 0.3, 17.5)
        e = fillet([ed for ed in e.edges() if abs(ed.tangent_at(0.5).Y) > 0.9], 4.9)
        out = e if out is None else out + e
    return _w(out, HZ)


# ---------------------------------------------------------------- display (Waveshare ESP32-S3-Touch-LCD-3.5B)
def _corner_boxes(y0, y1, size):
    zc, out = ZC_L(), []
    for sx in (-1, 1):
        for sz in (-1, 1):
            out.append(Pos(sx * (DW / 2 - size / 2 + 0.5), (y0 + y1) / 2, zc + sz * (DH / 2 - size / 2 + 0.5)) *
                       Box(size + 1.0, y1 - y0, size + 1.0))
    return out


def display_parts(HZ):
    """lcd (86x56x3.0, front 0.2 behind the visor), pcb (86x56x1.4), comp = 9 mm component keep-out behind the full
    board minus the 4 component-free 6.5 x 6.5 corner zones (mounting-hole areas), gasket = 0.2 mm adhesive foam frame"""
    zc = ZC_L()
    comp = rbox_y(DW, DH, DR, Y_P1, Y_P1 + KEEP, zc)
    for b in _corner_boxes(Y_P1 - 1, Y_P1 + KEEP + 1, CZ):
        comp = comp - b
    gasket = rbox_y(DW - 0.4, DH - 0.4, DR, Y_VB, Y_L0, zc) - rbox_y(DW - 4.4, DH - 4.4, 1.0, Y_VB - 1, Y_L0 + 1, zc)
    d = dict(lcd=rbox_y(DW, DH, DR, Y_L0, Y_L0 + LCD_T, zc), pcb=rbox_y(DW, DH, DR, Y_P0, Y_P1, zc), comp=comp,
             gasket=gasket)
    return {k: _w(v, HZ) for k, v in d.items()}


def _display_mount_l(with_holes=True):
    """local: 4 corner SEATS (rear stops for the PCB back, only inside the 6.5 x 6.5 corner zones of the board, webbed
    out to the shell wall) + 4 edge-locating RIBS (0.25 mm to the 86 x 56 outline); both printed with the shell"""
    cav, zc = _inner_l(), ZC_L()
    seats, ribs, inserts = [], [], []
    for sx in (-1, 1):
        for sz in (-1, 1):
            x0, z0 = DW / 2 - CZ, DH / 2 - CZ                       # 36.5, 21.5
            blk = Pos(sx * (x0 + 75) / 2, Y_P1 + SEAT_T / 2, zc + sz * (z0 + 60) / 2) * Box(75 - x0, SEAT_T, 60 - z0)
            s = blk & cav
            hx, hz = sx * HOLE_X, zc + sz * HOLE_Z
            if with_holes:
                s = s - ycyl(INS_D / 2, Y_P1 - 0.1, Y_P1 + INS_L, hx, hz)
            seats.append(s)
            inserts.append(ycyl(1.6, Y_P1 + 0.2, Y_P1 + 3.2, hx, hz) - ycyl(0.8, Y_P1, Y_P1 + 4, hx, hz))
    ry0, ry1 = Y_L0, Y_P1 + 2.0
    for sx in (-1, 1):
        xa = DW / 2 + FIT
        ribs.append((Pos(sx * (xa + 75) / 2, (ry0 + ry1) / 2, zc) * Box(75 - xa, ry1 - ry0, RIB_W)) & cav)
        za = DH / 2 + FIT
        ribs.append((Pos(0, (ry0 + ry1) / 2, zc + sx * (za + 60) / 2) * Box(RIB_W, ry1 - ry0, 60 - za)) & cav)
    return dict(seats=Compound(seats), ribs=Compound(ribs), inserts=Compound(inserts))


def display_mount(HZ):
    """dict(seats, ribs) = printed retaining frame, fused into head_shell(); inserts = 4 glue-in knurled brass M2x3
    (OD 3.2, hole D3.4 x 4.0, epoxy) at the ASSUMED board holes (+-39.75, +-24.75) - for M2x5 screws from the front
    only if the real board's corner holes are not covered by the glass; otherwise the board is clamped between the seats
    (rear) and the visor via the 0.2 mm gasket (front)."""
    return {k: _w(v, HZ) for k, v in _display_mount_l().items()}


# ---------------------------------------------------------------- shell
def _common_adds_l():
    cav, zc = _inner_l(), ZC_L()
    bosses = [xcyl(BOSS_R, sx * (EAR_X0 - LIP_T), sx * 75, EAR_Y, zc) & cav for sx in (-1, 1)]
    dm = _display_mount_l()
    return list(bosses) + list(dm["seats"].solids()) + list(dm["ribs"].solids())


def _common_cuts_l():
    zc = ZC_L()
    c = [prism_y(RAB_SH, Y_SEAM, Y_SEAM - 1.0, Y_SEAM + RAB_D)]                       # visor rabbet
    for sx in (-1, 1):
        c.append(xcyl(EAR_R + EAR_CL, sx * EAR_X0, sx * 70, EAR_Y, zc))               # ear disc seat (through)
        c.append(xcyl(LIP_R0, sx * (EAR_X0 - LIP_T - 1.0), sx * (EAR_X0 + 0.5), EAR_Y, zc))   # lip hole (light/wires)
    return c


@functools.lru_cache(None)
def _shell_base_l():
    """outer - white zone in front of the seam - cavity + common internal features (not yet cut)"""
    s = _outer_l() - SH.white_cut() - _inner_l()
    for a in _common_adds_l():
        s = s + a
    return s


def _fuse(base, items):
    if items is None:
        return base
    for it in (items if isinstance(items, (list, tuple)) else [items]):
        base = base + it
    return base


def _cut(base, items):
    if items is None:
        return base
    for it in (items if isinstance(items, (list, tuple)) else [items]):
        base = base - it
    return base


def clip_inside(shape, HZ):
    """helper for variants: clip an internal feature to the head's exterior so it can never show outside"""
    return shape & _w(_outer_l() - SH.white_cut(), HZ)


def head_shell(HZ, cuts=None, adds=None):
    """HOLLOW white shell (wall 2.5): visor rabbet, ear seats (through hole R13.15 + lip 1.5 + boss R16), display seats
    and ribs.  Order: base + common adds -> + variant adds -> - common cuts -> - variant cuts (world solids/lists)."""
    s = _fuse(_w(_shell_base_l(), HZ), adds)
    s = _cut(s, [_w(c, HZ) for c in _common_cuts_l()])
    s = _cut(s, cuts)
    if hasattr(s, "solids") and len(s.solids()) == 1:
        s = s.solids()[0]
    return s


setup()


def mesh_volume(shape, tol=0.01):
    """reliable volume: OCC GProp is WRONG for the closed periodic B-spline loft faces (outer loft reports 468256 mm3,
    true ~443900 = mesh = analytic) - use this (signed tetra sum of the tessellation) for all volume checks"""
    import numpy as np
    if shape is None or not shape.solids():
        return 0.0
    v, t = shape.tessellate(tol, 0.1)
    if not t:
        return 0.0
    V = np.array([[p.X, p.Y, p.Z] for p in v]); T = np.array(t)
    return float(np.einsum('ij,ij->i', V[T[:, 0]], np.cross(V[T[:, 1]], V[T[:, 2]])).sum() / 6)
