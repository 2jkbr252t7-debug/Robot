"""Orthographic z-buffer (numpy) for the seam visibility check: which part is the first one hit per pixel."""
import math
import numpy as np


def basis(az, el):
    """view direction d (camera -> scene), screen right u, screen up v.  az 0 = from the front (-Y), 180 = from the
    back; el > 0 = camera above (looking down)"""
    a, e = math.radians(az), math.radians(el)
    d = np.array([math.sin(a) * math.cos(e), math.cos(a) * math.cos(e), -math.sin(e)])
    u = np.cross(d, [0, 0, 1.0]); u /= np.linalg.norm(u)
    v = np.cross(u, d)
    return u, d, v


def zbuffer(T, ids, az, el, box, px=0.05):
    """T (n,3,3) world triangles, ids (n,) int labels; box = (xmin,xmax,ymin,ymax,zmin,zmax) world region whose
    projection defines the window.  Returns the id image (-1 = background)."""
    u, d, v = basis(az, el)
    c = np.array([[x, y, z] for x in box[:2] for y in box[2:4] for z in box[4:]])
    U0, U1, V0, V1 = (c @ u).min(), (c @ u).max(), (c @ v).min(), (c @ v).max()
    nx, ny = int((U1 - U0) / px) + 1, int((V1 - V0) / px) + 1
    TU, TV, TD = T @ u, T @ v, T @ d                                   # (n,3)
    i0 = np.floor((TU.min(1) - U0) / px - 0.5).astype(int) + 1
    i1 = np.floor((TU.max(1) - U0) / px - 0.5).astype(int)
    j0 = np.floor((TV.min(1) - V0) / px - 0.5).astype(int) + 1
    j1 = np.floor((TV.max(1) - V0) / px - 0.5).astype(int)
    keep = np.where((i1 >= 0) & (i0 < nx) & (j1 >= 0) & (j0 < ny) & (i1 >= i0) & (j1 >= j0))[0]
    depth = np.full((ny, nx), np.inf); img = np.full((ny, nx), -1, int)
    for k in keep:
        a0, a1, b0, b1 = max(i0[k], 0), min(i1[k], nx - 1), max(j0[k], 0), min(j1[k], ny - 1)
        if a1 < a0 or b1 < b0:
            continue
        X = U0 + (np.arange(a0, a1 + 1) + 0.5) * px
        Y = V0 + (np.arange(b0, b1 + 1) + 0.5) * px
        X, Y = np.meshgrid(X, Y)
        (x0, x1, x2), (y0, y1, y2) = TU[k], TV[k]
        den = (y1 - y2) * (x0 - x2) + (x2 - x1) * (y0 - y2)
        if abs(den) < 1e-12:
            continue
        w0 = ((y1 - y2) * (X - x2) + (x2 - x1) * (Y - y2)) / den
        w1 = ((y2 - y0) * (X - x2) + (x0 - x2) * (Y - y2)) / den
        w2 = 1 - w0 - w1
        m = (w0 >= -1e-9) & (w1 >= -1e-9) & (w2 >= -1e-9)
        if not m.any():
            continue
        z = w0 * TD[k, 0] + w1 * TD[k, 1] + w2 * TD[k, 2]
        sub = depth[b0:b1 + 1, a0:a1 + 1]
        upd = m & (z < sub)
        sub[upd] = z[upd]
        img[b0:b1 + 1, a0:a1 + 1][upd] = ids[k]
    return img


def seen(T, ids, names, internal, views, box, px=0.05):
    """count pixels (px^2 each) of the internal parts per view; returns (worst, per-view dict)"""
    out, worst = {}, 0
    for az, el in views:
        img = zbuffer(T, ids, az, el, box, px)
        cnt = {names[i]: int((img == i).sum()) for i in np.unique(img) if i >= 0 and names[i] in internal}
        cnt = {k: n for k, n in cnt.items() if n}
        out[f"az{az}_el{el}"] = cnt
        worst = max(worst, sum(cnt.values()))
    return worst, out
