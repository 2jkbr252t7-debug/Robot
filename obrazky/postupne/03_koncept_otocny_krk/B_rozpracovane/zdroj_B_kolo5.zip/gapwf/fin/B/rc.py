"""R4: local wall thickness by inward ray casting on a part STL (Moller-Trumbore, numpy).
For area-weighted random surface samples a ray is shot along -normal; the first hit counts as a WALL only if the hit
face is roughly opposite (normal dot < -0.7, same rule as the round-3 review).  Rays longer than LMAX -> 'thick'."""
import numpy as np

LMAX = 3.0


def ray_hits(O, Dv, T, eps=1e-4):
    v0, e1, e2 = T[:, 0], T[:, 1] - T[:, 0], T[:, 2] - T[:, 0]
    out, tid = np.full(len(O), np.inf), np.full(len(O), -1)
    if len(T) == 0:
        return out, tid
    o, d = O[:, None, :], Dv[:, None, :]
    p = np.cross(d, e2[None]); det = np.einsum('rtk,tk->rt', p, e1)
    ok0 = np.abs(det) > 1e-12
    inv = np.where(ok0, 1.0 / np.where(ok0, det, 1.0), 0.0)
    s = o - v0[None]; u = np.einsum('rtk,rtk->rt', s, p) * inv
    q = np.cross(s, e1[None]); v = np.einsum('rtk,rtk->rt', d, q) * inv
    t = np.einsum('rtk,tk->rt', q, e2) * inv
    ok = ok0 & (u >= -1e-9) & (v >= -1e-9) & (u + v <= 1 + 1e-9) & (t > eps)
    tt = np.where(ok, t, np.inf)
    return tt.min(1), tt.argmin(1)


def thickness(T, nmax=15000, seed=0, region=None, chunk=48):
    """T: (n,3,3) triangles.  region: optional (x0,x1,y0,y1,z0,z1) box for the SAMPLES.  -> P, N, th"""
    T = np.asarray(T, np.float64)
    n = np.cross(T[:, 1] - T[:, 0], T[:, 2] - T[:, 0]); a = np.linalg.norm(n, axis=1) / 2
    n = n / np.maximum(2 * a[:, None], 1e-12)
    w = a.copy()
    if region is not None:
        c = T.mean(1); x0, x1, y0, y1, z0, z1 = region
        w = w * ((c[:, 0] >= x0) & (c[:, 0] <= x1) & (c[:, 1] >= y0) & (c[:, 1] <= y1) & (c[:, 2] >= z0) & (c[:, 2] <= z1))
    rng = np.random.RandomState(seed)
    idx = rng.choice(len(T), size=nmax, p=w / w.sum())
    r1, r2 = rng.rand(nmax, 1), rng.rand(nmax, 1); fl = (r1 + r2) > 1
    r1, r2 = np.where(fl, 1 - r1, r1), np.where(fl, 1 - r2, r2)
    P = T[idx, 0] + r1 * (T[idx, 1] - T[idx, 0]) + r2 * (T[idx, 2] - T[idx, 0])
    N = n[idx]
    order = np.lexsort((np.floor(P[:, 2] / 2), np.floor(P[:, 1] / 2), np.floor(P[:, 0] / 2)))   # spatially compact chunks
    P, N, idx = P[order], N[order], idx[order]
    tmin, tmax = T.min(1), T.max(1)
    th = np.full(nmax, np.inf)
    for i in range(0, nmax, chunk):
        Pc, Nc = P[i:i + chunk], N[i:i + chunk]
        lo, hi = Pc.min(0) - LMAX, Pc.max(0) + LMAX
        m = np.all(tmax >= lo, 1) & np.all(tmin <= hi, 1)
        ti = np.nonzero(m)[0]
        h, k = ray_hits(Pc - Nc * 1e-4, -Nc, T[ti])
        hit = np.isfinite(h)
        opp = np.zeros(len(h), bool)
        opp[hit] = np.einsum('ij,ij->i', n[ti[k[hit]]], Nc[hit]) < -0.7
        th[i:i + chunk] = np.where(opp & (h <= LMAX), h, np.inf)
    return P, N, th


def summary(P, N, th, lim=1.2, zoff=0.0, top=12, cell=1.5):
    fin = th[np.isfinite(th)]
    out = dict(samples=int(len(th)), min=round(float(fin.min()), 3) if len(fin) else None,
               n_lt_1p2=int((th < lim).sum()), n_lt_1p0=int((th < 1.0).sum()), n_lt_0p6=int((th < 0.6).sum()))
    cl = {}
    for i in np.argsort(th):
        if th[i] >= lim:
            break
        key = tuple(np.round(P[i] / cell).astype(int))
        if key not in cl:
            q = P[i] + np.array([0, 0, zoff])
            cl[key] = dict(t=round(float(th[i]), 3), at=[round(float(x), 2) for x in q], n=[round(float(x), 2) for x in N[i]])
        if len(cl) >= top:
            break
    out["thin_spots"] = list(cl.values())
    return out
