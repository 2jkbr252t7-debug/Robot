"""Variant B round 5 - measured checks -> checks.json  (run: /opt/venv/cad/bin/python checks.py)"""
import sys, json, time, math, warnings
warnings.filterwarnings("ignore")
sys.path.insert(0, "/tmp/claude-0/gapwf/fin/B")
import build as B
import head_common as HC
from build123d import Pos, Box, Compound, Location, Vector
t0 = time.time()
mv = HC.mesh_volume
import os
REUSE = os.environ.get("REUSE") == "1"
try:
    OLD = json.load(open("/tmp/claude-0/gapwf/fin/B/checks.json"))
except Exception:
    OLD = {}
R = {"units": "mm / mm3", "pose": "extended (head bottom z=27, hinge axis z=16.5) unless stated; rest = -20; neck halves CLOSED as built/exported (front y -10..0, back 0..10)", "round": 5}

if REUSE:
    R["reuse_note"] = ("sections 2-4 come from the full round-5 run (checks_run_r5.log, 4568 s) of the same geometry; "
                       "only the head cross-screw heads changed afterwards (ISO 7380 dk 3.5) and they take no part in 2-4")


def r3(x):
    return round(float(x), 3)


def log(*a):
    print(f"[{time.time() - t0:6.1f}]", *a, flush=True)


def comp(lst):
    return lst[0] if len(lst) == 1 else Compound(list(lst))


P = B.build_all()
S = {k: comp([s for s, g in v]) for k, v in P.items()}
G = {k: [g for s, g in v] for k, v in P.items()}
R["validity"] = {k: [[bool(s.is_valid), len(s.solids())] for s, g in v] for k, v in P.items()}
log("built")
# individual named solids
shell, nf, nb, cap, lug = S["hlava_skrupina"], S["krk_predna_polovica"], S["krk_zadna_polovica"], S["usko_kryt"], S["usko_lozisko"]
servo, horn = S["servo_MG90S"], S["paka"]
bo, bi = [s for s, g in P["loziska_MR85"]]
pin, dowels = [s for s, g in P["capy"]]
nscr, hscr, xscr, dins = [s for s, g in P["skrutky"]]
cab_n, cab_h, lead = [s for s, g in P["kabel"]]
lcd, pcb, kom, gask = [s for s, g in P["displej"]]
disc, ring = S["golier_kotuc"], S["golier_prstenec"]
LOFTY = {"hlava_skrupina", "sklo"}               # loft faces: OCC volume unreliable -> mesh volume
NAMED = dict(shell=shell, visor=S["sklo"], ears=S["usi"], rings=S["led_kruzky"], ledb=S["led_dosky"], lcd=lcd, pcb=pcb,
             comp=kom, gasket=gask, neck_front=nf, neck_back=nb, cap=cap, lug_plus=lug, horn=horn, horn_screw=hscr,
             servo=servo, brg_outer=bo, brg_inner=bi, pin=pin, dowels=dowels, neck_screws=nscr, cross_screws=xscr,
             disp_inserts=dins, cable_neck=cab_n, cable_head=cab_h, servo_lead=lead, disc=disc, ring=ring,
             foam=S["pena_serva"])
INTENDED = {("cable_neck", "cable_head"): "same wire bundle, joint sphere on the hinge axis", ("neck_back", "dowels"): "R5: D2.0 reamed hole + epoxy in the BACK half (nominal line contact; front D2.02 slip)",
            ("cap", "horn"): "4 crush ribs 0.1 on the arm flanks (intended press, zero backlash)",
            ("shell", "lug_plus"): "R3: 3 crush ribs (0.05) per apron-peg hole grip the D2 pegs (friction hold, removable)"}


def vol(a, b, na, nb_):
    x = a & b
    if x is None or not x.solids():
        return 0.0
    return mv(x) if ({na, nb_} & {"shell", "visor"}) else x.volume


def ivol(a, b, mesh=False):
    x = a & b
    if x is None or not x.solids():
        return 0.0
    return r3(mv(x) if mesh else x.volume)


def bb_overlap(a, b, m=0.05):
    A, Bb = a.bounding_box(), b.bounding_box()
    a0, a1, b0, b1 = [tuple(v) for v in (A.min, A.max, Bb.min, Bb.max)]
    return all(a0[i] - m <= b1[i] and b0[i] - m <= a1[i] for i in range(3))


# ---------------------------------------------------------------- 1. pairwise overlaps, extended, tilt 0
names = list(NAMED)
pairs, worst = {}, 0.0
for i, na in enumerate(names):
    for nb_ in names[i + 1:]:
        a, b = NAMED[na], NAMED[nb_]
        if not bb_overlap(a, b):
            continue
        v = vol(a, b, na, nb_)
        if v > 1e-3:
            key = f"{na} x {nb_}"
            pairs[key] = r3(v) if (na, nb_) not in INTENDED else f"{r3(v)} ({INTENDED[(na, nb_)]})"
            if (na, nb_) not in INTENDED:
                worst = max(worst, v)
R["1_overlaps_tilt0"] = dict(nonzero_pairs=pairs, worst_unintended_mm3=r3(worst), n_parts=len(names))
log("overlaps", pairs)


def save():
    json.dump(R, open("/tmp/claude-0/gapwf/fin/B/checks.json", "w"), indent=1, ensure_ascii=False)


save()
# ---------------------------------------------------------------- 2. tilt sweep -40..40 step 5 (moving head side vs static neck side)
hinge_box = Pos(0, 0, B.HZ + 4) * Box(70, 50, 22)                    # head shell near the hinge (faster distances)
shell_h = shell & hinge_box
MOV = dict(shell=shell_h, visor=S["sklo"], cap=cap, lug_plus=lug, horn=horn + hscr, brg_outer=bo)
MOV["cable_head"] = cab_h
STA = dict(neck_front=nf, neck_back=nb, servo=servo, pin=pin, brg_inner=bi, dowels=dowels, neck_screws=nscr, lead=lead,
           cable_neck=cab_n, foam=S["pena_serva"])
SKIP = {("horn", "servo"): "horn is ON the spline (turns with the shaft)", ("brg_outer", "brg_inner"): "same bearing",
        ("cable_head", "cable_neck"): "same wire bundle, joint ON the hinge axis (pure twist)"}
if REUSE and "2_tilt_sweep" in OLD:
    R["2_tilt_sweep"] = OLD["2_tilt_sweep"]
else:
    sweep, minpair = {}, {}
    for th in range(-40, 45, 5):
        row = {}
        for mn, m in MOV.items():
            mr = m.rotate(B.AX, th) if th else m
            for sn, st in STA.items():
                if (mn, sn) in SKIP or not bb_overlap(mr, st, 1.0):
                    continue
                d = mr.distance_to(st)
                row[f"{mn}-{sn}"] = r3(d)
                k = f"{mn}-{sn}"
                if k not in minpair or d < minpair[k][0]:
                    minpair[k] = (r3(d), th)
        sweep[th] = min(row.values())
        log("tilt", th, sweep[th], min(row, key=row.get))
    R["2_tilt_sweep"] = dict(min_clearance_per_angle=sweep, min_per_pair_mm_at_deg=minpair, overall_min=min(sweep.values()),
                             skipped_pairs={f'{a}-{b}': v for (a, b), v in SKIP.items()})
save()
# ---------------------------------------------------------------- 3. retraction (lift 0 -> -20) at tilt 0, vs collar + torso
torso = B.torso()
torso_top = torso & (Pos(0, 0, 0.175) * Box(200, 200, 8.15))       # z -3.9..4.25 (below: illustrative solid torso, real one has a neck well)
COL = dict(disc=disc, ring=ring, torso=torso_top)
head_ext = HC.head_outer(B.HZ)                                       # exterior of the head (shell+visor envelope)
LMOV = dict(neck_front=nf, neck_back=nb, cap=cap, lug_plus=lug, head=head_ext)
if REUSE and "3_retraction" in OLD:
    R["3_retraction"] = OLD["3_retraction"]
else:
    lift_rows = {}
    for lf in [0, -2.5, -5, -7.5, -10, -12.5, -15, -17.5, -20]:
        row = {}
        for mn, m in LMOV.items():
            mm = m.moved(Location((0, 0, lf)))
            for cn, c in COL.items():
                if bb_overlap(mm, c, 1.0):
                    row[f"{mn}-{cn}"] = r3(mm.distance_to(c))
        lift_rows[lf] = dict(min=min(row.values()) if row else None, at=min(row, key=row.get) if row else None)
        log("lift", lf, lift_rows[lf])
    shell_rest = shell.moved(Location((0, 0, -B.LIFT)))
    R["3_retraction"] = dict(per_lift=lift_rows, head_to_torso_gap_at_rest=r3(shell_rest.distance_to(torso_top)),
                             head_to_disc_gap_at_rest=r3(shell_rest.distance_to(disc)))
save()
# ---------------------------------------------------------------- 4. tilt vs collar while retracting (firmware interlock)
if REUSE and "4_tilt_allowed_vs_lift" in OLD:
    R["4_tilt_allowed_vs_lift"] = OLD["4_tilt_allowed_vs_lift"]
else:
    LIFTS = [0, -1, -2, -3, -4, -5, -7.5, -10, -12.5, -15, -17.5, -20]
    TILTS = [40, 35, 30, 25, 20, 15, 10, 5, 2.5]
    table = {float(k): v for k, v in OLD.get("4_partial", {}).items()}     # resumable (same code, same geometry)
    head4 = LMOV["head"] & (Pos(0, 0, B.HZ + 10) * Box(200, 200, 20))      # head bottom 20 mm (the rest is >=15 higher)
    for lf in LIFTS:
        if float(lf) in table:
            continue
        row = {}
        for sg in (1, -1):
            best = 0.0
            for th in TILTS:
                dmin = 99.0
                for mn in ("head", "cap", "lug_plus"):
                    mm = (head4 if mn == "head" else LMOV[mn]).rotate(B.AX, sg * th).moved(Location((0, 0, lf)))
                    for c in (disc, ring, torso_top):
                        if bb_overlap(mm, c, 1.0):
                            dmin = min(dmin, mm.distance_to(c))
                if dmin >= 0.24:
                    best = th
                    break
            row["nod_down_+" if sg > 0 else "nod_up_-"] = best
        table[float(lf)] = row
        R["4_partial"] = table
        save()
        log("max tilt at lift", lf, row)
    R.pop("4_partial", None)
    R["4_tilt_allowed_vs_lift"] = dict(
        max_tilt_deg_keeping_the_0p25_slot_clearance_vs_collar_and_torso=table,
        firmware="R3 rule: between two listed lifts use the value of the MORE RETRACTED one (step, no interpolation); "
                 "full +-40 only at full extension; below -17.5 (to rest -20) tilt 0")
    tb = sorted(((float(k), v) for k, v in table.items()), reverse=True)
    def rule(lf, key):                                   # value of the next listed lift at or below lf
        cand = [v[key] for k, v in tb if k <= lf + 1e-9]
        return cand[0] if cand else 0.0
    ver = {}
    for lf in [-0.5, -1.5, -2.5, -3.5, -4.5, -6.25, -8.75, -11.25, -13.75, -16.25, -17.6, -18.75, -19.5]:
        row = {}
        for sg, key in ((1, "nod_down_+"), (-1, "nod_up_-")):
            th = rule(lf, key)
            dmin = 99.0
            for mn in ("head", "cap", "lug_plus"):
                mm = (head4 if mn == "head" else LMOV[mn])
                mm = (mm.rotate(B.AX, sg * th) if th else mm).moved(Location((0, 0, lf)))
                for c in (disc, ring, torso_top):
                    if bb_overlap(mm, c, 1.0):
                        dmin = min(dmin, mm.distance_to(c))
            row[key] = dict(tilt=th, min_clear=r3(dmin))
        ver[lf] = row
        log("rule check", lf, row)
    R["4_tilt_allowed_vs_lift"]["rule_check_between_points"] = ver
    R["4_tilt_allowed_vs_lift"]["rule_min_clear"] = min(v[k]["min_clear"] for v in ver.values() for k in v)
save()
# ---------------------------------------------------------------- 5. containment (internal parts inside the exterior)
from build123d import Axis
env_neck, env_cap, env_lug = B.neck_env(), B.lug_blank(-1), B.lug_blank(1)
ENV = env_neck + env_cap + env_lug
head_out = HC.head_outer(B.HZ)
above_zb = Pos(0, 0, B.ZB + 100) * Box(300, 300, 200)                  # z > ZB (the neck bottom opens into the torso)
gap = B.xcyl(6.6, -B.LUG0, -B.KN, 0, B.AXZ) + B.xcyl(6.6, B.KN, B.LUG0, 0, B.AXZ)   # 0.5 mm hinge gaps, r <= 6.6
cont = {}
for n, p in dict(servo=servo, foam=S["pena_serva"], pin=pin, brg_inner=bi, brg_outer=bo, dowels=dowels, neck_screws=nscr, horn=horn,
                 horn_screw=hscr, cable_neck=cab_n & above_zb, servo_lead=lead & above_zb).items():
    out = p - ENV
    v = out.volume if out is not None and out.solids() else 0.0
    vg = (out & gap).volume if v > 1e-4 else 0.0
    cont[n] = dict(outside_mm3=r3(v), of_which_inside_hinge_gap_r_le_6_6=r3(vg))
for n, p in dict(lcd=lcd, pcb=pcb, comp=kom, gasket=gask, led_boards=S["led_dosky"], cross_screws=xscr,
                 disp_inserts=dins, cable_head=cab_h & (Pos(0, 0, B.HZ + 50.5) * Box(300, 300, 100))).items():
    out = p - head_out
    cont[n] = dict(outside_head_mm3=r3(mv(out)) if out is not None and out.solids() else 0.0)
R["5_containment"] = cont
log("containment", cont)
save()
# ---------------------------------------------------------------- 6. wall minima
big = Pos(0, 0, 20) * Box(160, 120, 160)
excl = (Pos(0, 0, B.ZB - 49) * Box(200, 200, 101.0) + B.xcyl(8.5, 17.4, 18.6, 0, B.AXZ) +
        B.xcyl(8.5, -18.6, -17.4, 0, B.AXZ))                          # neck bottom face + hinge-gap bore mouths (open by design)
out_n = (big - env_neck) - excl
cv = B.closed_void_dict()                                            # R4: closed-state voids
OPEN = {k for k in cv if k.startswith("screw_cbore") or k.startswith("screw_clear")}   # M2 head counterbores (in the torso)
clipx = big - B.xcyl(10.6, 17.3, 18.7, 0, B.AXZ) - B.xcyl(10.6, -18.7, -17.3, 0, B.AXZ)   # voids clipped off the hinge mouths
walls = {"note": "voids clipped off the hinge-mouth slabs 17.3<=|x|<=18.7 (r<=10.6); outside = neck exterior minus the bottom face zone (z<ZB+1.5) and the "
                 "hinge-gap mouths r<=8.5 (counterbore / hub bore open there by design); screw counterbores + clearance "
                 "holes are open to the front face by design (always inside the torso)",
         "neck_void_to_outside": {k: r3((v & clipx).distance_to(out_n)) for k, v in cv.items() if k not in OPEN}}
vv, merged, ks = {}, [], list(cv)
for i, a in enumerate(ks):
    for b in ks[i + 1:]:
        if not bb_overlap(cv[a], cv[b], 4.0):
            continue
        x = cv[a] & cv[b]
        if x is not None and x.solids() and x.volume > 1e-4:
            merged.append(f"{a}+{b}")
            continue
        d = cv[a].distance_to(cv[b])
        if d < 1e-6:                                                   # R4: touching on the parting plane = one hole
            merged.append(f"{a}+{b}")
            continue
        if d < 4.0:
            vv[f"{a}-{b}"] = r3(d)
walls["neck_void_to_void_lt4"] = vv
walls["merged_voids_by_design"] = merged
walls["neck_min_wall"] = min(list(vv.values()) + list(walls["neck_void_to_outside"].values()))
log("neck walls", walls)
save()
# lugs: internal voids to the lug exterior (excluding the inner face toward the knuckle) + tenon / sleeve / lip walls
half_m = Pos(-B.LUG0 - 50.6, 0, 0) * Box(100, 100, 200)
half_p = Pos(B.LUG0 + 50.6, 0, 0) * Box(100, 100, 200)
gh_c, gh_l = B.groove_holes(-1), B.groove_holes(1)
cap_v = env_cap - cap
for g in B.groove_holes(-1, 1.3):
    cap_v = cap_v - g
lug_v = (B.xcyl(3.2, B.BRG_X1 - 0.01, B.LCH_Z0, 0, B.AXZ) + (B.lug_channel() & (Pos(0, 0, B.HZ - 50.3) * Box(200, 200, 100)))) & half_p
ten_z = (B.HZ - 0.4, B.HZ + 8.4)
chan_t = B.zcyl(0.8, ten_z[0], ten_z[1], x=B.LCH_X2)
probe = Pos(B.LCH_X2, 0, sum(ten_z) / 2) * Box(10, 30, ten_z[1] - ten_z[0])
outside_t = (probe - lug) - B.zcyl(0.81, ten_z[0] - 1, ten_z[1] + 1, x=B.LCH_X2)
s0, s1, sr0, sr1 = B.SLV
ring_sl = lug & B.xcyl(8.0, s0 + 0.2, s0 + 0.4, 0, B.AXZ)
ro = ring_sl.bounding_box().size.Y / 2
ri = math.sqrt(max(ro * ro - ring_sl.volume / 0.2 / math.pi, 0))
lip_sl = nf & B.xcyl(9.0, -18.3, -18.1, 0, B.AXZ)
walls["lugs"] = dict(cap_voids_to_outer_surface=r3((cap_v & half_m).distance_to((big - env_cap) & half_m)),
                     lug_voids_to_outer_surface=r3(lug_v.distance_to((big - env_lug) & half_p)),
                     lug_wire_channel_in_tenon_min_wall=r3(chan_t.distance_to(outside_t)),
                     lug_wire_channel_to_groove_holes=r3(min(B.lug_channel().distance_to(g) for g in gh_l)),
                     lug_wire_channel_to_mr85_stop_shoulder=r3(B.lug_channel().distance_to(B.xcyl(4.0, B.SLV[0], B.BRG_X1, 0, B.AXZ))),
                     lug_wire_channel_to_lug_outer_face=r3(B.LUG1 - B.LCH_X - 0.8),
                     cap_tenon_core_between_grooves=r3(gh_c[0].distance_to(gh_c[1])),
                     lug_tenon_core_between_grooves=r3(gh_l[0].distance_to(gh_l[1])),
                     lug_sleeve_wall_measured=dict(r_in=r3(ri), r_out=r3(ro), wall=r3(ro - ri)),
                     knuckle_lip_ring_radial=r3(B.LIP[1] - B.LIP[0]), lip_section_area_front_half_mm2=r3(lip_sl.volume / 0.2),
                     counterbore_wall_to_knuckle_surface=r3(B.RK - B.CB_R),
                     head_chamber_to_counterbore=r3(cv["head_chamber"].distance_to(
                         B.xcyl(B.CB_R, B.CB_X, B.KN, 0, B.AXZ) - B.xcyl(2.6, 0, 30, 0, B.AXZ))),
                     knuckle_end_wall_minus_x_over_boss=r3(B.xcyl(5.9 + B.G, B.BOSS_FLOOR, B.XC, 0, B.AXZ).distance_to(
                         Pos(-B.KN - 5, 0, B.AXZ) * Box(10, 30, 30))))
log("lug walls", walls["lugs"])
R["6_walls"] = walls
save()
# ---------------------------------------------------------------- 7. assembly order (paths)
neck_st = nf + nb
asm = {}
hs = horn + hscr
asm["1_horn_pushed_on_spline_from_-X (vs neck halves)"] = {s: ivol(hs.moved(Location((-s, 0, 0))), neck_st)
                                                          for s in (3.5, 2.0, 1.0, 0.0)}
lugset = lug + bo + bi                                                 # MR85 glued in the sleeve
asm["2_plus_lug_with_MR85_slid_-X_over_pin (vs neck+pin)"] = {
    s: ivol(lugset.moved(Location((s, 0, 0))), neck_st + pin) for s in (3.0, 2.0, 1.0, 0.5, 0.0)}
asm["3_cap_slid_+X_over_horn_arms (vs neck incl. lip + servo + aprons)"] = {
    s: ivol(cap.moved(Location((-s, 0, 0))), neck_st + servo + lug) for s in (3.0, 2.0, 1.0, 0.5, 0.0)}
asm["3b_cap_vs_horn_during_the_slide (only the 4 crush ribs touch the arms)"] = {
    s: ivol(cap.moved(Location((-s, 0, 0))), horn + hscr) for s in (3.0, 2.0, 1.0, 0.5, 0.0)}
lower = {}
for s in (12.0, 8.0, 4.0, 2.0, 1.0, 0.5, 0.0):
    x = shell.moved(Location((0, 0, s))) & (cap + lug + neck_st)
    lower[s] = r3(mv(x)) if x is not None and x.solids() else 0.0
asm["4_head_lowered_vertically_onto_both_tenons (vs lugs+neck)"] = lower
asm["4_note"] = "values at s<=2.1 include only the intended crush-rib contact on the 2 apron pegs (0.09 mm3 at s=0)"
pk = {}
for s_ in (3.0, 2.5, 2.0, 1.0, 0.0):
    x = shell.moved(Location((0, 0, s_))) & (cap + nf + nb + B.lug_plus().__sub__(B.apron_pegs()))
    pk[s_] = r3(mv(x)) if x is not None and x.solids() else 0.0
asm["4b_same_without_the_pegs (must be 0)"] = pk
drv = {}
for sx in (-1, 1):
    for x in B.SCR_X:
        tool = B.ycyl(2.0, -45.0, -B.PAD[2] - 1.15, sx * x, B.ZS)        # R5: D4.0 bit shank path from the front opening
        y = tool & shell
        drv[f"x={sx * x:+.1f}"] = r3(mv(y)) if y is not None and y.solids() else 0.0
asm["5_cross_screw_driver_path_through_front_opening (vs shell, before display/visor)"] = drv
dp_, dm_ = HC.display_parts(B.HZ), HC.display_mount(B.HZ)
obst = [dp_["lcd"], dp_["pcb"], dp_["comp"], gask, dm_["seats"], dm_["ribs"], dm_["inserts"], S["led_dosky"]]
asm["5b_driver_path_min_clearance_with_display_installed (service: only the visor comes off)"] = {
    f"x={sx * x:+.1f}": r3(min(B.ycyl(2.0, -45.0, -B.PAD[2] - 1.15, sx * x, B.ZS).distance_to(o) for o in obst))
    for sx in (-1, 1) for x in B.SCR_X}
tail = S["sklo"] & (Pos(0, -27.35, B.HZ + 38.5) * Box(200, 0.5, 200))        # spigot tail y -27.6..-27.1
asm["6_visor_seating"] = dict(flange_on_shell_front_face_gap=r3(S["sklo"].distance_to(shell)),
                              spigot_tail_to_shell_gap_for_0p1_tape=r3(tail.distance_to(shell)),
                              spigot_end_y=r3(S["sklo"].bounding_box().max.Y))
R["7_assembly"] = asm
log("assembly", asm)
save()
# ---------------------------------------------------------------- 8. visibility proxies
vis = {}
slab = Pos(0, 0, B.HZ - 0.15) * Box(120, 60, 0.1)                     # just under the head bottom
for sx, part, nm in ((-1, env_cap, "cap"), (1, env_lug, "lug_plus")):         # outer envelopes (internal wire channel ignored)
    xa, xb = sorted((sx * (B.TEN[0] - 0.1), sx * (B.TEN[1] + 0.1)))
    sl = B.rbox(xa, xb, -B.TEN[2] - 0.1, B.TEN[2] + 0.1, B.HZ - 1.5, B.TEN[4] + 0.5, 1.1, Axis.Z)
    miss = (sl & slab) - (part & slab)
    vis[f"head_floor_slot_{nm}_not_covered_by_web_mm3"] = r3(miss.volume) if miss is not None and miss.solids() else 0.0


def env_inset(d):
    body = B.rbox(-B.BW / 2 + d, B.BW / 2 - d, -B.BT / 2 + d, B.BT / 2 - d, B.ZB + d, B.AXZ, 2.0 - d, Axis.Z)
    for sx in (-1, 1):
        x0, x1 = sorted((sx * (B.KN + 0.25 - d), sx * (B.BW / 2 + 1.0)))
        body = body - (Pos((x0 + x1) / 2, 0, B.AXZ + (B.RK + 1.0) / 2) * Box(x1 - x0, B.BT + 2, B.RK + 1.0) +
                       B.xcyl(B.RK + 0.5 + d, x0, x1, 0, B.AXZ))
    return body + B.xcyl(B.RK - d, -B.KN + d, B.KN - d, 0, B.AXZ)


skin = env_neck - env_inset(0.4)
pier, zmax_fb = [], -99.0
for v in B.neck_voids():
    xx = v & skin
    if xx is None or not xx.solids():
        continue
    for x in xx.solids():
      if x.volume < 1e-3:
        continue
      bb = x.bounding_box()
      where = ("front" if bb.min.Y < -B.BT / 2 + 0.5 else "back" if bb.max.Y > B.BT / 2 - 0.5 else
               "bottom" if bb.min.Z < B.ZB + 0.5 else "hinge-gap end face (hidden by the lug, 0.5 gap)")
      pier.append(dict(where=where, x=[r3(bb.min.X), r3(bb.max.X)], z=[r3(bb.min.Z), r3(bb.max.Z)]))
      if where in ("front", "back"):
          zmax_fb = max(zmax_fb, bb.max.Z)
vis["neck_surface_openings"] = pier
vis["neck_front_back_openings_max_z_extended"] = r3(zmax_fb)
vis["collar_top_z"] = B.TOP
vis["front_back_openings_hidden_in_torso_when_extended"] = bool(zmax_fb < B.TOP - 1.0)
# collar slot at rest: open area in the disc top plane (z 3.9..4.0)
slotP = (Pos(0, 0, B.TOP - 3) * Box(B.BW + 0.5, B.BT + 0.5, 10))
from build123d import fillet as _fl
slotP = _fl(slotP.edges().filter_by(Axis.Z), 1.75)
pl = Pos(0, 0, B.TOP - 0.05) * Box(80, 40, 0.1)
dn = Location((0, 0, -B.LIFT))
occ_new = (nf + nb + cap + lug).moved(dn)
o_new = (slotP & pl) - (occ_new & pl)
o_nf, o_nb = B.B4.halves()
o_k = B.B4.lugs_closed()
o_old = (slotP & pl) - ((o_nf + o_nb + o_k).moved(dn) & pl)
widths = []
for so in o_new.solids():
    hz = [f for f in so.faces() if abs(f.normal_at().Z) > 0.99]
    top = max(hz, key=lambda f: f.center().Z)
    per = sum(e.length for e in top.edges())
    widths.append(r3(2 * top.area / per) if per > 0 else 0.0)  # mean width of each open strip = 2A/P
vis["collar_slot_open_strips_at_rest"] = dict(count=len(widths), max_mean_width_mm=max(widths) if widths else 0,
                                              note="seams only: 0.25 slot clearance, 0.5 radial apron-knuckle gap, 0.5 lug-knuckle gaps")
vis["collar_slot_open_area_at_rest_mm2"] = dict(round0_c_hn4=r3(o_old.volume / 0.1), now=r3(o_new.volume / 0.1),
                                                 slot_area=r3((slotP & pl).volume / 0.1))
R["8_visibility"] = vis
log("visibility", vis)
save()
# ---------------------------------------------------------------- 8b. seam visibility: orthographic z-buffer 0.05 mm/px
import numpy as np
import vis_zbuf as VZ
INTERNAL = {"servo_MG90S", "paka", "loziska_MR85", "capy", "skrutky", "kabel", "pena_serva"}
nf_c, nb_c = nf, nb                                                  # R4: halves are built CLOSED
names, TT = [], []
for k, lst in list(P.items()) + [("trup", [(torso, "T")])]:
    if k in ("drziak_displeja",):
        continue
    for s, g in lst:
        s = nf_c if k == "krk_predna_polovica" else nb_c if k == "krk_zadna_polovica" else s
        if k not in names:
            names.append(k)
        TT.append((B.tris(s, 0.02, 0.2).astype(float), g, names.index(k)))
VIEWS = [(az, el) for az in (0, 180) for el in (-30, -15, 0, 15, 30, 45, 60)] + \
        [(az, el) for az in (-30, -15, 15, 30, 150, 165, 195, 210) for el in (0, 20)]
zb = {}
for lab, lift, tilt in (("extended_tilt0", 0, 0), ("extended_tilt+40", 0, 40), ("extended_tilt-40", 0, -40),
                        ("rest", -B.LIFT, 0)):
    T = np.concatenate([t if g == "T" else B.tf(t, lift, tilt if g == "H" else 0.0) for t, g, i in TT])
    I = np.concatenate([np.full(len(t), i) for t, g, i in TT])
    box = (-25, 25, -12, 12, B.AXZ - 12 + lift, B.AXZ + 11 + lift)
    worst, per = VZ.seen(T, I, names, INTERNAL, VIEWS, box, 0.05)
    zb[lab] = dict(worst_internal_pixels=worst, worst_area_mm2=r3(worst * 0.0025),
                   views_with_internal={k: v for k, v in per.items() if v})
    log("zbuffer", lab, zb[lab])
R["8_visibility"]["seam_zbuffer"] = dict(
    method="orthographic z-buffer of all parts (0.05 mm/px, window |x|<=25 around the hinge), neck parting gap closed; "
           "internal = servo, horn, MR85, pins, screws, cables", views=[f"az{a}_el{e}" for a, e in VIEWS], result=zb,
    round1_same_method_front_el0={"loziska_MR85": 1120, "paka": 1120})
save()
# ---------------------------------------------------------------- 9. head cable across the hinge
sw = R["2_tilt_sweep"]["min_per_pair_mm_at_deg"]
R["9_cable"] = dict(
    route="neck bottom -> chamber x12.0..14.6 beside the servo end face -> up through the pin's -Z end slot 1.8 x 2.5 -> "
          "static bend R1.5 inside the pin bore D3 -> joint ON the axis x18.4 (only twists) -> rotating bend R1.8 inside the lug chamber "
          "x18.5..21.3 -> lug channel D1.6 x20.5 (tilted to x20.3 in the tenon) -> tenon top -> display",
    bundle_d=1.33, static_bend_R=B.WB[1], rotating_bend_R=r3(B.LCH_X - B.BRG_X1),
    rotating_bend_inner_R=r3(B.LCH_X - B.BRG_X1 - 0.665), rotating_chamber_axial_room=r3(B.LCH_Z0 - B.BRG_X1),
    pin_bore_end_chamfer="0.5 x 45 both ends",
    min_clear_rotating_cable_vs_static={k: v for k, v in sw.items() if k.startswith("cable_head")},
    min_clear_static_cable_vs_rotating={k: v for k, v in sw.items() if k.endswith("cable_neck")},
    overlap_with_any_part_tilt0={k: v for k, v in R["1_overlaps_tilt0"]["nonzero_pairs"].items() if "cable" in k})
save()
# ---------------------------------------------------------------- 10. servo hold (R3: clearance pocket + foam preload)
neck_c = nf_c + nb_c
cl = ivol(servo, neck_c)
rk, free = {}, None
for a in (0.05, 0.1, 0.15, 0.2, 0.25, 0.3, 0.4):
    rk[a] = max(ivol(servo.rotate(B.AX, a), neck_c), ivol(servo.rotate(B.AX, -a), neck_c))
    if free is None and rk[a] > 1e-3:
        free = a
fz = [B.FOAM[5], B.FOAM[6]]
floor_closed = 6.1 + B.GY + B.FOAM[0] - 0.05
spread = {}
for w in (12.0, 12.1, 12.2, 12.3, 12.4):
    c = B.rbox(B.XC, B.XB, -w / 2, w / 2, B.SZ0, B.SZ1, 0.5, Axis.X)
    gap_f = floor_closed - w / 2
    spread[w] = dict(hard_wall_overlap_mm3=ivol(c, neck_c), foam_gap=r3(gap_f),
                     foam_compression_pct=round(100 * (B.FOAM[1] - gap_f) / B.FOAM[1], 1))
fa = (B.FOAM[4] - B.FOAM[3] - 0.4) * (fz[1] - fz[0] - 0.4)
rib0 = ivol(horn, cap)
rib_rot = {a: min(ivol(horn.rotate(B.AX, a), cap), ivol(horn.rotate(B.AX, -a), cap)) for a in (0.05, 0.1)}
R["10_servo_hold"] = dict(
    pocket_y_closed_as_built=r3(6.1 + B.GY - B.CLOSE), pocket_y_design_before_closing=r3(6.1 + B.GY),
    servo_overlap_with_closed_halves_mm3=cl, servo_min_clear_closed=r3(servo.distance_to(neck_c)),
    foam=dict(recess_depth=B.FOAM[0], free_t=B.FOAM[1], recess_floor_y_closed=r3(floor_closed),
              strip_x=[B.FOAM[3] + 0.2, B.FOAM[4] - 0.2], strip_z=[fz[0] + 0.2, fz[1] - 0.2], area_mm2_per_side=r3(fa),
              foam_vs_closed_halves_overlap=ivol(S["pena_serva"], neck_c), foam_vs_servo_overlap=ivol(S["pena_serva"], servo),
              est_preload_N_per_side_at_30pct="~5-15 (PORON 4701-30/-40 CFD 30-100 kPa x %.0f mm2)" % fa),
    case_width_spread=spread,
    servo_overlap_mm3_after_rocking_deg=rk, servo_hard_stop_rock_deg=f"<= {free} (foam preload takes up the play below)",
    horn_rib_preload_overlap_mm3=rib0, horn_rib_overlap_after_rotating_deg=rib_rot,
    horn_free_rock_deg="0 (arms pressed between 4 crush ribs, 0.1 per flank)",
    round2="pocket = case -> 51 mm3 interference with the halves closed (rejected); round1 +-1.15 deg")
log("servo hold", R["10_servo_hold"])
save()
# ---------------------------------------------------------------- 11. torso top rim around the collar recess
from build123d import GeomType
topf = max([f for f in torso.faces() if f.geom_type == GeomType.PLANE and abs(f.center().Z - B.TOP) < 0.01
            and f.normal_at().Z > 0.99], key=lambda f: f.area)
def _rad(w):                                                            # sampled radii (B-spline bboxes are loose)
    rs = [math.hypot(p.X, p.Y) for e in w.edges() for p in [e.position_at(t / 40) for t in range(41)]]
    return min(rs), max(rs)
ro = _rad(topf.outer_wire())[0]
ri = max(_rad(w)[1] for w in topf.inner_wires())
cyl = [f for f in torso.faces() if f.geom_type == GeomType.CYLINDER and f.bounding_box().max.Z > B.TOP - 0.01]
outer = [f for f in torso.faces() if f.geom_type not in (GeomType.PLANE, GeomType.CYLINDER) and f.bounding_box().max.Z > B.TOP - 0.5]
wall = min(c.distance_to(o) for c in cyl for o in outer)
R["11_torso_rim"] = dict(top_face_ring_r=[r3(ri), r3(ro)], rim_width_at_top=r3(ro - ri), min_wall_recess_to_outer_skin=r3(wall),
                         recess_r=28.5, ring_od=28.25, round1_rim=0.1)
log("torso rim", R["11_torso_rim"])
save()
# ---------------------------------------------------------------- 12. round-3 items
r12 = {}
cvd = B.closed_void_dict()
cross = {f"M2x12 ({x}, {z})": z for x, z in B.NSCR}
sp = B.OBL_SP()
cross[f"M2x14 oblique x={B.OBL[0]}"] = r3(B.OBL[1] + sp * math.sin(math.radians(B.OBL[2])))
mouth = cvd[f"screw_cbore_{len(B.NSCR)}"] & (Pos(0, -B.BT / 2 - 0.25, 0) * Box(100, 0.5, 100))
r12["neck_clamp"] = dict(
    screws_z_where_they_cross_the_parting_plane=cross, dowels=B.DOWELS,
    oblique_screw=dict(rise_deg=B.OBL[2], face_mouth_z=[r3(mouth.bounding_box().min.Z), r3(mouth.bounding_box().max.Z)],
                       mouth_hidden_below=B.TOP - 1.0, insert_y=[r3(nscr.solids()[-1].bounding_box().min.Y),
                                                              r3(nscr.solids()[-1].bounding_box().max.Y)]),
    servo_clamp_interference_mm3=ivol(servo, neck_c), pin_seat_interference_mm3=ivol(pin, neck_c),
    foam_force_centroid_z=r3(sum(fz) / 2),
    note="no interference left between the closed halves (only the foam preload pushes them apart, centroid z %.1f, "
         "between the screw lines z -10.5 .. %.1f)" % (sum(fz) / 2, cross[f"M2x14 oblique x={B.OBL[0]}"]))
cov = {}
xs = [round(12.6 + 0.2 * i, 2) for i in range(int((18.6 - 12.6) / 0.2))]
for x0 in xs:
    band = B.xcyl(B.SEAT_R + 0.1, x0, x0 + 0.2, 0, B.AXZ) - B.xcyl(B.SEAT_R, x0 - 1, x0 + 1, 0, B.AXZ)
    cov[x0] = r3(ivol(band, neck_c) / band.volume)
grip = [x for x in xs if cov[x] >= 0.85 and B.PIN_X0 - 0.01 <= x <= B.PIN_X1]
r12["pin_grip"] = dict(pin_od=2 * B.PIN_R, seat_d_closed=2 * B.SEAT_R, coverage_by_x_0p2_slices=cov,
                       grip_len_cov_ge_0p85=r3(0.2 * len(grip)), grip_x=[min(grip), r3(max(grip) + 0.2)],
                       L_over_D=r3(0.2 * len(grip) / (2 * B.PIN_R)), mr85_load_centre_x=17.25,
                       bond="epoxy (or Loctite 603 + SF 7649 activator), radial bond gap 0.05-0.06 (R5 corrected)",
                       pin_vs_bearing="OD 4.99 (-0.005) vs MR85 bore 5.000/-0.008 -> slip fit (min 0.002)",
                       pin_lowered_into_front_half_minus_Y={s_: ivol(pin.moved(Location((0, s_, 0))), nf) for s_ in (3.0, 1.0, 0.0)})
ann = B.zcyl(28.25, -2.1, -2.0) - B.zcyl(26.75, -2.2, -1.9)
rb = ring.bounding_box()
r12["collar_ring"] = dict(ring_z=[r3(rb.min.Z), r3(rb.max.Z)], ring_r=[26.75, 28.25],
                          torso_support_under_ring_fraction=r3(ivol(ann, torso) / ann.volume),
                          ring_to_torso_overlap=ivol(ring, torso), ring_to_disc_gap=r3(ring.distance_to(disc)),
                          disc_z=[r3(disc.bounding_box().min.Z), r3(disc.bounding_box().max.Z)],
                          ring_top_flush_with_disc_top=bool(abs(rb.max.Z - disc.bounding_box().max.Z) < 1e-6))
pg = B.apron_pegs()
r12["apron_pegs"] = dict(peg=dict(x=B.APEG[0], y_abs=B.APEG[1], d=2 * B.APEG[2], h=B.APEG[3]), hole_d=2 * B.APEG[4],
                         peg_vs_shell_overlap=ivol(pg, shell, True), peg_to_shell_min_gap=r3(pg.distance_to(shell)),
                         apron_top_to_head_gap="0.1 (not glued: the head must lift off vertically for service)",
                         note="apron = beam fixed at the +X lug and held near the -X tip by a D2 peg gripped by 3 crush "
                              "ribs in the head floor (X/Y located, Z held by friction) -> no free cantilever")
log("round3", r12)
R["12_round3"] = r12
save()
R["design_numbers"] = dict(
    servo_case_x=[B.XC, B.XB], boss_x=[B.XC - 6, B.XC], spline_x=[B.XC - 9, B.XC - 6],
    horn_hub_x=[B.XC - 9.6, B.XC - 6.3], horn_spline_engagement_mm=2.7, horn_arms_x=[B.XC - 9.6, B.XC - 8.0],
    arm_slot="5.0 wide, bottom x %.2f (R5 +0.5) + 4 crush ribs r%.2f, 0.1 interference over x -18.25..-19.95 (lead-in from the mouth)" % (B.CAP_SLOT_X1, B.RIB[0]), lower_tab_x=[B.TAB_X0, B.TAB_X1],
    lower_tab_slot_x=[round(v, 3) for v in B.TAB_SLOT], pocket_z=dict(floor_gap=B.Z_FLOOR, roof_gap=B.G, datum="floor"),
    boss_bore_floor_x=round(B.BOSS_FLOOR, 3), cap_head_bore_bottom_x=round(B.CAP_HEAD_X1, 3),
    upper_tab="trimmed flush with the case", servo_pocket_y="+-6.15 (closed, as built) + foam 0.5 in 0.3 recess",
    servo_bump=dict(r=B.BUMP[0], h=B.BUMP[1], centre_dist=B.BUMP[2]), bump_relief=dict(r=B.BUMP_REL[0], depth=B.BUMP_REL[1], centre_dist=B.BUMP_REL[2:]),
    oblique_screw=B.OBL, apron_pegs=B.APEG, head_pad_abs_x=B.PAD[:2], knuckle_end_wall_minus_x=round(B.BOSS_FLOOR + B.KN, 3),
    mr85_x=[B.BRG_X0, B.BRG_X1], lug_sleeve=dict(x=B.SLV[:2], r=B.SLV[2:]), counterbore=dict(x0=B.CB_X, r=B.CB_R),
    inner_ring_stop_boss=dict(r=B.BOSS[0], x=[B.CB_X, B.BOSS[1]]), pin_x=[B.PIN_X0, B.PIN_X1],
    pin_glued_len=r3(B.BOSS[1] - B.PIN_X0), pin_od=2 * B.PIN_R, pin_flat=dict(x=[B.PIN_X0, B.PIN_FLAT],
    len=r3(B.PIN_FLAT - B.PIN_X0), seat_flat_len=r3(B.SEAT_FLAT - B.PIN_X0), depth=0.3), pin_end_slot=dict(width=B.PIN_SLOT[0], depth=B.PIN_SLOT[1]),
    lug_chamber_x=[B.BRG_X1, B.LCH_Z0], lug_channel_x=dict(lower=B.LCH_X, tenon=B.LCH_X2, tilt_z=B.LCH_ZJ), lip=B.LIP, cap_groove=B.GROOVE,
    servo_lead_channel=dict(x=B.LEAD_CH[:2], y=B.LEAD_CH[2]), neck_screws=B.NSCR, dowels=B.DOWELS,
    cross_screws=dict(axes_abs_x=B.SCR_X, z=B.ZS, y_from=-B.PAD[2], len=8, head="R5: ISO 7380 M2 dk 3.5 x k 1.1 "
                      "(axes 4.0 apart -> 0.5 between heads; a dk 4.0 pan head would touch)"),
    torque_path="spline -> horn hub -> 2 arms pressed between crush ribs -> cap -> tenon 4x16 in head slot + 2 cross screws",
    visor="transfer tape 0.10 / 0.15 / 0.20 chosen after measuring the bond-line gap (nominal 0.1, montaz 18e); display preload via 4 foam pads 3 x 3 (<= 0.72 N)",
    arm_contact_stress_MPa_at_0p2Nm=r3(0.2 / 0.0048 / 2 / (2.5 * 1.6)),
    rib_contact="see 16_round5.3_horn_ribs (crushed rib flats 0.49 x 1.2-1.6 mm)")
# ---------------------------------------------------------------- 13. STL files: watertight (edges used by != 2 triangles)
import glob
def open_edges(path):
    T = B.read_stl(path).astype(np.float64)
    q = np.round(T.reshape(-1, 3) / 1e-4).astype(np.int64)
    _, idx = np.unique(q, axis=0, return_inverse=True); idx = idx.reshape(-1, 3)
    e = np.sort(np.concatenate([idx[:, [0, 1]], idx[:, [1, 2]], idx[:, [2, 0]]]), axis=1)
    e = e[e[:, 0] != e[:, 1]]
    _, c = np.unique(e, axis=0, return_counts=True)
    return int((c != 2).sum())
oe = {os.path.basename(p): open_edges(p) for p in sorted(glob.glob(f"{B.D}/stl/*.stl"))}
R["13_stl_watertight"] = dict(open_edges_after_weld_1em4=oe,
                              per_part_all_closed=all(v == 0 for k, v in oe.items() if not k.startswith("CELOK")),
                              note="CELOK_* = concatenation of the closed per-part meshes; edges shared by touching "
                                   "parts (e.g. insert in its hole) are counted there, each part block itself is closed")
log("stl", oe)
# ---------------------------------------------------------------- 14. round-4 items (review B_r3)
r14 = {}
neck_c = nf + nb
bump = {}
for d in (5.5, 6.0, 6.5, 7.0, 7.2, 7.5):
    for h in (1.2, 1.3):
        bs = B.servo_bump(d, h)
        bump[f"dist{d}_h{h}"] = dict(overlap_closed_halves=ivol(bs, neck_c), min_clear=r3(bs.distance_to(neck_c)))
cvc = B.closed_void_dict()
r14["1_mg90s_bump"] = dict(
    model=dict(r=B.BUMP[0], h=B.BUMP[1], centre_dist=B.BUMP[2], x=[r3(B.XC - B.BUMP[1]), B.XC], side="-Z (toward the case far end)"),
    relief=dict(r=B.BUMP_REL[0], depth=B.BUMP_REL[1], centre_dist_range=list(B.BUMP_REL[2:])),
    servo_with_bump_vs_closed_halves_mm3=ivol(servo, neck_c), servo_min_clear=r3(servo.distance_to(neck_c)),
    sweep_bump_position_height=bump,
    relief_walls=dict(to_oblique_insert_hole=r3(B.bump_relief().distance_to(B.neck_void_dict()["insert_hole_3"])),
                      to_oblique_clearance_hole=r3(B.bump_relief().distance_to(B.neck_void_dict()["screw_clear_3"])),
                      to_foam_recess=r3(B.bump_relief().distance_to(B.foam_recess())),
                      to_neck_outer_surface=r3(B.bump_relief().distance_to(Pos(0, 0, 0) * (Box(300, 300, 300) - env_neck)))),
    pocket_end_wall_axial_clear_to_case_top=B.G)
log("r14 bump", r14["1_mg90s_bump"])
save()
y0, z0, a = B.SADDLE_LAND
zf = z0 + (B.BT / 2 - y0) * math.tan(math.radians(a))
r14["2_saddle_land"] = dict(land_start=dict(y_abs=y0, z=r3(z0), on_saddle_r=r3(math.hypot(y0, z0 - B.AXZ))), rise_deg=a,
                            face_top_z=r3(zf), face_top_below_axis=r3(B.AXZ - zf), was_face_top_below_axis=3.2,
                            wall_at_face=r3(B.BT / 2 - y0), corner_angle_at_face_deg=90 - a,
                            inner_corner_angle_deg=r3(180 - (math.degrees(math.atan2(y0, B.AXZ - z0)) - a)),
                            note="flat black under the lug barrel (black lug above) - no opening; seen from the front "
                                 "the lug barrel surface fills the 1.8 mm taller strip")
r14["3_lug_channel"] = dict(lower_x=B.LCH_X, tenon_x=B.LCH_X2, tilt_z=[r3(v) for v in B.LCH_ZJ],
                            wall_to_mr85_stop_shoulder=r3(B.lug_channel().distance_to(B.xcyl(4.0, B.SLV[0], B.BRG_X1, 0, B.AXZ))),
                            wall_to_lug_outer_face_x22p5=r3(B.LUG1 - B.LCH_X - 0.8),
                            tenon_walls=[r3(B.LCH_X2 - 0.8 - B.TEN[0]), r3(B.TEN[1] - B.LCH_X2 - 0.8)],
                            rotating_bend_R=r3(B.LCH_X - B.BRG_X1), head_slot_x_unchanged=[B.TEN[0] - 0.1, B.TEN[1] + 0.1])
csq = B.cap_slot_square()
r14["4_cap_slot_ends"] = dict(squared_region="x -17.99..-18.8, |y|<=2.5, |dz|>=3.7, r<=5.95",
                              squared_vs_cap_overlap=ivol(csq, cap), rib_vs_squared_cut=r3(min(
                                  B.rib(sy * B.RIB[1], B.AXZ + sz * B.RIB[2]).distance_to(csq)
                                  for sy in (-1, 1) for sz in (-1, 1))))
log("r14 land/channel/cap", r14["2_saddle_land"], r14["3_lug_channel"], r14["4_cap_slot_ends"])
save()
gk = gask.volume / HC.GASKET
sp_ = HC._w(HC.prism_y(HC.SPIG_SH, HC.Y_SEAM, -27.0, -26.95), B.HZ) & shell
tape = mv(sp_) / 0.05 if sp_ is not None and sp_.solids() else 0.0
fl_ = HC._w(HC.prism_y(HC.VIS_IN, HC.Y_SEAM, -28.0, -27.9), B.HZ) & shell
pre = {}
for t_free in (0.3, 0.4):
    c = (t_free - HC.GASKET) / t_free
    pre[f"foam_{t_free}"] = dict(compression_pct=round(100 * c, 1),
                                 force_N_at_foam_10_20_35kPa=[r3(gk * 0.010), r3(gk * 0.020), r3(gk * 0.035)],
                                 tape_stress_kPa=[r3(gk * 10 / tape), r3(gk * 20 / tape), r3(gk * 35 / tape)])
r14["5_display_preload"] = dict(
    gap_visor_to_lcd=r3(S["sklo"].distance_to(lcd)), pcb_to_seats_gap=r3(pcb.distance_to(dm_["seats"])),
    gasket_frame_area_mm2=r3(gk), tape_area_rabbet_floor_mm2=r3(tape),
    flange_on_rim_contact_mm2=r3(mv(fl_) / 0.1) if fl_ is not None and fl_.solids() else 0.0, cases=pre,
    r5_note="R5: the frame was replaced by 4 corner pads 3 x 3 (gasket() -> area above); see 16_round5.1",
    spec="R4: frame 1.0 wide (outer edge of the LCD border), closed-cell PU foam (PORON type, soft grade), free "
         "0.3 mm (gap 0.2 -> 33 %); 0.4 mm only if the measured gap is 0.25-0.3 (-> 33-38 %); foam must compress by "
         ">= 1/3 under <= 20 kPa (press test: 0.8 kg on a 20 x 20 mm piece) -> preload <= 5.5 N, display weight ~0.5 N",
    load_path="foam -> visor -> 0.1 tape in uniform tension (flange bears on the rim)",
    tape="R5: 93010LE / 93015LE / 93020LE chosen from the measured bond line (16_round5.1); the 30 kPa figure is the "
         "static-shear TEST load, not an allowable - R5 keeps the permanent tension <= 3.6 kPa")
r14["6_dowels_pin_service"] = dict(
    dowel_holes=dict(front_d=2 * B.DOWEL_R[0], back_d=2 * B.DOWEL_R[1]),
    dowels_vs_front_mm3=ivol(dowels, nf), dowels_vs_back_mm3=ivol(dowels, nb),
    pin_vs_front_mm3=ivol(pin, nf), pin_vs_back_mm3=ivol(pin, nb), pin_min_clear_to_back_half=r3(pin.distance_to(nb)),
    pin_spec="R5: Ø5 h6 hardened linear shaft cut to 5.7, drilled Ø3 on a lathe (soft core), lapped to 4.985-4.990; "
             "or precision stainless tube 5.0 x 1.0 (OD +-0.01) lapped the same way; slip test with the actual MR85",
    bond="epoxy on the FRONT-half seat only, back-half seat waxed (release) -> the back half lifts off with both dowels")
fb = nf.bounding_box(); bb_ = nb.bounding_box()
r14["7_model_consistency"] = dict(
    halves_closed=dict(front_y=[r3(fb.min.Y), r3(fb.max.Y)], back_y=[r3(bb_.min.Y), r3(bb_.max.Y)],
                       gap=r3(nf.distance_to(nb)), overlap=ivol(nf, nb)),
    all_neck_fasteners_vs_halves_mm3=dict(front=ivol(nscr, nf), back=ivol(nscr, nb)),
    spline="20T -> horn indexes in 18 deg steps: use the spline position nearest vertical, trim the rest (<= +-9 deg) "
           "as the firmware centre offset")
log("r14 preload/service/model", r14["5_display_preload"], r14["6_dowels_pin_service"], r14["7_model_consistency"])
R["14_round4"] = r14
save()
# ---------------------------------------------------------------- 15. wall minima by RAY CASTING on the printed-part STLs
import rc
RCP = dict(krk_predna_polovica=(20.0, None), krk_zadna_polovica=(20.0, None), usko_kryt=(20.0, None),
           usko_lozisko=(20.0, None), golier_kotuc=(0.0, None), golier_prstenec=(0.0, None),
           hlava_skrupina=(20.0, (-32, 32, -14, 14, B.HZ - 1.5 - 20, B.HZ + 12 - 20)))
rcr = {}
for nm, (zo, reg) in RCP.items():
    Tm = B.read_stl(f"{B.D}/stl/{nm}.stl")
    Pp, Nn, th = rc.thickness(Tm, 15000, region=reg)
    rcr[nm] = rc.summary(Pp, Nn, th, zoff=zo)
    rcr[nm]["n_lt_1p19"] = int((th < 1.19).sum())
    log("raycast", nm, {k: v for k, v in rcr[nm].items() if k != "thin_spots"})
R["15_raycast_walls"] = dict(
    method="per-part STL (rest pose, reported in the EXTENDED pose: z+20 for neck/head parts), 15000 area-weighted "
           "samples, ray along -normal, wall = first hit with opposite normal (dot < -0.7), rays > 3 mm ignored; "
           "head shell sampled only in the hinge/pad zone |x|<=32, |y|<=14, z HZ-1.5..HZ+12",
    parts=rcr,
    known_below_1p2={"krk_*_polovica x 15.8..16.0, r 2.55..3.1": "MR85 inner-ring stop step: a 0.2 mm high ring on the "
                     "solid counterbore floor (its radial width 0.5 is measured, not a wall; it only carries the inner-ring "
                     "axial contact, 9.8 mm2)",
                     "values 1.199x": "design walls of exactly 1.2 (tessellation)"})
save()
# ---------------------------------------------------------------- 16. round-5 items (findings_B_round5)
import checks16
R["16_round5"] = checks16.run(B, HC, rc, S, P, log)
save()
R["time_s"] = round(time.time() - t0, 1)
save()
log("done")
