"""Variant B round 5 - section 16 of checks.json (review findings_B_round5).  Called from checks.py: run(ctx)."""
import math
from build123d import Pos, Box, Location, Axis


def r3(x):
    return round(float(x), 3)


def ivol(a, b):
    r = a & b
    return 0.0 if r is None or not r.solids() else round(sum(s.volume for s in r.solids()), 4)


def servo_var(B, tab_lo=15.5, dx=0.0, w=12.2, h=22.5, boss=6.0, boot=None, bump=7.2):
    """MG90S envelope variant: case top at XC+dx, height h, width w; boss height; lower tab 2.5 thick starting tab_lo
    above the case bottom; boot = (from, to above the bottom, half-y, protrusion below the far end); 2nd bump"""
    xt = B.XC + dx
    xb = xt + h
    s = B.rbox(xt, xb, -w / 2, w / 2, B.SZ0, B.SZ1, 0.5, Axis.X)
    s = s + B.xcyl(5.9, xt - boss, xt + 0.01, 0, B.AXZ) + B.xcyl(2.4, xt - boss - 3.0, xt - boss + 0.01, 0, B.AXZ)
    s = s + B.rbox(xb - tab_lo - 2.5, xb - tab_lo, -w / 2, w / 2, B.SZ0 - 4.85, B.SZ0 + 0.5)
    b0, b1, by, bo = boot or (0.65, 2.35, 2.0, 2.0)
    s = s + B.rbox(xb - b1, xb - b0, -by, by, B.SZ0 - bo, B.SZ0 + 0.3)
    if bump:
        s = s + B.xcyl(B.BUMP[0], xt - B.BUMP[1], xt + 0.01, 0, B.AXZ - bump)
    return s


VARIANTS = {
    "nominal (tab 15.5-18.0, model boot)": {},
    "repo tab 15.9-18.4": dict(tab_lo=15.9),
    "tab 15.3-17.8 (range low end)": dict(tab_lo=15.3),
    "tab 16.2-18.7 (range high end)": dict(tab_lo=16.2),
    "repo boot 0.8-4.0 +-1.6 x1.6": dict(boot=(0.8, 4.0, 1.6, 1.6)),
    "max boot 0.4-4.25 +-2.15 x2.0": dict(boot=(0.4, 4.25, 2.15, 2.0)),
    "case height 22.7 (repo MS_H)": dict(h=22.7),
    "worst stack: h22.7 + boss 6.2 + repo tab + repo boot": dict(h=22.7, boss=6.2, tab_lo=15.9, boot=(0.8, 4.0, 1.6, 1.6)),
    "width 12.3 + repo tab": dict(w=12.3, tab_lo=15.9),
    "width 12.0 + tab 15.3 + bump 5.5": dict(w=12.0, tab_lo=15.3, bump=5.5),
}


def mg90s_range(B, nf, nb, log):
    box = Pos(-1.5, 0, 8.0) * Box(31.0, 20.6, 32.0)               # pocket region of both halves (x -17..14, z -8..24)
    neck = (nf + nb) & box
    out = {}
    grid = [round(-0.3 + 0.05 * i, 2) for i in range(13)]
    for nm, kw in VARIANTS.items():
        ok = [dx for dx in grid if ivol(servo_var(B, dx=dx, **kw), neck) < 1e-4]
        row = dict(free_axial_float_dx=[min(ok), max(ok)] if ok else None, fits=bool(ok),
                   overlap_at_dx0_mm3=ivol(servo_var(B, **kw), neck))
        if ok:
            d0 = 0.0 if 0.0 in ok else ok[len(ok) // 2]
            row["min_clear_at_dx%.2f" % d0] = r3(servo_var(B, dx=d0, **kw).distance_to(neck))
        out[nm] = row
        log("r16 servo range", nm, row)
    ins = {}
    for nm in ("nominal (tab 15.5-18.0, model boot)", "repo tab 15.9-18.4", "tab 16.2-18.7 (range high end)"):
        sv = servo_var(B, **VARIANTS[nm])
        ins[nm] = {str(s): ivol(sv.moved(Location((0, s, 0))), nf & box) for s in (0.3, 1.0, 3.0, 6.5)}
    v = B.neck_void_dict()
    tab_slot = B.rbox(B.TAB_SLOT[0], B.TAB_SLOT[1], -6.2, 6.2, B.SZ0 - 5.0, B.SZ0 + 0.6)
    walls = dict(lead_channel_to_insert_hole_x5=r3(v["lead_channel"].distance_to(v["insert_hole_1"])),
                 lead_channel_to_screw_clear_x5=r3(v["lead_channel"].distance_to(v["screw_clear_1"])),
                 lead_channel_to_head_chamber="joined (same void, x 12.0-12.25) as in R4",
                 tab_slot_to_dowel_hole_x_minus5=r3(tab_slot.distance_to(v["dowel_hole_0"])),
                 tab_slot_to_neck_side_face=r3(B.BT / 2 - 6.2), tab_slot_to_pocket_floor_end="open into the pocket")
    return dict(
        pocket=dict(tab_slot_x=[r3(B.TAB_SLOT[0]), r3(B.TAB_SLOT[1])],
                    tab_slot_accepts_above_case_bottom=[r3(B.XB - B.TAB_SLOT[1]), r3(B.XB - B.TAB_SLOT[0])],
                    lead_channel_x=[r3(B.LEAD_CH[0]), r3(B.LEAD_CH[1])], lead_channel_half_y=B.LEAD_CH[2],
                    boot_accepted_above_case_bottom=[r3(B.XB - B.LEAD_CH[1]), r3(B.XB - B.LEAD_CH[0])],
                    case_end_walls_x=[r3(B.XC - B.G), r3(B.XB + B.G)], boss_bore_floor_x=r3(B.BOSS_FLOOR)),
        variants_vs_closed_halves=out, all_variants_fit=all(r["fits"] for r in out.values()),
        insertion_into_front_half_along_minus_y_overlap_mm3=ins, walls=walls,
        x_location="axial (X) position is set ONLY by the case end walls (0.15) and the horn in the cap; the tab "
                   "slot leaves >= 0.3 on both sides of the nominal tab -> no over-constraint")


def horn_ribs(B, cap, horn, hscr, nf, nb):
    """minor 2 + 10: rib contact over the arm range, horn axial range (arm top 9.3..10.0 below the case top)"""
    neck = nf + nb
    rr, ry, rz = B.RIB
    chord = 2 * math.sqrt(rr ** 2 - (rr - 0.1) ** 2)
    out = {}
    for dx in (-0.4, 0.0, 0.3):                       # -X = horn further out (taller boss / hub), +X = hub on the boss
        h, sc = horn.moved(Location((dx, 0, 0))), hscr.moved(Location((dx, 0, 0)))
        ov = cap & h
        lens = sorted(r3(s.bounding_box().max.X - s.bounding_box().min.X) for s in ov.solids()) if ov else []
        tilt = {}
        for th in (-40, -20, 0, 20, 40):
            ht = h.rotate(B.AX, th)
            tilt[str(th)] = dict(overlap_neck=ivol(ht, neck), min_clear=r3(ht.distance_to(neck)))
        out["arm_top_below_case_top_%.1f" % (9.6 - dx)] = dict(
            horn_dx=dx, cap_overlap_mm3_ribs_only=ivol(cap, h), rib_contact_lengths=lens,
            rib_contact_area_mm2_each=r3(chord * (min(lens) if lens else 0)),
            arm_top_to_slot_bottom=r3((B.XC - 9.6 + dx) - B.CAP_SLOT_X1), screw_head_to_bore_bottom=r3(
                (B.XC - 10.8 + dx) - B.CAP_HEAD_X1), screw_vs_cap_mm3=ivol(sc, cap),
            arm_inner_face_to_knuckle_end=r3(-B.KN - (B.XC - 8.0 + dx)), vs_neck_over_tilt=tilt)
    a0 = chord * 1.2                                   # shortest contact over the range (arm top 9.3 below the case top)
    st = {f"{t} N.m": dict(force_per_rib_N=r3(t / (2 * rz * 1e-3)), stress_MPa=r3(t / (2 * rz * 1e-3) / a0))
          for t in (0.021, 0.072, 0.19)}
    return dict(ribs=dict(r=rr, centre_abs_y=ry, centre_abs_dz=rz, interference=r3(rr - (ry - 2.5)),
                          x_leadin=[B.RIB_X[0], B.RIB_X[1]], x_full=[B.RIB_X[1], B.RIB_X[2]], crushed_chord=r3(chord),
                          r4_was="r0.25 x 0.66 long (0.26 mm2)"),
                rib_stress_at_shortest_contact_1p2=st,
                torque_cases="0.021 gravity at 0 deg / 0.072 gravity at +40 deg / 0.19 = +40 deg + fast move "
                             "(reviewer: 193 g head, I ~6e-4 kg m2, 200 rad/s2)",
                horn_positions=out, slot_bottom_x=r3(B.CAP_SLOT_X1), head_bore_bottom_x=r3(B.CAP_HEAD_X1),
                cap_outer_wall_at_head_bore=r3(B.LUG1 + B.CAP_HEAD_X1),
                boss=dict(boss_top_x=r3(B.XC - 6.0), bore_floor_x=r3(B.BOSS_FLOOR), gap_nominal=r3(B.XC - 6.0 - B.BOSS_FLOOR),
                          gap_case_at_minus_x_stop=r3(B.XC - B.G - 6.0 - B.BOSS_FLOOR),
                          boss_plus_0p2_case_at_minus_x_stop=r3(B.XC - B.G - 6.2 - B.BOSS_FLOOR),
                          end_wall=r3(B.BOSS_FLOOR + B.KN),
                          note="boss +0.2 AND case pulled fully to -X: the boss top touches the end wall 0.05 before "
                               "the case top reaches its stop (a contact, the servo floats axially) - no interference"))


def servo_z(B, servo, nf, nb):
    neck = nf + nb
    mv = {str(dz): ivol(servo.moved(Location((0, 0, dz))), neck) for dz in (-0.02, 0.0, 0.14, 0.16)}
    A, t = 145.16, 0.35
    rows = {}
    for cfd in (14.0, 34.0):                                          # PORON soft grade, kPa at 25 %
        E = cfd / 0.25
        Gs = E / 3
        rows[f"CFD25_{cfd:.0f}kPa"] = dict(preload_N_per_side=r3(cfd * A * 1e-3), shear_stiffness_N_per_mm=r3(2 * Gs * A / t * 1e-3),
                                         friction_N_mu0p5=r3(2 * 0.5 * cfd * A * 1e-3))
    return dict(floor_gap_modelled=B.Z_FLOOR, roof_gap=B.G, tab_end_gap=B.G, overlap_after_dz_mm3=mv,
                hold=rows, gravity_N="~0.9 (about half of the 1.9 N head weight via the lower arm tip)",
                note="the case far end rests on the pocket floor (Z datum -> spline on the hinge axis); upward it is held "
                     "elastically by the two Y foam strips in shear (>= 16 N/mm) and by their friction (>= 2 N) plus "
                     "gravity; the 0.15 at the roof only absorbs case-length tolerance")


def fits_screws(B, nscr, nf, nb, dowels, lug, bo):
    sc = list(nscr.solids())[:4]                                     # 3 straight + 1 oblique (inserts follow)
    face = -B.BT / 2 + B.CLOSE
    inset = {f"x{s.center().X:.1f}": r3(s.bounding_box().min.Y - face) for s in sc}
    sp = B.OBL_SP()
    pil = B.ocyl(1.2, sp + 5.2, sp + 6.4)
    outside = Pos(0, 0, 0) * (Box(300, 300, 300) - B.neck_env())
    return dict(
        neck_screws=dict(head="ISO 7045 (PH0) or ISO 14583 (T6) pan head, dk 4.0 / k 1.6 max - NOT DIN 912",
                         modelled_head=[4.0, 1.6], head_inset_below_closed_front_face=inset,
                         oblique_counterbore_bearing_face_s=B.OBL_HEAD[1], oblique_pilot_end_s=r3(sp + 6.4),
                         oblique_screw_tip_s=r3(B.OBL_HEAD[1] + 14.0), oblique_pilot_wall_to_outside=r3(pil.distance_to(outside)),
                         screws_vs_front_mm3=ivol(nscr, nf), screws_vs_back_mm3=ivol(nscr, nb)),
        dowels=dict(front_hole_d=2 * B.DOWEL_R[0], back_hole_d=2 * B.DOWEL_R[1], vs_front_mm3=ivol(dowels, nf),
                    vs_back_mm3=ivol(dowels, nb),
                    fit="back half: ream D2.0 (resin prints undersize), dowel bonded with epoxy; front: D2.02 slip"),
        lug_sleeve=dict(bore_d=r3(2 * B.SLV[2]), mr85_od=8.0, radial_epoxy_gap=r3(B.SLV[2] - 4.0),
                        wall=r3(B.SLV[3] - B.SLV[2]), radial_clear_to_counterbore=r3(B.CB_R - B.SLV[3]),
                        outer_ring_shoulder_x=B.BRG_X1, bearing_vs_lug_mm3=ivol(bo, lug),
                        fit="dry-fit by hand first; ream / sand the bore if the ring does not slide in"),
        pin_seat=dict(seat_r=B.SEAT_R, pin_r=[2.494, 2.498], radial_glue_gap=[r3(B.SEAT_R - 2.498), r3(B.SEAT_R - 2.494)],
                      text="0.05-0.06"))


def visor_pads(B, HC, gask, vis, lcd, shell, tape_area):
    A = gask.volume / HC.GASKET
    cov = {}
    for nm, dy, other in (("visor_back_face", -0.05, vis), ("lcd_front", 0.05, lcd)):
        sl = gask.moved(Location((0, dy, 0)))
        cov[nm] = r3(ivol(sl, other) / (A * 0.05))
    a, e = B.PADS
    act = (73.44 / 2, 48.96 / 2)                                      # 3.5" 320 x 480 active area (half sizes)
    load = {f"{k}kPa": dict(force_N=r3(A * k * 1e-3), tape_kPa=r3(A * k / tape_area)) for k in (10, 20, 40)}
    load["pads_2x2_at_40kPa"] = dict(force_N=r3(16 * 40e-3), tape_kPa=r3(16 * 40 / tape_area))
    return dict(
        pads=dict(n=4, size=a, inset_from_lcd_edge=e, area_mm2=r3(A), coverage=cov, pads_vs_shell_mm3=ivol(gask, shell),
                  inner_edge_abs_x=r3(HC.DW / 2 - e - a), active_area_half_x=act[0], outside_active_area=bool(
                      HC.DW / 2 - e - a > act[0]), r4_frame_area_mm2=276),
        tape_area_mm2=r3(tape_area), preload=load, dead_load_guideline_kPa=1.7, static_shear_test_kPa=30,
        rule="foam press test: 20 x 20 piece compressed by 1/3 under <= 0.8 kg (<= 20 kPa) -> pads 3 x 3; 0.8-1.6 kg "
             "(<= 40 kPa) -> pads 2 x 2; harder foam -> do not use",
        bond_line=dict(nominal_gap=r3((HC.Y_SEAM + HC.RAB_D) - HC.Y_VB), tolerance="+-0.1 worst case (rabbet, spigot, warp)",
                       rule={"t 0.07-0.10": "3M 93010LE (0.10)", "t 0.12-0.15": "3M 93015LE (0.15)",
                             "t 0.17-0.20": "3M 93020LE (0.20)",
                             "t < 0.07 or between the bands": "sand the spigot back face (glass plate P600 -> P1500, "
                                                               "re-polish) into the next band above",
                             "t > 0.20": "reprint the visor"},
                       tape_compression="0-0.03 -> wet-out under the 50 N press, the flange still seats",
                       measure="Plastigauge red (0.051-0.152) / blue (0.102-0.229) at 4 points, or depth gauge R - L (0.01)"))


def foam_shim(B):
    rows = {}
    floor = 6.1 + B.GY + B.FOAM[0] - B.CLOSE
    for w in (12.0, 12.05, 12.1, 12.14, 12.15, 12.2, 12.3):
        shim = 0.1 if w < 12.15 else 0.0
        g = floor - w / 2 - shim
        rows[str(w)] = dict(kapton_shim=shim, foam_gap=r3(g), compression_pct=round(100 * (B.FOAM[1] - g) / B.FOAM[1], 1))
    return dict(rule="case width < 12.15 -> one layer of 0.1 Kapton under each foam strip", table=rows)


def shell_rim_raycast(B, rc, log):
    """minor 11: ray-cast walls of the printed shell in the whole visor-rim band (y -28.6..-26.0, all x/z), rest pose"""
    Tm = B.read_stl(f"{B.D}/stl/hlava_skrupina.stl")
    reg = (-60, 60, -28.6, -26.0, -100, 200)
    Pp, Nn, th = rc.thickness(Tm, 20000, region=reg)
    out = rc.summary(Pp, Nn, th, zoff=20.0)
    out["n_lt_0p5"] = int((th < 0.5).sum())
    near = (abs(Pp[:, 1] + 26.95) < 0.15) & (Pp[:, 2] + 20.0 > B.HZ + 2.0) & (Pp[:, 2] + 20.0 < B.HZ + 3.5) & (
        abs(Pp[:, 0]) < 15)
    out["samples_in_former_ridge_zone"] = int(near.sum())
    out["min_in_former_ridge_zone"] = r3(th[near].min()) if near.any() and (th[near] < 1e9).any() else "all > 3 (thick)"
    log("r16 shell rim raycast", {k: v for k, v in out.items() if k != "thin_spots"})
    return out


def left_rim_corner(B, shell):
    """B-rep check of the ray-cast hits at x ~ -51 (cavity side wall meets the rabbet floor y -27.0): corner angle"""
    from build123d import Pos, Box
    rows = {}
    for zl in (33.0, 42.0, 45.0):
        sec = shell & (Pos(-51.5, -26.0, B.HZ + zl + 0.0013) * Box(5.1, 4.1, 0.0021))
        if sec is None:
            continue
        ed = [(e.start_point(), e.end_point()) for e in sec.edges() if (e.start_point() - e.end_point()).length > 1e-3
              and e.start_point().Z > B.HZ + zl + 0.002 and abs(e.start_point().Z - e.end_point().Z) < 1e-3]
        wall = [(a, b) for a, b in ed if abs(a.Y + 23.95) < 0.01 and abs(b.Y + 27.0) < 0.01]
        floor = [(a, b) for a, b in ed if abs(a.Y + 27.0) < 1e-3 and abs(b.Y + 27.0) < 1e-3]
        if wall and floor:
            w, f = wall[0], floor[0]
            v1 = (w[0] - w[1]).normalized(); v2 = (f[1] - f[0]).normalized()
            rows[f"local_z{zl:.0f}"] = dict(corner_deg=r3(math.degrees(math.acos(v1.dot(v2)))),
                                          rabbet_floor_ring_width=r3(abs(f[1].X - f[0].X)), cavity_wall_x_at_y_m27=r3(w[1].X))
    return dict(sections=rows, verdict="mesh artifact: a long sliver facet of the cavity loft spans the 0.1 step from the "
                "rabbet floor edge (y -27.0) to the side display-rib corner (y -26.9); the B-rep material corner is ~82 deg (sections above) with "
                "the rabbet ring + 2 mm of wall behind it - not a thin wall (same hits in the round-4 STL; common head)")


def run(B, HC, rc, S, P, log):
    nf, nb, cap, lug = S["krk_predna_polovica"], S["krk_zadna_polovica"], S["usko_kryt"], S["usko_lozisko"]
    servo, horn = S["servo_MG90S"], S["paka"]
    bo, bi = [s for s, g in P["loziska_MR85"]]
    pin, dowels = [s for s, g in P["capy"]]
    nscr, hscr, xscr, dins = [s for s, g in P["skrutky"]]
    lcd, pcb, kom, gask = [s for s, g in P["displej"]]
    shell = S["hlava_skrupina"]
    sp_ = HC._w(HC.prism_y(HC.SPIG_SH, HC.Y_SEAM, -27.0, -26.95), B.HZ) & shell
    tape = HC.mesh_volume(sp_) / 0.05
    r = {}
    r["1_visor_tape_major"] = visor_pads(B, HC, gask, S["sklo"], lcd, shell, tape)
    log("r16 visor", r["1_visor_tape_major"]["pads"], r["1_visor_tape_major"]["preload"])
    r["2_mg90s_range_major"] = mg90s_range(B, nf, nb, log)
    r["3_horn_ribs"] = horn_ribs(B, cap, horn, hscr, nf, nb)
    log("r16 horn/ribs", r["3_horn_ribs"]["horn_positions"])
    r["4_servo_z"] = servo_z(B, servo, nf, nb)
    log("r16 servo z", r["4_servo_z"])
    r["5_fits_screws"] = fits_screws(B, nscr, nf, nb, dowels, lug, bo)
    log("r16 fits", r["5_fits_screws"])
    r["6_foam_shim"] = foam_shim(B)
    r["7_shell_rim_raycast"] = shell_rim_raycast(B, rc, log)
    r["7_shell_rim_raycast"]["left_side_hits_x_m51"] = left_rim_corner(B, shell)
    return r
