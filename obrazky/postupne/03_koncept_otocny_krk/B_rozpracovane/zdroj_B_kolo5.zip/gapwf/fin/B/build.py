"""NOVA mini - variant B (tilt MG90S in the neck top, shaft on the hinge axis), ROUND 5.
Imports the original builder c_hn4 (constants/helpers) + the shared head module; overrides the neck, servo, horn, lugs.
World mm, Z up, front -Y, robot right -X.  Extended pose: head bottom HZ=27, hinge axis AXZ=16.5.  Rest = -20 mm.
Round 1 (kept): real MG90S, horn arms keyed in the -X lug CAP, tenons + 4 x M2x8 cross screws, aprons, glue-in inserts.
Round 2:
* +X hinge moved 1.0 in -X: MR85 x16.0..18.5 in a black lug SLEEVE (r4.0..5.5, x16.5..18) running in a knuckle
  counterbore r5.9 from x15.8; hollow pin 14.3..18.5 (Loctite 603), both bore ends chamfered 0.5x45;
  rotating lug chamber 18.5..21.3 -> 90 deg wire bend R1.8 inside the lug; lug channel x=20.3 (tenon walls 1.2/1.2).
* static wire bend R1.5 in a chamber x12.0..14.6 beside the servo end face (1.2 to the counterbore); the wires enter
  the pin through its -X end + an open end slot 1.8 x 1.2 (no thin brass bridge); pin flat 1.6 long (seat flat 1.5).
* zero backlash: servo pocket Y = case (+-6.1) -> closing the 0.1 parting gap clamps the case; cap arm slot 5.0
  with 4 crush ribs 0.1 (arms filed parallel 5.0).
* seams: sleeve hides the MR85; a static lip ring (r6.8..8.0) on the -X knuckle end runs in a cap groove -> the
  horn is hidden.  Visor on removable 0.1 tape (serviceable).  Torso top_r 29.8 (rim 1.3 around the r28.5 recess).
Round 3:
* servo pocket +-6.20 (0.05/side clearance with the halves closed) + PORON foam 0.5 in a 0.3 recess on each large face
  (compressed to 0.35 for a 12.2 case; preload for 12.0..12.3).  Neck screws: 3x M2x12 straight (-15,-10.5), (5,-10.5),
  (17.8,-2.5) + 1x M2x14 OBLIQUE at x -14.2 (rises 28 deg: head hidden in the torso, crosses the parting plane at
  z 5.6 where the old dowel was); inserts bottom on a step + pilot; dowels (-5,-13) [moved down] and (19,3).
* hollow pin OD 4.99 (h6, slip fit in the MR85), 12.8..18.5, glued with epoxy over 3.2 mm; seat r2.55 about the axis
  when closed (each half's seat centred 0.05 outward); wires enter from below through a 1.8 x 2.5 end slot.
* +X lug aprons: one peg D2 x 2.5 per apron tip (x -15) in a D2.2 head-pad hole with 3 crush ribs (friction, no glue,
  the head still lifts off vertically) -> each apron is supported at both ends.
* collar ring 6 tall (z -2..4) sits on the recess floor; collar exported from collar(); cable STL meshed watertight.
Round 4:
* MG90S 2nd top-cover bump D5.6 x 1.2 at 7.2 from the spline axis (toward the case far end, -Z) modelled; pocket relief
  = stadium r3.0 x 1.4 deep covering bump centre distance 5.5..7.5 (BUMP / BUMP_REL).
* neck saddle under each lug: the 18 deg feather edge where R10.5 meets y=+-10 is replaced by a 35 deg land
  (from |y| 8.645 / z AXZ-5.96 up to the face at z AXZ-5.01) -> wall >= 1.2 also across the R2 corners (SADDLE_LAND).
* +X lug wire channel: x 20.5 from the chamber up to AXZ+5 (shoulder wall 1.2), tilted to x 20.3 by the tenon base
  (tenon walls 1.2/1.2 unchanged, head slot unchanged, no visible change); rotating bend R2.0.
* usko_kryt: the slot ends inside the lip groove depth are squared off to r5.95 (no slivers against the groove wall).
* neck halves are built/exported CLOSED (front +0.05 Y, back -0.05 Y); inserts seated at 0.55..3.55 (-0.05),
  neck screws +0.05 (heads on the counterbore floor).  Dowels: D1.95 press in the BACK half, D2.02 slip in the FRONT.
* display foam frame 1.0 wide (gasket(), ~270 mm2), free 0.3 (33 %) / 0.4 -> preload <= 5.5 N on the 0.1 visor tape.
* head shell: cross-screw clearance holes through the slot-corner zone, apron-peg hole mouth chamfer from 0.4 below the
  floor; oblique neck holes clipped at the parting plane (all: no sub-0.5 resin slivers, ray-cast checked).
Round 5:
* display preload: gasket() = 4 corner PADS 3 x 3 (36 mm2) instead of the 276 mm2 frame -> <= 0.72 N on the visor tape.
* MG90S range: lower-tab slot x XB-18.8..XB-15.2 (tab 15.3..18.7 above the case bottom), lead channel XB-4.3..XB-0.35
  (boot up to 4.3); pocket FLOOR = Z datum (0.01 modelled, gravity side), roof 0.15; boss bore floor XC-6.3.
* usko_kryt: arm slot 0.5 deeper (XC-10.25), screw-head bore to XC-11.4 (wall 1.2); crush ribs r0.35 (0.1 interference)
  over x -18.25..-19.95 with a lead-in cone from the slot mouth (contact area 2.4x).
* resin fits: back-half dowel holes D2.0 (dowels epoxied), lug sleeve bore D8.08 (0.04 epoxy gap), sleeve OD 11.08.
* oblique M2x14 counterbore 0.4 deeper (ISO 7045 pan head k1.6 sits >= 0.3 inside the face), pilot to sp+6.4.
* screws modelled at max head size: neck ISO 7045 dk 4.0 x k 1.6; head cross screws ISO 7380 M2x8 dk 3.5 x k 1.1
  (axes 4.0 apart: 0.5 between the heads).
* head shell: clean-up cut of the 0.1 step ridge at the rabbet-floor / inner-floor edge (|x| <= 12, local z 2.55..3).
"""
import sys, math, json, importlib.util
sys.path.insert(0, "/home/user/Robot"); sys.path.insert(0, "/tmp/claude-0/pan16"); sys.path.insert(0, "/tmp/claude-0/gapwf/fin/common")
from build123d import (Pos, Rot, Box, Cylinder, Sphere, Axis, Location, Solid, Compound, Face, Polyline, extrude, fillet,
                       export_stl)
import head_common as HC


def _load(name, path):
    s = importlib.util.spec_from_file_location(name, path); m = importlib.util.module_from_spec(s); s.loader.exec_module(m)
    return m


_prev = sys.modules.get("build")                                       # c_hn4 does `import build` (= c_hn3)
sys.modules["build"] = _load("c_hn3_build", "/tmp/claude-0/gapwf/c_hn3/build.py")
B4 = _load("c_hn4_build", "/tmp/claude-0/gapwf/c_hn4/build.py")      # original builder (imports c_hn3)
if _prev is not None:
    sys.modules["build"] = _prev
else:
    del sys.modules["build"]
HC.setup()                                                             # c_hn3 import re-patched softhead - re-assert
D = "/tmp/claude-0/gapwf/fin/B"
HZ, BW, BT, RK, AXZ, KN, LUG0, LUG1, ZB = B4.HZ, B4.BW, B4.BT, B4.RK, B4.AXZ, B4.KN, B4.LUG0, B4.LUG1, B4.ZB
xcyl, zcyl, ycyl = HC.xcyl, B4.zcyl, HC.ycyl
LIFT = 20.0
# ---- servo (shaft along -X on the hinge axis); x positions from the horn stack: arms -17.9..-19.5 -> case top xC
XC = -9.9                         # case top face (gear side); case bottom = XC + 22.5 = 12.6
XB = XC + 22.5
G = 0.15                          # servo pocket clearance in X / Z (boss radial)
GY = 0.10                         # R3: pocket +-6.20 modelled -> +-6.15 closed = 0.05/side clearance (no clamp)
FOAM = (0.30, 0.50, 0.35, -8.4, 11.1, 0.6, 8.6)   # R3: recess depth, foam t free / compressed, recess x0,x1,z0,z1
SZ0, SZ1 = AXZ - 16.9, AXZ + 5.9  # case z range (shaft 5.9 from the top end)
TAB_X0, TAB_X1 = XB - 18.0, XB - 15.5
TAB_SLOT = (XB - 18.8, XB - 15.2)   # R5: slot accepts tab 15.3..18.7 above the case bottom (+-0.1 float)
Z_FLOOR = 0.01                    # R5: pocket floor = Z datum (case far end rests on it; 0.01 = numerical gap)
BOSS_FLOOR = XC - 6.3             # R5: boss bore floor (0.3 above the boss, end wall 1.3)
LEAD_X = XB - 1.5                 # lead exits the bottom end face next to the bottom cover (ASSUMED side)
# ---- +X hinge side (round 2: everything 1.0 further -X)
BRG_X0, BRG_X1 = 16.0, 18.5       # MR85 5x8x2.5
SLV = (16.5, 18.0, 4.04, 5.54)    # lug sleeve x0, x1 (lug inner face), bore r (R5: D8.08 = 0.04 epoxy gap), outer r
CB_X, CB_R = 15.8, 5.9            # knuckle counterbore floor / radius (sleeve clearance 0.4 radial, 0.7 axial)
BOSS = (3.1, 16.0)                # inner-ring stop boss r / end x (stands 0.2 on the counterbore floor)
PIN_X0, PIN_X1 = 12.8, 18.5       # R3: hollow pin 4.99/3 (glued 12.8..16.0 = 3.2 grip + bearing seat 16.0..18.5)
PIN_R, SEAT_R, SEAT_X0 = 2.495, 2.55, 12.7   # R3: pin OD 4.99 h6; seat r2.55 about the axis WHEN CLOSED (epoxy gap)
PIN_FLAT, SEAT_FLAT = 14.4, 14.3  # D-flat end x on the pin / in the seat (pin flat 1.6 > seat flat 1.5 -> -X stop)
PIN_SLOT = (1.8, 2.5)             # R3: open end slot (-Z side) width y, length x: the wires enter from below
CHAM = (12.0, 14.6, 1.0, AXZ - 1.9)   # head-wire chamber x0, x1, half-width y, top z (R3: stops under the pin slot)
WB = (13.7, 1.5)                  # static wire bend: vertical leg x, bend radius (centre 15.2, AXZ-1.5)
LCH_X = 20.5                      # R4: wire channel in the +X lug (r0.8) -> rotating bend R = 20.5-18.5 = 2.0
LCH_X2 = 20.3                     # R4: channel x inside the tenon (walls 1.2/1.2); tilted 20.5 -> 20.3 between LCH_ZJ
LCH_ZJ = (AXZ + 5.0, HZ - 0.5)    # R4: z range of the tilted transition (ends at the tenon base)
LCH_Z0 = 21.3                     # lug chamber end x (outer wall 1.2)
LEAD_CH = (XB - 4.3, XB - 0.35, 2.25)    # servo lead channel x0, x1, half-width y (R5: boot up to 4.3 above the bottom)
LIP = (6.8, 8.0, -18.4)           # -X knuckle lip ring r0, r1, tip x (from the knuckle end -17.5)
GROOVE = (5.9, 8.4, -18.8)        # cap groove r0, r1, bottom x
RIB = (0.35, 2.75, 3.5)           # R5: crush rib r, centre |y|, centre |dz|  (protrudes 0.1 into the 5.0 slot)
RIB_X = (-17.99, -18.25, -19.95)  # R5: rib lead-in start (flush) / full radius from / to (covers the arm range)
CAP_SLOT_X1 = XC - 10.25          # R5: arm slot bottom (0.65 behind the nominal arm top)
CAP_HEAD_X1 = XC - 11.4           # R5: horn-screw head bore bottom (1.2 to the cap outer face x -22.5)
# ---- lugs / tenons / head pads
DZW = 5.0                         # web is full +-10 above AXZ+DZW (chamfer from the R10 barrel)
TEN = (18.3, 22.3, 8.0, HZ - 0.5, HZ + 8.5)   # tenon |x| range, half y, z range
ZS = HZ + 5.5                     # cross-screw axis height (groove holes)
SCR_X = (18.3, 22.3)              # cross-screw axes |x| (tenon inner / outer face)
PAD = (11.0, 27.5, 11.0)          # head pad |x| range, half y (front face y=-11 = screw head seat); R3 from 11.0
APEG = (-15.0, 7.75, 1.0, 2.5, 1.1, 3.0)   # R3 apron pegs: x, |y|, r, height; head hole r, depth
# ---- neck fasteners
NSCR = [(-15.0, ZB + 6.0), (5.0, ZB + 6.0), (17.8, -2.5)]       # M2x12 along +Y (R3: 3rd = new, +X side)
OBL = (-14.2, 0.3, 28.0)          # R3: 4th M2x14 OBLIQUE (x, z at the front face, rise deg): head hidden in the torso
                                  # (mouth top z 2.68 < 3), crosses the parting plane at z 5.6 -> pulls the upper neck
DOWELS = [(-5.0, ZB + 3.5), (19.0, 3.0)]                         # D2 steel (R3: 1st moved down)
DOWEL_R = (1.01, 1.0)             # R5: hole r FRONT half (D2.02 slip) / BACK half (D2.0, reamed, dowel EPOXIED)
CLOSE = 0.05                      # R4: each half is moved this much toward y=0 (parting gap 0.1 closed) in halves()
BUMP = (2.8, 1.2, 7.2)            # R4: MG90S 2nd top-cover bump r, height, centre distance from the spline axis (-Z)
BUMP_REL = (3.0, 1.4, 5.5, 7.5)   # R4: pocket relief r, depth, centre-distance range covered (stadium)
SADDLE_LAND = (8.645, AXZ - 5.96, 35.0)  # R4: land start |y| (on R10.5), z, rise angle (deg) toward the y=+-10 face


def rbox(x0, x1, y0, y1, z0, z1, r=0.0, axis=Axis.Z):
    b = Pos((x0 + x1) / 2, (y0 + y1) / 2, (z0 + z1) / 2) * Box(x1 - x0, y1 - y0, z1 - z0)
    return fillet(b.edges().filter_by(axis), r) if r > 0 else b


def prism_x(pts, x0, x1):
    """extrude a closed (y, z) polygon from x0 to x1"""
    w = Polyline(*[(x0, y, z) for y, z in pts], close=True)
    return extrude(Face(w), amount=x1 - x0, dir=(1, 0, 0))


def servo():
    """MG90S: case 22.5 (X) x 12.2 (Y) x 22.8 (Z) R0.5 long edges, boss r5.9 to 28.5, spline D4.8 to 31.5 with M2 hole,
    lower mounting tab (32.5 span, 2.5 thick at 15.5..18 from the case bottom), UPPER tab trimmed flush with the case,
    lead strain-relief block on the bottom end face."""
    case = rbox(XC, XB, -6.1, 6.1, SZ0, SZ1, 0.5, Axis.X)
    boss = xcyl(5.9, XC - 6.0, XC, 0, AXZ)
    spl = xcyl(2.4, XC - 9.0, XC - 6.0, 0, AXZ) - xcyl(0.8, XC - 9.1, XC - 6.0, 0, AXZ)
    tab = rbox(TAB_X0, TAB_X1, -6.1, 6.1, SZ0 - 4.85, SZ0 + 0.5) - xcyl(1.0, TAB_X0 - 1, TAB_X1 + 1, 0, SZ0 - 2.475)
    relief = rbox(LEAD_X - 0.85, LEAD_X + 0.85, -2.0, 2.0, SZ0 - 2.0, SZ0 + 0.3)
    return case + boss + spl + tab + relief + servo_bump()


def servo_bump(dist=None, h=None, r=None):
    """R4: 2nd round bump on the MG90S top cover beside the output boss (repo envelope micro_servo_local:
    D5.6 x 1.2 tall, centre 7.2 from the spline axis toward the far end of the case = -Z here)"""
    r0, h0, d0 = BUMP
    r, h, d = (r0 if r is None else r), (h0 if h is None else h), (d0 if dist is None else dist)
    return xcyl(r, XC - h, XC + 0.01, 0, AXZ - d)


def bump_relief():
    """R4: pocket relief for the bump: stadium r3.0 (0.2 radial) x 1.4 deep (0.2 axial), centre distance 5.5..7.5"""
    r, dp, d0, d1 = BUMP_REL
    x0, x1 = XC - dp, XC + 0.01
    return (xcyl(r, x0, x1, 0, AXZ - d0) + xcyl(r, x0, x1, 0, AXZ - d1) +
            rbox(x0, x1, -r, r, AXZ - d1, AXZ - d0))


def servo_pocket():
    """case pocket: Y = case (clamped when the halves close), X/Z clearance G; boss, hub bore, arm sweep, tab slot"""
    case = rbox(XC - G, XB + G, -6.1 - GY, 6.1 + GY, SZ0 - Z_FLOOR, SZ1 + G, 0.5, Axis.X)   # R5: floor = datum
    boss = xcyl(5.9 + G, BOSS_FLOOR, XC, 0, AXZ)                     # R5: 0.3 axial gap at the boss top (end wall 1.3)
    hub = xcyl(4.0, XC - 6.0, -LUG0, 0, AXZ)                         # horn hub bore through the -X end wall
    sweep = xcyl(6.6, -KN, -LUG0 - 0.5, 0, AXZ)                      # arm sweep relief in the ledge |x| 17.5..17.75
    tab = rbox(TAB_SLOT[0], TAB_SLOT[1], -6.1 - GY, 6.1 + GY, SZ0 - 4.85 - G, SZ0 + 0.6)   # R5: wide (tab range)
    return case + boss + hub + sweep + tab + foam_recess() + bump_relief()


def foam_recess():
    """R3: 0.3 deep recess for the foam strip on each large (Y) pocket face, low on the case (far from the shaft)"""
    d, _, _, x0, x1, z0, z1 = FOAM
    w = 6.1 + GY
    return rbox(x0, x1, -w - d, -w + 0.01, z0, z1, 0.5, Axis.Y) + rbox(x0, x1, w - 0.01, w + d, z0, z1, 0.5, Axis.Y)


def foam():
    """R3: 2 x closed-cell PU foam strip (PORON 0.5, self-adhesive), drawn COMPRESSED (0.35) on the case faces"""
    _, _, tc, x0, x1, z0, z1 = FOAM
    return Compound([rbox(x0 + 0.2, x1 - 0.2, -6.1 - tc, -6.1, z0 + 0.2, z1 - 0.2, 0.3, Axis.Y),
                     rbox(x0 + 0.2, x1 - 0.2, 6.1, 6.1 + tc, z0 + 0.2, z1 - 0.2, 0.3, Axis.Y)])


def horn():
    """stock MG90S 2-arm horn trimmed to 12 mm tip-to-tip: hub OD7 over the full 3 mm spline (0.3 above the boss),
    arms 5 wide x 1.6 thick (flush with the hub top) along Z at rest; spline bore + D2 screw hole"""
    hub = xcyl(3.5, XC - 9.6, XC - 6.3, 0, AXZ)
    arms = Pos(XC - 8.8, 0, AXZ) * Box(1.6, 5.0, 7.0) + xcyl(2.5, XC - 9.6, XC - 8.0, 0, AXZ + 3.5) + \
        xcyl(2.5, XC - 9.6, XC - 8.0, 0, AXZ - 3.5)
    return hub + arms - xcyl(2.4, XC - 9.0, XC - 6.2, 0, AXZ) - xcyl(1.0, XC - 9.7, XC - 8.9, 0, AXZ)


def horn_screw():
    return xcyl(1.9, XC - 10.8, XC - 9.6, 0, AXZ) + xcyl(0.8, XC - 9.6, XC - 6.0, 0, AXZ)


def neck_void_dict():
    """named voids of the neck (used by halves() and by the wall checks)"""
    x0, x1, hy = LEAD_CH
    v = dict(case_pocket=servo_pocket(),
             lead_channel=rbox(x0, x1, -hy, hy, ZB - 1.0, SZ0 + 0.1),          # servo lead to the neck bottom
             head_chamber=rbox(CHAM[0], CHAM[1], -CHAM[2], CHAM[2], ZB - 1.0, CHAM[3], 0.4, Axis.Z),
             pin_seat=pin_seat(),
             counterbore=xcyl(CB_R, CB_X, LUG0 + 0.5, 0, AXZ) - xcyl(BOSS[0], CB_X - 0.1, BOSS[1], 0, AXZ))
    for i, (x, z) in enumerate(NSCR):
        v[f"screw_cbore_{i}"] = ycyl(2.1, -BT / 2 - 1, -BT / 2 + 2.0, x, z)
        v[f"screw_clear_{i}"] = ycyl(1.2, -BT / 2, 0.1, x, z)
        v[f"insert_hole_{i}"] = ycyl(1.7, -0.1, 3.6, x, z) + ycyl(1.2, 3.5, 5.0, x, z)   # R3: insert bottoms at 3.6, pilot
    i, sp = len(NSCR), OBL_SP()
    v[f"screw_cbore_{i}"] = ocyl(2.1, -1.5, OBL_HEAD[1])
    # R4: the oblique holes now end/start EXACTLY on the parting plane (clipped by y=0) - their tilted end discs used to
    # leave 0.05-0.5 resin wedges at the parting face of both halves
    v[f"screw_clear_{i}"] = ocyl(1.2, OBL_HEAD[1] - 0.01, sp + 1.0) & _side_box(-1)
    v[f"insert_hole_{i}"] = (ocyl(1.7, sp - 1.0, sp + 5.3) & _side_box(1)) + ocyl(1.2, sp + 5.2, sp + 6.4)
    for i, (x, z) in enumerate(DOWELS):
        v[f"dowel_hole_{i}"] = ycyl(DOWEL_R[0], -3.2, 0.0, x, z) + ycyl(DOWEL_R[1], 0.0, 3.2, x, z)   # R4 slip | press
    return v


OBL_HEAD = (1.4, 3.0)              # R5: ISO 7045 pan head top (k 1.6) / bearing face along the oblique axis (0.4 deeper)


def OBL_SP():
    """axial distance from the front-face point to the parting plane y=0"""
    return (BT / 2) / math.cos(math.radians(OBL[2]))


def ocyl(r, s0, s1):
    """cylinder on the oblique screw axis (from the front-face point (x, -BT/2, z), direction (0, cos a, sin a))"""
    x, z, a = OBL
    return Location((x, -BT / 2, z)) * Rot(a - 90, 0, 0) * Pos(0, 0, (s0 + s1) / 2) * Cylinder(r, s1 - s0)


def neck_voids():
    return list(neck_void_dict().values())


def lip():
    """static lip ring on the -X knuckle end (r6.8..8.0, x -17.4..-18.4): runs in the cap groove, hides the horn"""
    return xcyl(LIP[1], LIP[2], -KN + 0.1, 0, AXZ) - xcyl(LIP[0], LIP[2] - 1, -KN + 1, 0, AXZ)


def neck_env():
    """outer envelope of the neck (no holes): 45 x 20 R2 blade, saddle R10.5 under the lugs, knuckle R10 |x|<=17.5,
    + the -X lip ring (inside the 0.5 hinge seam / cap groove)"""
    body = rbox(-BW / 2, BW / 2, -BT / 2, BT / 2, ZB, AXZ, 2.0, Axis.Z)
    for sx in (-1, 1):
        x0, x1 = sorted((sx * (KN + 0.25), sx * (BW / 2 + 1.0)))
        cut = Pos((x0 + x1) / 2, 0, AXZ + (RK + 1.0) / 2) * Box(x1 - x0, BT + 2, RK + 1.0) + xcyl(RK + 0.5, x0, x1, 0, AXZ)
        body = body - cut - saddle_land(x0, x1)
    return body + xcyl(RK, -KN, KN, 0, AXZ) + lip()


def saddle_land(x0, x1):
    """R4: blunts the 18 deg feather edge where the R10.5 saddle meets the y=+-10 faces: material above a plane rising
    35 deg outward from (|y| 8.645, AXZ-5.96) [a point ON the saddle] is removed -> face top at AXZ-5.01, wall >= 1.35
    at the faces and >= 1.23 across the R2 corner fillets (ray-cast rule: opposite normals)"""
    y0, z0, a = SADDLE_LAND
    t = math.tan(math.radians(a))
    out = None
    for sy in (-1, 1):
        ya, yb = 8.0, BT / 2 + 1.5
        pts = [(sy * ya, z0 + (ya - y0) * t), (sy * yb, z0 + (yb - y0) * t), (sy * yb, AXZ + 12), (sy * ya, AXZ + 12)]
        c = prism_x(pts, x0, x1)
        out = c if out is None else out + c
    return out


def pin_seat():
    """R3: union of the two half-seats (r2.55 centred 0.05 outward = r2.55 about the axis once the halves close);
    D-flat at z=+2.25 from SEAT_X0 to SEAT_FLAT (pin flat at +2.2 -> 0.05 epoxy gap); open to the pocket at -X"""
    flat = Pos((SEAT_X0 + SEAT_FLAT) / 2 - 0.05, 0, AXZ + 2.25 + 2) * Box(SEAT_FLAT - SEAT_X0 + 0.1, 8, 4)
    return (xcyl(SEAT_R, SEAT_X0, BOSS[1] + 0.1, -0.05, AXZ) + xcyl(SEAT_R, SEAT_X0, BOSS[1] + 0.1, 0.05, AXZ)) - flat


def _side_box(sy):
    return Pos(0, sy * 50, 0) * Box(200, 100, 400)


def closed_voids(sy):
    """R4: the voids of ONE half as they sit when the neck is CLOSED: every void was designed for halves cut 0.05 short
    of y=0 that move 0.05 toward each other on assembly, so for the front half (sy=-1) the voids are moved +0.05 Y and
    for the back half (sy=+1) -0.05 Y.  The outer envelope is NOT moved -> closed neck exactly 45 x 20, knuckle R10."""
    return {k: v.moved(Location((0, -sy * CLOSE, 0))) for k, v in neck_void_dict().items()}


def closed_void_dict():
    """R4: closed-state voids of the whole neck (front-half part + back-half part of every void)"""
    f, b = closed_voids(-1), closed_voids(1)
    out = {}
    for k in f:
        parts = [p for p in (f[k] & _side_box(-1), b[k] & _side_box(1)) if p is not None and p.solids()]
        out[k] = parts[0] if len(parts) == 1 else parts[0] + parts[1]
    return out


def halves():
    """R4: neck halves in the CLOSED (assembled) position: front y -10..0, back y 0..10, touching on y=0; internal
    voids in their closed-state positions (pocket +-6.15, pin seat r2.55 about the axis, insert step y 3.55 ...)"""
    out = []
    for sy in (-1, 1):
        h = neck_env()
        for c in closed_voids(sy).values():
            h = h - c
        h = h & _side_box(sy)
        out.append(h.solids()[0] if len(h.solids()) == 1 else h)
    return out[0], out[1]


def xcone(r0, r1, x0, x1, y=0.0, z=0.0):
    """truncated cone along X: radius r0 at x0 -> r1 at x1"""
    from build123d import Cone
    c = Cone(r0, r1, abs(x1 - x0), align=None).rotate(Axis.Y, 90 if x1 > x0 else -90)
    return c.moved(Location((x0, y, z)))


def pin():
    """hollow pin 4.99/3 (ground steel tube, h6) 12.8..18.5: D-flat 0.3 (z=+2.2) 1.6 long at the -X end, open end slot
    1.8 x 2.5 on the -Z side at the -X end (wires enter from below), both bore ends chamfered 0.5 x 45"""
    p = xcyl(PIN_R, PIN_X0, PIN_X1, 0, AXZ) - xcyl(1.5, PIN_X0 - 1, PIN_X1 + 1, 0, AXZ)
    p = p - Pos((PIN_X0 + PIN_FLAT) / 2 - 0.1, 0, AXZ + 2.2 + 2) * Box(PIN_FLAT - PIN_X0 + 0.2, 8, 4)
    w, d = PIN_SLOT
    p = p - Pos(PIN_X0 + d / 2 - 0.1, 0, AXZ - 2.0) * Box(d + 0.2, w, 2.0)
    p = p - xcone(2.0, 1.4, PIN_X1 + 0.001, PIN_X1 - 0.6, 0, AXZ) - xcone(2.0, 1.4, PIN_X0 - 0.001, PIN_X0 + 0.6, 0, AXZ)
    return p.solids()[0] if len(p.solids()) == 1 else p


def bearing():
    """MR85 as 2 rings (outer turns with the lug, inner static on the pin)"""
    outer = xcyl(4.0, BRG_X0, BRG_X1, 0, AXZ) - xcyl(3.55, BRG_X0 - 1, BRG_X1 + 1, 0, AXZ)
    inner = xcyl(3.0, BRG_X0, BRG_X1, 0, AXZ) - xcyl(2.5, BRG_X0 - 1, BRG_X1 + 1, 0, AXZ)
    return outer, inner


def neck_fasteners():
    """3 x M2x12 pan (head in a D4.2x2 counterbore of the front half) into glue-in knurled inserts M2 (OD3.2 x 3, hole
    D3.4 x 4) in the back half; 2 x D2x6 steel dowels"""
    scr, ins = [], []                     # R4: screws ride with the closed FRONT half (+0.05), inserts with the BACK (-0.05)
    for x, z in NSCR:
        scr.append(ycyl(2.0, -BT / 2 + 0.4, -BT / 2 + 2.0, x, z) + ycyl(0.8, -BT / 2 + 2.0, 4.0, x, z))   # R5: ISO 7045
        ins.append(ycyl(1.6, 0.6, 3.6, x, z) - ycyl(1.0, 0, 4, x, z))                  # R3: on the hole step
    sp, h0, h1 = OBL_SP(), OBL_HEAD[0], OBL_HEAD[1]
    scr.append(ocyl(2.0, h0, h1) + ocyl(0.8, h1, h1 + 14.0))                          # R5: ISO 7045 M2x14 (k 1.6)
    ins.append(ocyl(1.6, sp + 2.3, sp + 5.3) - ocyl(1.0, sp, sp + 5.5))                # on the hole step (back half)
    out = [s.moved(Location((0, CLOSE, 0))) for s in scr] + [s.moved(Location((0, -CLOSE, 0))) for s in ins]
    dw = [ycyl(1.0, -3.0, 3.0, x, z) for x, z in DOWELS]
    return Compound(out), Compound(dw)


LUG_POLY = [(-10.0, 12.0), (10.0, 12.0), (10.0, DZW + 1.34), (8.66, DZW), (-8.66, DZW), (-10.0, DZW + 1.34)]


def _poly_w(dz_poly):
    return [(y, AXZ + z) for y, z in dz_poly]


def lug_blank(sx):
    """barrel R10 + web (+-10 above AXZ+5, chamfer from the barrel), outer face edges R2 (like the neck's R2 corners),
    top = head bottom - 0.1, + tenon (into the head floor slot)"""
    x0, x1 = sorted((sx * LUG0, sx * LUG1))
    lug = prism_x(_poly_w(LUG_POLY), x0, x1) + xcyl(RK, x0, x1, 0, AXZ)
    lug = lug.solids()[0].clean()
    fo = [f for f in lug.faces() if abs(f.center().X - sx * LUG1) < 1e-3 and abs(abs(f.normal_at().X) - 1) < 1e-6][0]
    eds = [e for e in fo.edges() if e.center().Z < AXZ + 11.5]
    try:
        lug = fillet(eds, 2.0)
    except Exception as ex:                                              # fallback: barrel arc only
        print("lug fillet fallback", ex, flush=True)
        lug = fillet([e for e in eds if e.geom_type != "LINE" or e.center().Z < AXZ], 2.0)
    lug = lug - HC.head_outer(HZ - 0.1)
    t0, t1, ty, tz0, tz1 = TEN
    xa, xb = sorted((sx * t0, sx * t1))
    return lug + rbox(xa, xb, -ty, ty, tz0, tz1, 1.0, Axis.Z)


def groove_holes(sx, r=0.8):
    return [ycyl(r, -TEN[2] - 0.1, -2.0, sx * x, ZS) for x in SCR_X]


def rib(y, z):
    """R5: crush rib along -X: lead-in cone from r(flush)=RIB_r-0.1 at the slot mouth to RIB_r, then full radius"""
    r, _, _ = RIB
    x0, x1, x2 = RIB_X
    return xcone(r - 0.1, r, x0 + 0.01, x1, y, z) + xcyl(r, x2, x1 + 0.01, y, z)


def cap():
    """-X lug CAP (usko_kryt): horn-arm slot 5.0 x 12.4 x 1.65 with 4 crush ribs (0.1 per flank -> no backlash), hub
    clearance r3.9, screw-head bore, closed 1.6 outer wall; groove r5.9..8.4 for the static knuckle lip; tenon"""
    c = lug_blank(-1)
    xs0, xs1 = -LUG0 + 0.01, CAP_SLOT_X1                                          # R5: slot x -17.99..-20.15
    slot = Pos((xs0 + xs1) / 2, 0, AXZ) * Box(abs(xs1 - xs0), 5.0, 7.4) + \
        xcyl(2.5, xs0, xs1, 0, AXZ + 3.7) + xcyl(2.5, xs0, xs1, 0, AXZ - 3.7)
    rr, ry, rz = RIB
    for sy in (-1, 1):
        for sz in (-1, 1):
            slot = slot - rib(sy * ry, AXZ + sz * rz)                       # R5: full-length rib + lead-in
    groove = xcyl(GROOVE[1], -LUG0 + 0.01, GROOVE[2], 0, AXZ) - xcyl(GROOVE[0], -LUG0 + 1, GROOVE[2] - 1, 0, AXZ)
    c = c - slot - groove - xcyl(3.9, xs0, xs1, 0, AXZ) - xcyl(2.3, xs1 + 0.01, CAP_HEAD_X1, 0, AXZ) - cap_slot_square()
    for g in groove_holes(-1):
        c = c - g
    return c.solids()[0]


def cap_slot_square():
    """R4: inside the lip-groove depth (x -17.99..-18.8) the round slot ends are squared off out to r5.95 (|y|<=2.5,
    |dz|>=3.7) so no resin sliver is left between the slot ends and the groove inner wall r5.9 (ribs untouched)"""
    x0, x1 = -LUG0 + 0.01, GROOVE[2]
    r = 5.95
    boxes = rbox(x1, x0, -2.5, 2.5, AXZ + 3.7, AXZ + 7.0) + rbox(x1, x0, -2.5, 2.5, AXZ - 7.0, AXZ - 3.7)
    return xcyl(r, x0, x1, 0, AXZ) & boxes


def lug_channel(r=0.8):
    """R4: +X lug wire channel: x 20.5 from the axis to AXZ+5 (1.2 wall to the MR85 stop shoulder at x 18.5), tilted to
    x 20.3 by the tenon base HZ-0.5 (tenon walls 1.2/1.2), x 20.3 up to the tenon top; spheres at the two kinks"""
    from build123d import Plane, Solid as _S
    from build123d import Vector as V
    za, zb = LCH_ZJ
    p0, p1 = V(LCH_X, 0, za), V(LCH_X2, 0, zb)
    d = p1 - p0
    tilt = _S.make_cylinder(r, d.length, Plane(origin=p0, z_dir=d.normalized()))
    return (zcyl(r, AXZ, za, x=LCH_X) + tilt + zcyl(r, zb, TEN[4] + 1, x=LCH_X2) +
            Pos(*p0) * Sphere(r) + Pos(*p1) * Sphere(r))


def lug_plus():
    """+X lug: SLEEVE r4.0..5.5 x16.5..18 (MR85 outer ring glued in, bore r4.0 to 18.5 = ring stop), wire chamber
    r3.2 x18.5..21.3, wire channel D1.6 (R4: x 20.5 -> 20.3, lug_channel()) to the tenon top; + front/back APRONS"""
    l = lug_blank(1)
    apr = prism_x(_poly_w(LUG_POLY), -KN - 0.25, LUG0 + 0.5) - xcyl(RK + 0.5, -KN - 1, LUG0 + 1, 0, AXZ)
    apr = apr - Pos(0, 0, AXZ) * Box(60, 11.0, 40) - HC.head_outer(HZ - 0.1)
    s0, s1, sr0, sr1 = SLV
    l = l + apr + xcyl(sr1, s0, s1 + 0.3, 0, AXZ) + apron_pegs()
    l = l - xcyl(sr0, s0 - 0.01, BRG_X1, 0, AXZ) - xcyl(3.2, BRG_X1 - 0.01, LCH_Z0, 0, AXZ)
    l = l - lug_channel()                                               # R4 (was a straight D1.6 at x 20.3)
    for g in groove_holes(1):
        l = l - g
    return l.solids()[0] if len(l.solids()) == 1 else l


def head_floor_z(x, y):
    """lowest z of the head exterior on the vertical line (x, y)"""
    return (HC.head_outer(HZ) & zcyl(0.005, HZ - 5, HZ + 10, x=x, y=y)).bounding_box().min.Z


def apron_pegs():
    """R3: one peg D2 x 2.5 on each apron top near its -X tip (enters a D2.2 head-pad hole, 3 crush ribs) -> the
    36 mm apron is held at both ends (lug root + head) and cannot sag/warp onto the static neck"""
    x, y, r, h, _, _ = APEG
    out = None
    for sy in (-1, 1):
        zf = head_floor_z(x, sy * y) - 0.1
        p = zcyl(r, zf - 1.0, zf + h - 0.3, x=x, y=sy * y) + xcone_z(r, r - 0.3, zf + h - 0.3, zf + h, x, sy * y)
        out = p if out is None else out + p
    return out


def xcone_z(r0, r1, z0, z1, x, y):
    from build123d import Cone
    return Pos(x, y, (z0 + z1) / 2) * Cone(r0, r1, z1 - z0)


def head_pads_and_cuts():
    adds, cuts = [], []
    for sx in (-1, 1):
        xa, xb = sorted((sx * PAD[0], sx * PAD[1]))
        adds.append(HC.clip_inside(rbox(xa, xb, -PAD[2], PAD[2], HZ - 1.0, TEN[4]), HZ))
        xa, xb = sorted((sx * (TEN[0] - 0.1), sx * (TEN[1] + 0.1)))
        cuts.append(rbox(xa, xb, -TEN[2] - 0.1, TEN[2] + 0.1, HZ - 1.5, TEN[4] + 0.5, 1.1, Axis.Z))
        cuts += groove_holes(sx)
        # R4: clearance D2.2 now runs through the R1.1 slot-corner zone (to y -6.9): it used to stop at -8.05 and left
        # 0.002-0.4 resin slivers between its end face and the rounded slot corners
        cuts += [ycyl(1.1, -PAD[2] - 0.6, -TEN[2] + 1.1, sx * x, ZS) for x in SCR_X]
    # R5: clean-up of the 0.1 step ridge where the rabbet floor (y -27.0) meets the inner floor (local z ~2.73):
    # one plain step (y -27.05..-26.85 down to local z 2.55) instead of a 0.005-0.12 resin ridge
    cuts.append(rbox(-12.0, 12.0, -27.05, -26.85, HZ + 2.55, HZ + 3.0))
    x, y, _, _, hr, hd = APEG
    for sy in (-1, 1):
        zf = head_floor_z(x, sy * y)
        # R4: mouth chamfer starts 0.4 BELOW the floor point (the floor slopes ~0.1 in y): no 0.01-0.12 film at the mouth
        hole = zcyl(hr, zf - 1.0, zf + hd, x=x, y=sy * y) + xcone_z(hr + 0.7, hr, zf - 0.4, zf + 0.3, x, sy * y)
        for k in range(3):                       # 3 crush ribs r0.2, 0.05 interference on the D2 peg (friction hold)
            a = math.radians(90 + 120 * k)
            hole = hole - zcyl(0.2, zf + 0.3, zf + hd + 0.1, x=x + 1.15 * math.cos(a), y=sy * y + 1.15 * math.sin(a))
        cuts.append(hole)
    return adds, cuts


def cross_screws():
    """4 x M2x8 ISO 7380 button head (R5: dk 3.5 x k 1.1, hex 1.3), thread-forming in the D1.6 pilot, along +Y, head on
    the pad front face y=-11.  The two axes per side are only 4.0 apart -> a dk 4.0 pan head would touch its neighbour."""
    return Compound([ycyl(1.75, -PAD[2] - 1.1, -PAD[2], sx * x, ZS) + ycyl(0.8, -PAD[2], -PAD[2] + 8.0, sx * x, ZS)
                     for sx in (-1, 1) for x in SCR_X])


TOP = 4.0                                   # torso top (collar disc top), static


def collar():
    """golier: disc R26.5 (z -2..4) with the 45.5 x 20.5 R1.75 slot (unchanged - neck still 45 x 20 R2) + thin ring"""
    slot = fillet((Pos(0, 0, TOP - 3) * Box(BW + 0.5, BT + 0.5, 10)).edges().filter_by(Axis.Z), 1.75)
    disc = Pos(0, 0, TOP - 3) * Cylinder(26.5, 6) - slot
    ring = Pos(0, 0, TOP - 3) * (Cylinder(26.5 + 1.75, 6) - Cylinder(26.5 + 0.25, 6.2))   # R3: z -2..4, on the floor
    return disc, ring


def torso():
    """illustrative torso as exported for B, REPAIRED: the source STL's top recess cut had failed (top_r 28.5 coincided
    with the cutter -> the torso was solid through the collar disc and the neck).  top_r 29.8 (rim 1.3) + recess r28.5 (z -2..4)
    + a neck well 47 x 22 down to z -40 (the retracted neck reaches -36.5); recess floor at z=-2 = disc bottom."""
    sys.path.insert(0, "/home/user/Robot")
    from nova_v8 import klasik as KL
    KL.K["torso"].update(w=108.0, d=74.0, h=100.0, top_r=29.8)
    t = KL.loft(KL.torso_secs())
    t = t.moved(Location((0, 0, TOP - t.bounding_box().max.Z)))
    t = t - (Pos(0, 0, TOP - 2.995) * Cylinder(26.5 + 2.0, 6.01))                   # recess floor z=-2 (disc rests on it)
    well = fillet((Pos(0, 0, -21.0) * Box(BW + 2.0, BT + 2.0, 38.2)).edges().filter_by(Axis.Z), 2.5)
    return t - well


def tube(pts, R, r=0.665):
    """wire bundle D1.33: circle swept along a polyline whose corners are filleted with radius R (= bend radius)"""
    from build123d import FilletPolyline, Wire, Plane, Circle, sweep, Vector as V
    w = Wire(FilletPolyline(*pts, radius=R).edges())
    sec = Plane(origin=pts[0], z_dir=(V(*pts[1]) - V(*pts[0])).normalized()) * Circle(r)
    return sweep(sec, path=w)


def cable_paths():
    """kabel: 4 x AWG30 PTFE (bundle D1.33).  STATIC part: neck bottom -> chamber beside the servo (x 13.7) -> up through
    the pin's -Z end slot -> bend R1.5 inside the pin bore -> pin end x18.5.  ROTATING part (turns with the head): pin end
    on the hinge axis (pure twist) -> bend R2.0 inside the lug chamber -> lug channel x20.5 -> (tilted) x20.3 in the
    tenon -> tenon top -> display."""
    XJ = BRG_X1 - 0.1                                     # static/rotating joint on the axis (inside the chamfer)
    zt = HZ + 12.0
    return [([(WB[0], 0, ZB - 3.0), (WB[0], 0, AXZ), (XJ, 0, AXZ)], WB[1], "N"),
            ([(XJ, 0, AXZ), (LCH_X, 0, AXZ), (LCH_X, 0, LCH_ZJ[0]), (LCH_X2, 0, LCH_ZJ[1]), (LCH_X2, 0, zt - 3.0)],
             LCH_X - BRG_X1, "H"),
            ([(LCH_X2, 0, zt - 3.0), (LCH_X2, 0, zt), (LCH_X2, -12.6, zt), (LCH_X2, -12.6, HZ + 20.0)], 2.0, "H")]


def cables():
    c = cable_paths()
    neck = tube(*c[0][:2])
    head = tube(*c[1][:2]) + tube(*c[2][:2])
    lead = rbox(LEAD_X - 0.65, LEAD_X + 0.65, -1.8, 1.8, ZB - 3.0, SZ0 - 2.0)
    return neck, head, lead


def tube_mesh(pts, R, r=0.665, n=24, ds=0.12, ph0=0.0):
    """R3: watertight triangle mesh of the same tube (filleted polyline, ring of n, parallel-transport frames, caps)"""
    import numpy as np
    P = [np.array(p, float) for p in pts]
    path = [P[0]]
    Rs = list(R) if isinstance(R, (list, tuple)) else [R] * (len(P) - 2)
    for i in range(1, len(P) - 1):
        a, b, c, R = P[i - 1], P[i], P[i + 1], Rs[i - 1]
        u, v = (a - b) / np.linalg.norm(a - b), (c - b) / np.linalg.norm(c - b)
        th = math.acos(np.clip(u @ v, -1, 1))
        t = R / math.tan(th / 2)
        ctr = b + (u + v) / np.linalg.norm(u + v) * R / math.sin(th / 2)
        p0, p1 = b + u * t, b + v * t
        k = max(2, int(math.ceil(np.linalg.norm(p0 - path[-1]) / 1.0)))
        path += [path[-1] + (p0 - path[-1]) * j / k for j in range(1, k + 1)]
        e0, e1 = p0 - ctr, p1 - ctr
        ang = math.acos(np.clip(e0 @ e1 / (R * R), -1, 1))
        w = np.cross(np.cross(e0, e1), e0); w /= np.linalg.norm(w)
        m = max(4, int(math.ceil(R * ang / ds)))
        path += [ctr + R * (math.cos(ang * j / m) * e0 / R + math.sin(ang * j / m) * w) for j in range(1, m + 1)]
    k = max(2, int(math.ceil(np.linalg.norm(P[-1] - path[-1]) / 1.0)))
    path += [path[-1] + (P[-1] - path[-1]) * j / k for j in range(1, k + 1)]
    Q = np.array(path)
    keep = np.r_[True, np.linalg.norm(np.diff(Q, axis=0), axis=1) > 1e-6]
    Q = Q[keep]
    T = np.gradient(Q, axis=0); T /= np.linalg.norm(T, axis=1, keepdims=True)
    nrm = np.cross(T[0], [0.0, 1.0, 0.0] if abs(T[0][1]) < 0.9 else [1.0, 0.0, 0.0]); nrm /= np.linalg.norm(nrm)
    rings = []
    for i in range(len(Q)):
        if i:
            nrm = nrm - (nrm @ T[i]) * T[i]; nrm /= np.linalg.norm(nrm)
        bn = np.cross(T[i], nrm)
        rings.append([Q[i] + r * (math.cos(2 * math.pi * (j + ph0) / n) * nrm + math.sin(2 * math.pi * (j + ph0) / n) * bn)
                      for j in range(n)])
    V = np.array(rings)
    tri = []
    for i in range(len(Q) - 1):
        for j in range(n):
            a, b_, c, d = V[i, j], V[i + 1, j], V[i + 1, (j + 1) % n], V[i, (j + 1) % n]
            tri += [(a, c, b_), (a, d, c)]
    for j in range(n):
        tri.append((Q[0], V[0, (j + 1) % n], V[0, j]))
        tri.append((Q[-1], V[-1, j], V[-1, (j + 1) % n]))
    Tr = np.array(tri, np.float32)
    sv = np.einsum('ij,ij->i', Tr[:, 0], np.cross(Tr[:, 1], Tr[:, 2])).sum()
    return Tr if sv > 0 else Tr[:, [0, 2, 1]]


def build_all():
    """registry: name -> list of (shape, group); group H = head side (lifts + tilts), N = neck side (lifts), T = torso"""
    adds, cuts = head_pads_and_cuts()
    P = {}
    P["hlava_skrupina"] = [(HC.head_shell(HZ, cuts=cuts, adds=adds), "H")]
    P["sklo"] = [(HC.visor(HZ), "H")]
    P["usi"] = [(HC.ears(HZ), "H")]
    P["led_kruzky"] = [(HC.led_rings(HZ), "H")]
    P["led_dosky"] = [(HC.led_boards(HZ), "H")]
    dp, dm = HC.display_parts(HZ), HC.display_mount(HZ)
    P["displej"] = [(dp["lcd"], "H"), (dp["pcb"], "H"), (dp["comp"], "H"), (gasket(), "H")]   # R5: 4 corner pads
    P["drziak_displeja"] = [(dm["seats"], "H"), (dm["ribs"], "H")]          # printed WITH the shell (reference only)
    P["oci_len_vizualizacia"] = [(HC.eyes_decal(HZ), "H")]
    nf, nb = halves()
    P["krk_predna_polovica"] = [(nf, "N")]
    P["krk_zadna_polovica"] = [(nb, "N")]
    P["usko_kryt"] = [(cap(), "H")]
    P["usko_lozisko"] = [(lug_plus(), "H")]
    P["paka"] = [(horn(), "H")]
    P["servo_MG90S"] = [(servo(), "N")]
    P["pena_serva"] = [(foam(), "N")]                                     # R3: 2 foam strips (compressed state)
    bo, bi = bearing()
    P["loziska_MR85"] = [(bo, "H"), (bi, "N")]
    nsc, dw = neck_fasteners()
    P["capy"] = [(pin(), "N"), (dw, "N")]
    P["skrutky"] = [(nsc, "N"), (horn_screw(), "H"), (cross_screws(), "H"), (dm["inserts"], "H")]
    cn, ch, cl = cables()
    P["kabel"] = [(cn, "N"), (ch, "H"), (cl, "N")]
    disc, ring = collar()
    P["golier_kotuc"] = [(disc, "T")]
    P["golier_prstenec"] = [(ring, "T")]
    return P


PADS = (3.0, 0.6)                   # R5: display foam pad size (square), inset from the LCD outline 86 x 56


def gasket():
    """R5: 4 closed-cell foam PADS 3 x 3 on the LCD border corners (outside the active area), drawn COMPRESSED (0.2,
    y -27.1..-26.9) -> 36 mm2 instead of the 276 mm2 frame: preload <= 0.72 N at <= 20 kPa (montaz press test), i.e.
    <= 3.5 kPa permanent tension on the visor tape.  Free thickness 0.3 / 0.4 after measuring the gap (montaz 18)."""
    zc, (a, e) = HC.ZC_L(), PADS
    out = []
    for sx in (-1, 1):
        for sz in (-1, 1):
            cx, cz = sx * (HC.DW / 2 - e - a / 2), zc + sz * (HC.DH / 2 - e - a / 2)
            out.append(Pos(cx, (HC.Y_VB + HC.Y_L0) / 2, cz) * Box(a, HC.Y_L0 - HC.Y_VB, a))
    return HC._w(Compound(out), HZ)


AX = Axis((0, 0, AXZ), (1, 0, 0))


def pose(shape, group, lift=0.0, tilt=0.0):
    """lift: 0 = extended, -20 = rest; tilt about the hinge axis (+ = nod down / front down)"""
    if group == "T":
        return shape
    s = shape.rotate(AX, tilt) if (group == "H" and tilt) else shape
    return s.moved(Location((0, 0, lift))) if lift else s


def tris(shape, tol=0.01, ang=0.1):
    import numpy as np
    out = []
    for s in (shape.solids() if shape.solids() else [shape]):
        v, t = s.tessellate(tol, ang)
        if t:
            V = np.array([[p.X, p.Y, p.Z] for p in v], dtype=np.float32)
            out.append(V[np.array(t)])
    return np.concatenate(out) if out else np.zeros((0, 3, 3), np.float32)


def write_stl(path, T):
    import numpy as np
    T = np.asarray(T, np.float32)
    n = np.cross(T[:, 1] - T[:, 0], T[:, 2] - T[:, 0]); n /= np.maximum(np.linalg.norm(n, axis=1, keepdims=True), 1e-12)
    rec = np.zeros(len(T), dtype=np.dtype([('n', '<f4', 3), ('v', '<f4', (3, 3)), ('a', '<u2')]))
    rec['n'], rec['v'] = n, T
    with open(path, 'wb') as f:
        f.write(b"NOVA mini B (mm, Z up, front -Y)".ljust(80, b" ")); f.write(len(T).to_bytes(4, 'little')); f.write(rec.tobytes())


def read_stl(path):
    import numpy as np
    d = open(path, 'rb').read(); n = int.from_bytes(d[80:84], 'little')
    return np.frombuffer(d[84:], dtype=np.dtype([('n', '<f4', 3), ('v', '<f4', (3, 3)), ('a', '<u2')]), count=n)['v'].copy()


def tf(T, lift=0.0, tilt=0.0):
    """numpy pose of a triangle array (same convention as pose())"""
    import numpy as np
    T = T.copy()
    if tilt:
        a = math.radians(tilt); c, s = math.cos(a), math.sin(a)
        y, z = T[..., 1].copy(), T[..., 2] - AXZ
        T[..., 1], T[..., 2] = c * y - s * z, s * y + c * z + AXZ
    T[..., 2] += lift
    return T


SRC_T = "/home/user/Robot/obrazky/postupne/03_koncept_otocny_krk/stl/B_servo_v_krku/"
REF_ONLY = ("drziak_displeja",)                 # fused into the shell: separate STL for viewing, not in CELOK


def export(P):
    import numpy as np, os
    os.makedirs(f"{D}/stl", exist_ok=True)
    M = {}                                       # name -> list of (tris extended pose, group)
    for k, lst in P.items():
        M[k] = [(tris(s), g) for s, g in lst]
    M["trup"] = [(tris(torso(), 0.02, 0.15), "T")]                                     # repaired (see torso())
    # R3: collar from collar() (disc = source disc, same slot 45.5 x 20.5 R1.75; ring now 6 tall, z -2..4)
    (pn, rn, _), (ph, rh, _), (ph2, rh2, _) = cable_paths()                # one closed tube per side (no shared caps):
    rr = [rh] * (len(ph) - 2) + [rh2] * (len(ph2) - 2)                    # R4: path 2 has 3 corners (tilted channel)
    ph = [(ph[0][0] - 0.1,) + tuple(ph[0][1:])] + ph[1:-1] + ph2[1:]       # head tube starts 0.1 inside the neck tube
    M["kabel"] = [(tube_mesh(pn, rn), "N"), (tube_mesh(ph, rr, ph0=0.5), "H"), (tris(P["kabel"][2][0]), "N")]
    files = []
    for k, lst in M.items():                     # every part separately, REST pose (neck + head -20)
        T = np.concatenate([t if g == "T" else tf(t, -LIFT) for t, g in lst])
        write_stl(f"{D}/stl/{k}.stl", T); files.append(f"{D}/stl/{k}.stl")
    for fn, tilt in (("CELOK_vysunute", 0.0), ("CELOK_naklon40", 40.0)):
        T = np.concatenate([t if g != "H" else tf(t, 0.0, tilt) for k, lst in M.items() if k not in REF_ONLY
                            for t, g in lst])
        write_stl(f"{D}/stl/{fn}.stl", T); files.append(f"{D}/stl/{fn}.stl")
    T = np.concatenate([t if g == "T" else tf(t, -LIFT) for k, lst in M.items() if k not in REF_ONLY for t, g in lst])
    write_stl(f"{D}/stl/CELOK_pokoj.stl", T); files.append(f"{D}/stl/CELOK_pokoj.stl")
    return files


if __name__ == "__main__":
    import time
    t0 = time.time()
    P = build_all()
    for k, lst in P.items():
        print(k, [(s.is_valid, len(s.solids())) for s, g in lst], round(time.time() - t0, 1), flush=True)
    files = export(P)
    print("exported", len(files), round(time.time() - t0, 1), flush=True)
